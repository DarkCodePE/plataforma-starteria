# Starteria — Change Shaping Proposal

**Documento:** `STARTERIA_CHANGE_SHAPING_PROPOSAL_v0.2.md`  
**Versión:** v0.2  
**Estado:** PROPUESTA INICIAL / PARA VALIDACIÓN  
**Tipo:** Business-to-Change Shaping Contract / Upstream Harness Proposal  
**Ámbito:** Necesidad de negocio → localización del cambio → cambio definido → handoff a Delivery Translation  
**Propósito:** Externalizar el modelo mental utilizado para transformar una necesidad, señal, problema u oportunidad de negocio en un cambio suficientemente claro, localizado, acotado, gobernado y verificable antes de traducirlo a User Stories, Tech Specs, Tasks o código.

---

# 0. Cambios respecto a v0.1

Esta versión incorpora una nueva regla de experiencia:

> **El usuario no debería necesitar recordar la arquitectura interna de Starteria para poder registrar una necesidad de cambio.**

Por tanto:

- `Change Location` deja de ser un input obligatorio;
- se introduce un `Change Locator`;
- se distingue entre:
  - dónde se observa el problema;
  - dónde probablemente se origina;
  - qué momentos impacta;
- se añaden `Journey Anchors` en lenguaje humano;
- se incorpora una lectura por `Product Layer`, `Journey Moment`, `Change Topology`, `Change Depth` y `Change Reach`;
- la localización puede ser `RESOLVED`, `PROVISIONAL`, `AMBIGUOUS`, `CROSS_MOMENT`, `CROSS_LAYER` o `UNKNOWN`;
- la localización puede refinarse progresivamente durante el shaping;
- se propone mantener un `STARTERIA_PRODUCT_JOURNEY_MAP` interno para ayudar a agentes y personas a ubicar cambios sin depender de memoria.

La regla principal de v0.1 se mantiene:

> **Change Shaping define qué debe cambiar y por qué. Delivery Translation define cómo convertir ese cambio en software. CODEX implementa trabajo ya suficientemente definido.**

---

# 1. Posición dentro del Harness

```text
BUSINESS SIGNAL / NEED
        ↓
CHANGE UNDERSTANDING
        ↓
CHANGE LOCATOR
        ↓
CHANGE SHAPING
        ↓
SHAPED CHANGE
        ↓
DELIVERY TRANSLATION
        ↓
HU / BUSINESS RULES / AC / TECH SPEC / TASKS
        ↓
DEVELOPMENT HARNESS
        ↓
CODEX / IMPLEMENTATION
        ↓
TEST / HARNESS / E2E
        ↓
RELEASE
        ↓
OBSERVATION / LEARNING
```

Este documento cubre la parte anterior al diseño técnico.

No sustituye:

- `STARTERIA_AUTHORITY.md`;
- `STARTERIA_CORE_LOGIC_CONTRACT.md`;
- ADRs;
- Experience Contracts;
- Agent Contracts;
- Skill Contracts;
- Tech Specs;
- schemas;
- tests;
- implementación.

---

# 2. Principio central

> **La persona describe la situación; el sistema reconstruye dónde vive el cambio.**

El usuario debe poder empezar con algo como:

> “Cuando alguien recibe una iniciativa que ya venía trabajada, entra demasiado de golpe y no entiende todo lo que pasó antes.”

No necesita recordar:

- si pertenece a Portfolio Lead;
- si ocurre en un Handoff;
- si existe un Overview;
- si está antes de Step 0;
- si impacta el Brief;
- si afecta Benefit Tracking.

El sistema debe reconstruir esa localización progresivamente.

---

# 3. Tres formas válidas de entrada

## A. Lenguaje natural

> “Cuando el owner recibe una iniciativa pierde contexto.”

## B. Ubicación aproximada

> “Pasa cuando una persona pasa de Portfolio a trabajar su iniciativa.”

## C. Ubicación exacta conocida

> “Quiero cambiar el Overview post-handoff antes de Step 0.”

Las tres entradas deben converger al mismo objeto estructurado.

Regla:

> **Nunca exigir una taxonomía interna que Starteria pueda reconstruir razonablemente.**

---

# 4. Lifecycle de Change Shaping v0.2

```text
CS-0  SIGNAL
        ↓
CS-1  WHY / EVIDENCE
        ↓
CS-2  CURRENT REALITY
        ↓
CS-3  DESIRED OUTCOME
        ↓
CS-4  CHANGE LOCATOR
        ↓
CS-5  CHANGE DIMENSIONING
        ↓
CS-6  POINTS OF CHANGE + AUTHORITY CHECK
        ↓
CS-7  SCOPE / BOUNDARIES / NO-GOS
        ↓
CS-8  PROOF / BEHAVIOR EXAMPLES
        ↓
CS-9  SHAPED CHANGE GATE
```

El `Change Locator` puede ejecutarse más de una vez.

Ejemplo:

```text
inicio                   UNKNOWN
↓
Current Reality          HANDOFF
↓
Desired Outcome          HANDOFF + OVERVIEW
↓
auditoría posterior      HANDOFF + OVERVIEW + READ MODEL
```

La historia no debe sobrescribirse silenciosamente.

---

# 5. CS-0 — Signal

## Pregunta

> ¿Qué ocurrió para que estemos considerando un cambio?

## Capturar

```text
signal
source
observed_at_if_known
reported_by
evidence_reference
frequency
severity
confidence
```

`observed_at_if_known` es opcional.

`No recuerdo dónde ocurre` es una respuesta válida.

---

# 6. CS-1 — Why / Evidence

## Preguntas

> ¿Por qué esto importa?

> ¿Qué pasa si no cambia?

> ¿Qué resultado queremos mejorar?

## Capturar

```text
business_reason
user_reason
product_reason
reason_now
expected_value
risk_of_no_change
```

No aceptar una solución como objetivo.

Ejemplo:

```text
No:
“Necesitamos un nuevo Overview.”

Sí:
“Queremos evitar que el Initiative Owner reconstruya manualmente
el contexto de una iniciativa ya asignada.”
```

---

# 7. CS-2 — Current Reality

## Pregunta

> ¿Qué ocurre realmente hoy?

Separar:

### Current Product Behavior

- qué estaba haciendo la persona;
- qué esperaba;
- qué ocurrió;
- qué pasó después;
- qué generó la fricción.

### Current Governing Logic

Cuando esté disponible:

- contrato relevante;
- regla existente;
- autoridad;
- restricción.

### Current Implementation

Puede auditarse después.

No es obligatorio conocer route, component, service o schema para iniciar Change Shaping.

---

# 8. CS-3 — Desired Outcome

## Preguntas

> ¿Quién necesita hacer, entender o decidir algo diferente?

> ¿Qué debería poder ocurrir después que hoy no ocurre?

## Estructura

```text
actor
job
current_friction
desired_behavior
desired_outcome
decision_to_enable
```

Regla:

> Describir primero la diferencia de comportamiento; diseñar después la solución.

---

# 9. CS-4 — Change Locator

## Propósito

Responder:

> **¿Dónde parece manifestarse esta necesidad dentro de Starteria y qué otros momentos podrían verse afectados?**

El Change Locator no decide:

- archivo;
- componente;
- endpoint;
- tabla;
- migration;
- solución técnica.

Localiza conceptualmente el cambio.

---

# 10. Inputs del Change Locator

Puede inferir desde:

```text
actor
action
preceding_event
expected_result
actual_result
visible_copy
approximate_moment
role_transition
decision_context
artifact_mentioned
screenshot_reference
route_if_known
test_reference
issue_reference
```

Ningún input es obligatorio por sí mismo.

---

# 11. Regla de clarificación

No preguntar:

> “¿Es Challenge Activation, Initiative Handoff o Step 0?”

Preguntar:

> “¿El problema ocurre cuando asignas la iniciativa, cuando la otra persona la acepta o cuando ya entra a trabajarla?”

La taxonomía interna pertenece al estado estructurado, no necesariamente al lenguaje visible.

---

# 12. Journey Anchors

Los `Journey Anchors` permiten ubicarse sin conocer la arquitectura interna.

```text
J0 — ANTES DE CREAR TRABAJO
Quiero ordenar algo o entender qué hacer.

J1 — ORGANIZANDO EL PORTAFOLIO
Estoy definiendo prioridades, retos o iniciativas.

J2 — ACTIVANDO / ENTREGANDO TRABAJO
Estoy asignando, invitando, transfiriendo o activando trabajo.

J3 — INICIANDO UNA INICIATIVA
Acabo de recibir/crear una iniciativa y necesito entender cómo comenzar.

J4 — DESARROLLANDO UNA INICIATIVA
Estoy entendiendo, diseñando, probando o aprendiendo.

J5 — CERRANDO UNA INICIATIVA
Estoy consolidando resultados y preparando una salida.

J6 — TOMANDO UNA DECISIÓN
Necesito decidir continuidad, escalamiento, transferencia, pausa o cierre.

J7 — SIGUIENDO RESULTADOS
Estoy observando si el valor esperado realmente ocurrió.
```

Reglas:

- ayudan, no obligan;
- no sustituyen la ontología interna;
- pueden inferirse desde el relato;
- el usuario puede seleccionar uno si le facilita explicar la situación.

---

# 13. Product Layer

Valores iniciales:

```text
PUBLIC_ENTRY
PORTFOLIO
INITIATIVE
DECISION_CONTINUITY
CROSS_CUTTING
UNKNOWN
```

## PUBLIC_ENTRY

- entrada pública;
- Portfolio Entry;
- interpretación inicial;
- onboarding.

## PORTFOLIO

```text
Contexto organizacional
→ Frente
→ Reto
→ Activación
→ Cobertura
→ Seguimiento
→ Alertas
→ Decisiones de Portfolio
```

## INITIATIVE

```text
Assignment / Acceptance
→ Handoff
→ Overview
→ Step 0
→ Step 1
→ Step 2
→ Step 3
→ Step 4
```

## DECISION_CONTINUITY

```text
Initiative Brief
→ Business Decision
→ Continuity
→ Benefit Tracking
```

## CROSS_CUTTING

- provenance;
- evidence;
- permissions;
- audit;
- analytics;
- AI governance;
- organization context;
- notifications.

---

# 14. Journey Moment

Taxonomía conceptual inicial:

```text
ENTRY

PORTFOLIO_HOME
PORTFOLIO_DEFINITION
FRONT_DEFINITION
CHALLENGE_DEFINITION
CHALLENGE_ACTIVATION
PORTFOLIO_MONITORING

INITIATIVE_ASSIGNMENT
INITIATIVE_ACCEPTANCE
INITIATIVE_HANDOFF
INITIATIVE_OVERVIEW

STEP_0
STEP_1
STEP_2
STEP_3
STEP_4

INITIATIVE_BRIEF
BUSINESS_DECISION
CONTINUITY
BENEFIT_TRACKING

MULTI_MOMENT
CROSS_CUTTING
UNKNOWN
```

Estos son momentos conceptuales, no necesariamente pantallas.

---

# 15. Observed At ≠ Originates At ≠ Impacts

Separar:

## `observed_at`

Dónde la persona percibe el problema.

## `probable_origin`

Dónde parece originarse.

## `affected_moments`

Dónde produce efectos.

Ejemplo:

```text
Problema:
“El Brief no muestra correctamente el objetivo original.”

observed_at:
INITIATIVE_BRIEF

probable_origin:
CHALLENGE → INITIATIVE context propagation

affected_moments:
INITIATIVE_BRIEF
BUSINESS_DECISION
BENEFIT_TRACKING
```

Regla:

> No asumir que el lugar donde se observa el problema es el lugar donde debe resolverse.

---

# 16. Location Status

```text
RESOLVED
PROVISIONAL
AMBIGUOUS
CROSS_MOMENT
CROSS_LAYER
UNKNOWN
```

`UNKNOWN` no bloquea automáticamente el shaping.

Solo debe pedirse aclaración si la ambigüedad cambia materialmente:

- scope;
- authority;
- contract impact;
- depth;
- reach.

---

# 17. Provenance de localización

Valores:

```text
USER_DECLARED
AI_INFERRED
REPO_VERIFIED
CONTRACT_VERIFIED
USER_CONFIRMED
```

Ejemplo:

```yaml
observed_at:
  value: INITIATIVE_HANDOFF
  origin: AI_INFERRED
  review_status: UNREVIEWED
```

Una inferencia no debe aparecer después como confirmada sin un evento de confirmación real.

---

# 18. Change Topology

Valores:

```text
LOCAL_SURFACE
JOURNEY_MOMENT
HANDOFF
MULTI_MOMENT
CROSS_LAYER
CROSS_CUTTING
```

Especial atención a `HANDOFF` porque muchos problemas importantes no viven en una pantalla sino entre dos momentos.

Ejemplos:

```text
Portfolio → Initiative
Assignment → Acceptance
Step 4 → Brief
Brief → Decision
Decision → Benefit Tracking
```

---

# 19. Software Change Gate

Antes de asumir software:

> ¿Esto realmente requiere modificar el producto?

Valores:

```text
NO_PRODUCT_CHANGE
COPY_CHANGE
CONFIGURATION_CHANGE
PROCESS_CHANGE
DATA_CHANGE
TRAINING_ENABLEMENT
SOFTWARE_CHANGE
MIXED_CHANGE
UNKNOWN
```

---

# 20. CS-5 — Change Dimensioning

Dos coordenadas independientes.

## Change Depth

```text
C0 — Presentation
C1 — Experience / Behavior
C2 — System / Capability
C3 — Core / Architecture / Authority
```

## Change Reach

```text
R0 — Local
R1 — Single Journey
R2 — Multi-Moment
R3 — Cross-Layer
R4 — Cross-Cutting
```

Ejemplos:

```text
C0 / R0
Cambio de copy local.
```

```text
C1 / R3
Continuidad Portfolio → Initiative.
```

```text
C2 / R2
Nueva semántica persistente usada en varios Steps.
```

```text
C3 / R4
Cambio de autoridad transversal.
```

---

# 21. CS-6 — Points of Change

`Location` responde **dónde**.

`Points of Change` responde **qué tipo de elemento puede cambiar**.

| Área | Estado |
|---|---|
| Business logic | CHANGE / PRESERVE / UNKNOWN |
| Core | CHANGE / PRESERVE / UNKNOWN |
| Experience | CHANGE / PRESERVE / UNKNOWN |
| Human authority | CHANGE / PRESERVE / UNKNOWN |
| AI authority | CHANGE / PRESERVE / UNKNOWN |
| Agent | CHANGE / PRESERVE / UNKNOWN |
| Skills | CHANGE / PRESERVE / UNKNOWN |
| Data | CHANGE / PRESERVE / UNKNOWN |
| Backend | CHANGE / PRESERVE / UNKNOWN |
| Frontend | CHANGE / PRESERVE / UNKNOWN |
| Analytics | CHANGE / PRESERVE / UNKNOWN |
| Security / permissions | CHANGE / PRESERVE / UNKNOWN |
| Migration | CHANGE / PRESERVE / UNKNOWN |
| Tests / Harness | CHANGE / PRESERVE / UNKNOWN |

`UNKNOWN` es válido.

---

# 22. Authority Check

Preguntar:

```text
¿Existe un contrato que gobierna este comportamiento?
¿El cambio cabe dentro de él?
¿Cambia una regla estable?
¿Cambia autoridad humana?
¿Cambia autoridad IA?
¿Cambia dominio?
¿Cambia Step 0–4?
¿Cambia gating?
¿Requiere migración material?
```

Resultado:

```text
NO_CONTRACT_DELTA
EXPERIENCE_DELTA
AGENT_DELTA
SKILL_DELTA
TECH_ONLY_DELTA
CORE_OR_ADR_REQUIRED
UNRESOLVED
```

---

# 23. CS-7 — Scope / Boundaries / No-Gos

Capturar:

```text
IN SCOPE
OUT OF SCOPE
NO-GOS
PRESERVE
APPETITE
```

Ejemplo:

```text
IN
- preservar contexto del handoff;
- mostrar qué heredó;
- mostrar pendientes;
- mostrar siguiente acción.

OUT
- rediseñar Step 0;
- cambiar Portfolio Home.

NO-GOS
- no activar Steps automáticamente;
- no cambiar ownership;
- no confirmar inferencias.

PRESERVE
- función estable de Step 0;
- autoridad existente.

APPETITE
Resolver continuidad de contexto sin crear una segunda metodología.
```

---

# 24. CS-8 — Proof / Behavior Examples

Formato:

```text
GIVEN
contexto

WHEN
evento / acción

THEN
resultado observable

AND
restricciones preservadas
```

Ejemplo:

```gherkin
Given un Initiative Owner ha aceptado una iniciativa vinculada a un reto

When accede por primera vez a la iniciativa

Then comprende por qué existe
And distingue contexto heredado de información pendiente
And identifica su siguiente acción
And ninguna inferencia no confirmada aparece como hecho
And el acceso no activa automáticamente un Step
```

---

# 25. CS-9 — Shaped Change Gate

Puede marcarse:

```text
READY_FOR_DELIVERY_TRANSLATION
```

cuando existe suficiente claridad sobre:

- Signal;
- Why;
- Current Reality;
- Desired Outcome;
- Change Location o localización provisional suficiente;
- Change Topology;
- Change Depth;
- Change Reach;
- Points of Change;
- Scope;
- No-Gos;
- Preserve;
- Authority Impact;
- Proof;
- incertidumbres bloqueantes.

No exige localización perfecta.

Exige que la incertidumbre restante no impida una traducción responsable a software.

---

# 26. Output canónico — ShapedChange v0.2

```yaml
shaped_change:
  id: CHG-XXX
  version: 1
  shaping_model_version: 0.2

  title:

  signal:
    description:
    source:
    evidence:
    confidence:

  why:
    business_reason:
    user_reason:
    reason_now:
    risk_of_no_change:

  actor:
    primary:
    secondary:

  current_reality:
    current_behavior:
    governing_logic:
    known_constraints:

  desired_outcome:
    desired_behavior:
    user_outcome:
    business_outcome:
    decision_to_enable:

  software_change_gate:
    result:
    notes:

  journey_impact:
    observed_at:
      status:
      candidates: []

    probable_origin:
      status:
      candidates: []

    primary_layer:
    primary_moment:
    topology:

    affected_moments: []
    upstream_dependencies: []
    downstream_impacts: []
    explicitly_unaffected: []

    location_confidence:
      level:

    clarification:
      required:
      question:

  change_dimensioning:
    depth: C0 | C1 | C2 | C3
    reach: R0 | R1 | R2 | R3 | R4
    rationale:
    blast_radius:
    reversibility:

  points_of_change:
    business_logic:
    core:
    experience:
    human_authority:
    ai_authority:
    agent:
    skills:
    data:
    backend:
    frontend:
    analytics:
    security:
    migration:
    tests:

  authority:
    governing_contracts:
    required_delta:
    adr_required:
    unresolved_conflicts:

  scope:
    in_scope:
    out_of_scope:
    no_gos:
    preserve:
    appetite:

  proof:
    scenarios:

  uncertainties:
    blocking:
    non_blocking:

  readiness:
    status:
    ready_reason:
```

---

# 27. STARTERIA_PRODUCT_JOURNEY_MAP

El Harness debería mantener una cartografía conceptual interna.

```text
PUBLIC ENTRY
    ↓
PORTFOLIO ENTRY
    ↓
PORTFOLIO HOME
    ↓
STRATEGIC FRONT
    ↓
CHALLENGE
    ↓
CHALLENGE ACTIVATION
    ↓
INITIATIVE ASSIGNMENT
    ↓
INITIATIVE ACCEPTANCE
    ↓
INITIATIVE HANDOFF
    ↓
INITIATIVE OVERVIEW
    ↓
STEP 0
    ↓
STEP 1
    ↓
STEP 2
    ↓
STEP 3
    ↓
STEP 4
    ↓
INITIATIVE BRIEF
    ↓
BUSINESS DECISION
    ↓
CONTINUITY
    ↓
BENEFIT TRACKING
```

No es necesariamente la navegación UI.

Es una cartografía del lifecycle.

---

# 28. Metadata futura del Journey Map

Cada nodo puede contener:

```text
node_id
human_name
internal_name
layer
journey_anchor
roles
purpose
upstream
downstream
governing_contracts
inputs
outputs
known_routes
agents
skills
tests
status
```

Esto permitirá que futuros agentes localicen cambios con mayor precisión.

---

# 29. Evidencias de localización

El Locator podrá usar:

```text
texto libre
screenshot
ruta
URL interna
nombre visible de pantalla
copy visible
video
test fallido
issue Jira
PR
commit
archivo
contrato
```

Una evidencia de ubicación no demuestra necesariamente la causa.

---

# 30. Caso aplicado — usuario no recuerda dónde ocurre

Input:

> “Quiero mejorar una parte porque cuando alguien recibe un proyecto que ya venía trabajado por otra persona, parece que entra demasiado de golpe a continuar y no entiende todo lo que pasó antes. No recuerdo dónde estaba exactamente.”

## Interpretación inicial

```text
Signal:
ruptura de continuidad de contexto

Actor:
probable Initiative Owner

Trigger:
recibe trabajo ya existente

Desired Outcome:
comprender origen + contexto heredado + estado actual + siguiente acción
```

## Localización inicial

```yaml
status: PROVISIONAL

observed_at:
  candidates:
    - INITIATIVE_OVERVIEW
    - STEP_0

probable_origin:
  candidates:
    - INITIATIVE_HANDOFF

upstream_dependencies:
  - INITIATIVE_ASSIGNMENT
  - INITIATIVE_ACCEPTANCE

downstream_impacts:
  - STEP_0
```

## Aclaración mínima

> “Cuando dices que entra demasiado de golpe, ¿te refieres a que al abrir la iniciativa no encuentra un resumen previo o a que ya comienza directamente el trabajo del primer Step?”

Respuesta:

> “Más lo segundo.”

## Localización refinada

```text
primary:
INITIATIVE_HANDOFF / INITIATIVE_OVERVIEW

downstream:
STEP_0_ENTRY

preserve:
STEP_0_FUNCTION
```

El usuario no tuvo que recordar taxonomía interna.

---

# 31. Caso aplicado — problema observado en Brief

Input:

> “En el resumen final no se entiende bien qué esperaba mover originalmente la iniciativa.”

## Observed At

```text
INITIATIVE_BRIEF
```

## Probable Origin

No asumir que vive solo en Brief.

Candidatos:

```text
CHALLENGE_CONTEXT_PROPAGATION
INITIATIVE_EXPECTED_CONTRIBUTION
BRIEF_READ_MODEL
```

## Affected

```text
INITIATIVE_BRIEF
BUSINESS_DECISION
BENEFIT_TRACKING
```

## Regla

Antes de “arreglar el Brief”, verificar si la información:

```text
existe
↓
se hereda
↓
se conserva
↓
se expone
```

---

# 32. Definition of Ready v0.2

```text
[ ] Existe una señal concreta.
[ ] Existe una razón para actuar.
[ ] El actor está identificado o suficientemente inferido.
[ ] La realidad actual está suficientemente entendida.
[ ] El resultado deseado está expresado como comportamiento/outcome.
[ ] Se evaluó si realmente requiere software.
[ ] Existe una localización resuelta o provisional suficiente.
[ ] Se separó observed_at de probable_origin cuando es material.
[ ] Se identificaron momentos afectados.
[ ] Se identificó topology.
[ ] Se determinó Change Depth.
[ ] Se determinó Change Reach.
[ ] Los Points of Change fueron identificados.
[ ] El impacto en autoridad fue evaluado.
[ ] El alcance está definido.
[ ] Los no-gos están definidos.
[ ] Se declaró qué debe preservarse.
[ ] Existe al menos un comportamiento observable de prueba.
[ ] No existe una decisión crítica escondida.
[ ] Los conflictos de autoridad están resueltos o escalados.
```

---

# 33. Handoff a Delivery Translation

Cuando:

```text
status = READY_FOR_DELIVERY_TRANSLATION
```

otro proceso puede generar:

```text
User Stories
Business Rules
Acceptance Criteria
Contract deltas
Tech Spec
Implementation slices
Tasks
Test plan
```

Delivery Translation puede refinar la localización mediante auditoría de repo.

No puede cambiar silenciosamente:

```text
Why
Desired Outcome
Scope
No-Gos
Authority
Proof
```

Si descubre que el cambio real es materialmente distinto:

```text
RETURN_TO_CHANGE_SHAPING
```

---

# 34. Learning Loop

El modelo debe aprender de cambios reales.

```text
Change Shaping v0.2
        ↓
cambios reales
        ↓
¿localizamos correctamente?
        ↓
¿preguntamos demasiado?
        ↓
¿Delivery encontró otro origen?
        ↓
¿aparecieron impactos no previstos?
        ↓
Findings
        ↓
Change Shaping v0.3
```

Métricas candidatas:

```text
location_accuracy
location_correction_rate
late_origin_discovery
cross_layer_impact_discovered_late
clarification_questions_per_change
user_taxonomy_burden
delivery_reframing_rate
```

---

# 35. Integración propuesta en un Harness mayor

```text
STARTERIA DELIVERY HARNESS

01 — BUSINESS SIGNAL INTAKE
        ↓
02 — CHANGE UNDERSTANDING
        ↓
03 — CHANGE LOCATOR
        ↓
04 — CHANGE SHAPING
        ↓
05 — AUTHORITY / CONTRACT RESOLUTION
        ↓
06 — DELIVERY TRANSLATION
        ↓
07 — TECHNICAL DESIGN
        ↓
08 — TASK PLANNING
        ↓
09 — CODEX EXECUTION
        ↓
10 — QUALITY GATES
        ↓
11 — RELEASE
        ↓
12 — POST-RELEASE OBSERVATION
        ↓
13 — LEARNING / FINDINGS
```

Esta propuesta cubre principalmente `01–04` y define el handoff hacia `05–06`.

---

# 36. Próximos artefactos sugeridos

Después de validar esta propuesta:

```text
STARTERIA_CHANGE_SHAPING_CONTRACT_v0.1.md
```

Luego:

```text
STARTERIA_SHAPED_CHANGE_SCHEMA_v0.1.yaml
```

Y:

```text
STARTERIA_PRODUCT_JOURNEY_MAP_v0.1.md
```

Posteriormente:

```text
STARTERIA_DELIVERY_TRANSLATION_PLAYBOOK_v0.1.md
```

Y finalmente:

```text
CODEX_EXECUTION_CONTRACT_v0.1.md
```

---

# 37. Principios finales

> **Starteria no debería pedirle a la persona que recuerde dónde vive un problema antes de permitirle describirlo.**

> **El usuario expresa la situación; el Change Locator reconstruye dónde se observa, dónde puede originarse y hasta dónde impacta.**

> **La localización es una hipótesis versionada que puede refinarse con contexto, contratos y auditoría técnica.**

> **Una necesidad de negocio no se convierte directamente en código: primero se convierte en un cambio localizado, acotado, gobernado y verificable.**
