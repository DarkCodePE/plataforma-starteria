# STARTERIA_TARGET_MODEL_MANIFEST_RECONCILED v0.1

**Fecha:** 2026-10-14 · **Modo:** auditoría autónoma, producto read-only, sin implementación.

## Target reconciliado

`TARGET = B + overlays elegibles acotados + contratos aprobados aplicables − comportamiento sustituido`.

**B = DarkCodePE/plataforma-starteria, main@f365800288bd74d83985bfbd00e1b9bd6d74eeda.** Identidad oficial esperada pendiente D-01. No se construyó ni fusionó un checkout combinado. Las variantes son simulaciones conceptuales sustentadas por código/documentos, no demostración de implementación ni despliegue conjunto.

## Jerarquía documental reconstruida

| Nivel | Fuente y estado | Uso en auditoría |
|---|---|---|
| 1 | [AGENTS.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/AGENTS.md>) + instrucción usuario RTK.md | Gobierna operación; la orden actual read-only prevalece sobre workflows de implementación. |
| 2 | [docs/STARTERIA_AUTHORITY.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/STARTERIA_AUTHORITY.md>) | Índice de autoridad y distinción v0.2 factual / v0.3 candidata. |
| 3 | [doc/CONTRATO_LOGICA_CORE_STARTERIA_MVP_v0.2_ES(1).md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/CONTRATO_LOGICA_CORE_STARTERIA_MVP_v0.2_ES(1).md>) | Core factual; encabezado Base fundacional revisada/Por validar. No se eleva a ratificación absoluta: es la referencia factual declarada por authority. |
| 3 candidata | [docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md>) | v0.3 no promovida. Sus deltas se evalúan como escenarios, no invalidan automáticamente código vigente. |
| 4 | [doc/product-adr/ADR-INDEX.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/product-adr/ADR-INDEX.md>) | ADR-001 propuesto; 002–007 aceptados con alcance. No confundir numeración de producto, backend y harness. |
| 5 | [doc/experience/portfolio-entry/PORTFOLIO_ENTRY_LOGIC_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/experience/portfolio-entry/PORTFOLIO_ENTRY_LOGIC_CONTRACT_v0.1.md>) | Activo; Entry provisional textual; sin canonicalización por IA. |
| 5 candidato | [docs/experience/portfolio-entry/PORTFOLIO_ENTRY_CLARIFICATION_HANDOFF_CONTRACT_v0.2.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/experience/portfolio-entry/PORTFOLIO_ENTRY_CLARIFICATION_HANDOFF_CONTRACT_v0.2.1.md>) | Propuesto para testing. Adoptar sólo partes respaldadas por decisiones posteriores como ADR-002. |
| 5 | [docs/experience/portfolio-entry/PORTFOLIO_ENTRY_CRITICAL_REASONING_EXPERIENCE_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/experience/portfolio-entry/PORTFOLIO_ENTRY_CRITICAL_REASONING_EXPERIENCE_CONTRACT_v0.1.md>) | Accepted/frozen acotado, adopción runtime por KAN-114/119. |
| 5 | [docs/experience/portfolio-entry/PORTFOLIO_ENTRY_STARTERIA_PATH_EXPERIENCE_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/experience/portfolio-entry/PORTFOLIO_ENTRY_STARTERIA_PATH_EXPERIENCE_CONTRACT_v0.1.md>) | 114E y frontera de capacidades; la proyección no otorga autoridad. |
| 5 | [docs/experience/portfolio-entry/PORTFOLIO_SETUP_CONTINUITY_EXPERIENCE_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/experience/portfolio-entry/PORTFOLIO_SETUP_CONTINUITY_EXPERIENCE_CONTRACT_v0.1.md>) | 114F acotado Portfolio-first; implementación133A–F integrada, 133G diferida. |
| 5 | [docs/portfolio-lead/05-activation-handoff/PORTFOLIO_TO_INITIATIVE_ACTIVATION_EXPERIENCE_CONTRACT_v0.2.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/portfolio-lead/05-activation-handoff/PORTFOLIO_TO_INITIATIVE_ACTIVATION_EXPERIENCE_CONTRACT_v0.2.md>) | Active/frozen for planning; Accept != Start; v0.1 superseded. |
| 5 | [docs/portfolio-lead/06-portfolio-home-governance/PORTFOLIO_HOME_READ_MODEL_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/portfolio-lead/06-portfolio-home-governance/PORTFOLIO_HOME_READ_MODEL_CONTRACT_v0.1.md>) | PH0 congelado; PH2 GO_WITH_GAPS; PH3B no equivale a Home ya completo. |
| 5 | [docs/portfolio-lead/07-strategic-framing/STRATEGIC_FRAMING_EXPERIENCE_CONTRACT_v0.1.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/portfolio-lead/07-strategic-framing/STRATEGIC_FRAMING_EXPERIENCE_CONTRACT_v0.1.md>) | SF0 aprobado, SF3 provisional; extensiones aprobadas sólo en rama SF conservadas como variante. |
| 4–5 WIP | [sf-wip-source/backend/docs/adr/ADR-032-session-scoped-portfolio-context-selection-persistence.md](sf-wip-source/backend/docs/adr/ADR-032-session-scoped-portfolio-context-selection-persistence.md) y ADR-033; SF5A/SF6A/SF7B2B | Decisiones accepted/GO_WITH_GAPS localizadas en rama e1fbfd 1; scope acotado; no promoción automática a authority integrada. |
| 6 | [docs/agents/portfolio-entry/PORTFOLIO_ENTRY_AGENT_CONTRACT_v0.2.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/agents/portfolio-entry/PORTFOLIO_ENTRY_AGENT_CONTRACT_v0.2.md>) | PROPUESTO PARA TESTING; orquesta intent/context/reverse alignment/questions. |
| 7 | [docs/agents/portfolio-entry/skills/entry-04-question-planner/SKILL_v0.2.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/agents/portfolio-entry/skills/entry-04-question-planner/SKILL_v0.2.md>); skills 01–03 | Candidatos; presupuesto controlador y 0–1 pregunta activa respaldados por ADR-002; procedencia separada de revisión. |
| 8 | [docs/ai-harness/portfolio-entry/PORTFOLIO_ENTRY_HARNESS_EXECUTION_SPEC_v0.2.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/ai-harness/portfolio-entry/PORTFOLIO_ENTRY_HARNESS_EXECUTION_SPEC_v0.2.md>) | Laboratorio aislado; conformance != validación de hipótesis. Archivo con algunos bytes no UTF8 leído con reemplazo identificado. |
| 9–10 | PRDs, CURRENT_STATE, STARTERIA_V2_MANIFEST, informes de implementación | Evidencia subordinada. Frases históricas “119 pending” no prevalecen sobre ancestry y cierre posterior. |
| Documentos de auditoría | Manifest, Cases, Gap Matrix y Bere aportados | Alcance provisional; escenarios; preguntas de verificación; feedback. Ninguno aprueba Core. |

**Drift documental:** CURRENT_STATE conserva un bloque NOT_YET_IMPLEMENTED antiguo de continuación, seguido del cierre133A–F más reciente; manifest mantiene una línea 119 merge pending antes del cierre integrado. La ruta `docs/product-adr` es histórica frente al índice `doc/product-adr`. Se usa la evidencia más específica y la integración verificable, sin editar estos documentos.

## Clasificación de capacidades y overlays

| Unidad | Estado | Evidencia/alcance | Tratamiento |
|---|---|---|---|
| Landing KAN-102/113; Entry reasoning 114, understanding 116, 114D119 | MERGED_VERIFIED | B + código/contratos; 119 ya integrado | Disponible como baseline de código; proveedor/despliegue no certificado |
| 114E125 y114F134–142 | MERGED_VERIFIED | B; version binding, scoped authority, atomic write, read continuity | Portfolio-first acotado; no atribuir acceso autoaprovisionado |
| Core Steps, Truth, Decision, continuation | MERGED_VERIFIED | Servicios/schema y tests seleccionados | Implementación parcial verificada, con F-04–13; merge no implica completitud |
| KAN-151 S1a | WIP_TARGET_VERIFIED | bf66e2b…; 71 tests +15 browser sintéticos | Simular recuperación conocida/desconocida; human visual gate pendiente |
| KAN-150-A | WIP_TARGET_VERIFIED | B+staged hashes; 57 tests | Una lectura sustentada, sin duplicado ni edición falsa; no persistencia narrativa B |
| KAN-150-B | DEFINED_NOT_IMPLEMENTED | Contrato candidato +planN01–N12 | No afirmar materialDelta/persistencia/versionado disponible; D-07 |
| KAN-144 Copilot v0.3.1/VIS10 v0.5.1 | DEFINED_NOT_IMPLEMENTED / EXPERIMENTAL | Actas de freeze scoped; prototipos | Diseño aprobado acotado; producciónNO, proveedor/idempotencia/export pendientes |
| KAN-145 microcopyv0.2.2 y preview | DEFINED_NOT_IMPLEMENTED / EXPERIMENTAL | Aprobación sólo de literal para preview; Q01–09/Planner abiertos | Mejora conceptual Entry/Bere 03/11/12; no resuelve runtime ni Step 0 |
| SF3D–SF7, KAN-41 | WIP_TARGET_VERIFIED (estático, condicional) | e1fbfd 1…; contratos y código de promoción/contexto; PR77 | Variante T-SF. No fusionar cadena histórica a ciegas; D-12 integración |
| Core v0.3 deltas | DEFINED_NOT_IMPLEMENTED / UNKNOWN aprobación | Candidata, no ratificada | Variantes de estados/alcance D-02–04 |
| BenefitTrackingL5/L6 completo | DEFINED_NOT_IMPLEMENTED | Core factual inv 12; objetos parciales presentes | No confundir ImpactAssertion/continuation con ciclo completo |
| Team/personal Portfolio; petición externa sin Portfolio | UNKNOWN / propuesta | E2E-03/07 | Requieren contrato de alcance y autoridades; no bugs automáticos del release |
| Activationv0.1, default público directo legacy | SUPERSEDED como objetivo | v0.2/ADR-003/005/006 | Legacy accesible puede seguir KEEP_COMPAT; no usarlo como prueba del nuevo journey |
| Dashboardstarteria; harness histórico | EXCLUDED | Remotes distintos | Sólo inventario histórico |
| Marketplace, training automático, MCP multicanal profundo | EXCLUDED | Manifest§7 | No crear missing-feature del release; riesgo futuro sólo si concreto |
| Flags/provider/schema desplegados; original 31; originalBere | UNKNOWN / SOURCE_UNAVAILABLE | No acceso operacional/original | No PASS de producción |

## Variantes de simulación y qué cambian

| Variante | Composición | Resultado proyectado |
|---|---|---|
| T0 | B + autoridad factual vigente | Recorrido Portfolio-first acotado; problemas confirmados de aislamiento, handoff de revisión y continuidad de impacto. |
| T1 | T0 + KAN-151 | Mejora recuperación Entry ante red/respuesta perdida. No arregla RouteConfirmation ni permisos Portfolio. |
| T2 | T0 + KAN-150-A | Reduce duplicación y falsas lecturas de comprensión. No añade narrativa durable/materialDelta. |
| T3 | T0 +151+150-A+target visual KAN-144 | Conceptualmente compatible por finalidad; toca el mismo Experience. Integración de cambios, aceptación visual y backend aún no probadas. |
| T-SF | T3 + slices SF respaldadas por decisiones de rama | Prioriza gaps/capacidad, promueve candidato humano a Challenge draft con snapshots y permite contexto por sesión. No crea automáticamente Initiative/Steps. |
| T-Future | T-SF + deltas Core v0.3 + beneficios completos +team Portfolio | Sólo escenarios contrafactuales; requiere D-02–05/08/12. No se presenta como target aprobado ni implementado. |

T-SF conserva valor real de WIP que no está en main: recomendación derivada separada de disposición humana; focusSlots desconocido no inventado; candidata con identidad estable; promoción transaccional y unicidad(state, candidate); scope de organización; selección por sesión autenticada. El código de promoción consulta autoridad mediante servicio externo a `tx`; revocación concurrente necesita verificación específica. El Home de esa rama conserva su lectura canónica antigua sin where organizacional y aplica contexto a la sección SF: **no** puede usarse como reparación demostrada de F-01–03. También falta recomponer los handoffs/learnings incorporados después en main.

No se suman ramas SF antecesoras como funciones separadas. No se eliminan fuentes/contratos del baseline al simular overlays. Una aprobación literal KAN-145 no valida selección de preguntas ni permite usar respuestas futuras para generar la primera pregunta.

## Integridad conceptual del Target final

Hay una estructura coherente de funciones: entender intención → revisar interpretación → confirmar con autoridad → desarrollar evidencia → decisión humana → continuidad. Se rompe la garantía integral en cuatro fronteras: autoridad de organización no uniforme, semántica tarea/decisión/facto en handoff, actualización de dependencias y realización/atribución del beneficio. Incluso suponiendo implementados los overlays visuales y SF elegibles, esas fronteras siguen abiertas.

El resultado es **Target parcial reconciliado, NO_READY_FOR_MERGE_INTEGRAL**. Cada slice puede tener gates propios; este dictamen no sustituye decisiones humanas ni afirma que toda mejora aislada deba esperar al producto futuro completo.
