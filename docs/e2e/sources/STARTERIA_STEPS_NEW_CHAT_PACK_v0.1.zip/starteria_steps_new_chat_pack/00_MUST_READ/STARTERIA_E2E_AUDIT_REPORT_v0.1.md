# STARTERIA_E2E_AUDIT_REPORT v0.1

**Fecha:** 2026-10-14 · **Modo:** auditoría autónoma, producto read-only, sin implementación.

## Resultado ejecutivo

**Startería no queda certificada como Target integral listo para merge.** Hay una base funcional sustancial y mejoras recientes útiles, pero persisten defectos confirmados de autorización, recuperación y semántica de datos, además de decisiones estructurales sin resolver.

Se evaluó el repositorio accesible **DarkCodePE/plataforma-starteria**, baseline main@`f365800288bd74d83985bfbd00e1b9bd6d74eeda`. El esperado `DarkCodePE/proyect-starteria` no pudo verificarse (404); esa discrepancia se conserva como D-01. El dashboard antiguo se excluyó como implementación vigente.

**Cobertura:** 10/10 casos E2E del catálogo, 22 variantes adversariales, 32 experiencias funcionales, 14 journeys del Manifest, 15 filas de Gap Matrix, 14 findings Bere y 12 tests candidatos Bere. Todos tienen evaluación conceptual y contraste técnico donde hay evidencia; **ninguno de los 10 recorridos se ejecutó íntegro con backend+DB+IA reales**. No es un porcentaje de cobertura de líneas ni de estado completo del sistema.

**Findings:** 23 = 13 CONFIRMED, 1 LIKELY, 5 NEEDS_EVIDENCE y 4 CONTRACT_CONFLICT. Los pendientes de evidencia/experiencia suman 6; los 4 conflictos contractuales se cuentan aparte. Hay 3 S1_CRITICAL. No se asignó S0; no hace falta un S0 para bloquear la readiness integral.

## Lo más material

1. **Seguridad:** ausencia de portfolio:read produce scope global; Home carga handoffs sin filtro de organización; varias mutaciones por ID sólo comprueban permiso global (F-01–03).
2. **Continuidad:** confirmRoute puede crear un Project y quedar bloqueado tras fallar la vinculación final; los reintentos no recuperan esa rama (F-04).
3. **Verdad y decisiones:** una actividad se convierte en decisión y una hipótesis en knownFacts; cambios de mandato no invalidan derivados; estimaciones pueden llegar a realized sin medida operacional adicional (F-05/F-08/F-10).
4. **Valor experiencial:** el FAQ falla ante su propio vocabulario, el modo determinista/degradado no se distingue en el output y Step 4 conserva etiquetas de presentación (F-06/F-07/F-11). Bere no queda resuelto por mejorar Entry.
5. **Target futuro:** ciclo completo de beneficios/atribución pendiente, Core v0.3 no promovido, Portfolio de equipo/Initiative-first requieren reconciliación y Guided anticipado sigue bloqueado (F-13/F-19–21/F-23).

## Target que se auditó

T0 (baseline verificado) + T1 (recuperación KAN-151) + T2 (narrativa UI KAN-150A) + T3 (diseño visual acotado KAN-144); **T-SF** añade condicionalmente la cadena StrategicFraming/KAN-41 con promoción humana y contexto por sesión. No se realizó una fusión. KAN150B, deltas de Core v0.3 y runtime KAN-145 quedan definidos/candidatos según su autoridad; los previews no se contabilizan como implementación.

La línea SF es sustancial: prioriza gaps sin inventar capacidad, conserva snapshots de decisiones humanas y promueve a Challenge draft, sin iniciar Steps. Está 337 commits detrás/32 propios respecto de B; altera autenticación, schema y Home. Su inclusión conceptual no demuestra compatibilidad con 114F ni arregla el scope de todas las colecciones canónicas.

Incluso suponiendo implementados los overlays elegibles y respetados sus límites, siguen abiertos el alcance de autoridad, la propagación de cambios, la semántica del handoff y la continuidad hasta beneficio observado/atribuido. No basta sumar pantallas aprobadas para cerrar esas fronteras.

## Método y niveles de evidencia

**A — Conceptual:** reconstrucción de autoridad, estados, transiciones y variantes de los 10 casos. Contratos superiores prevalecen sobre PRDs/documentación histórica. No se usa v0.3 candidata como ley aprobada ni una aprobación de preview como autorización productiva.

**B — Técnica:** Git no destructivo, lectura de rutas/componentes/servicios/schema/policies/tests/flags, comparación de WIP, pruebas de módulos y probes directos. Los cambios sin commit se anclan a hashes, no sólo a HEAD. Las copias de fuentes SF se extraen mediante git show, sin checkout.

**C — Experiencial preliminar:** inspección de copy, valor de outputs y continuidad; Chromium con UI real de KAN-151 y API interceptada, 15 escenarios. Capturas desktop/móvil guardadas; inspección visual del estado incierto móvil confirma texto conservado, explicación de incertidumbre y Comprobar estado. No se hizo prueba real de usuario, no se certificó accesibilidad integral y no se visitó un despliegue productivo.

## Pruebas realizadas y límites

| Ejecución | Resultado observado | Qué demuestra | Qué no demuestra |
|---|---|---|---|
| front-baseline | 12 suites/135 tests PASS | Review, Overview, MissionReview, dominio adaptativo, acceso del layout, continuidad de Setup y Critical Handoff | Comprensión humana ni backend real |
| backend-baseline | 11 suites/142 tests PASS | Scope/router, cobertura, Truth, autoridad/readiness, cambios críticos, atomicidad de handoff y sesiones con dobles | DB, aislamiento entre organizaciones real, delivery/proveedor |
| KAN-151 unit | 2 suites/71 tests PASS | Experience: 58; storage: 13 | Integración con KAN-150 ni idempotencia del servidor real |
| KAN150A unit | 2 suites/57 tests PASS | Experience: 46; LiveUnderstanding: 11 | Persistencia B ni calidad del modelo |
| Playwright KAN-151 | 15/15 PASS | Navegador Chromium, API simulada, reload/retry/dobleclick/uncertain/failure | Journey Startería completo ni producción |
| P01–P07 | 7 observaciones sintéticas completadas | FAQ, mapeo, scope, Home, update, impact, reconstruction | Exposición real ni efectos de DB |
| P08/P09 aislados | 2/2 observaciones PASS | Fallo finalización y selección explícita snapshot antiguo | Semántica aprobada del snapshot ni transacción real en DB |
| Intento de descubrimiento ampliado | 200 suites:146 PASS/53 FAIL/1 SKIP; 1284 tests:1272 PASS/11 FAIL/1 SKIP | Limitaciones del entorno y ejecución accidental más amplia | No se considera cierre de suite global ni 11 defectos del producto |

Las cuatro selecciones previstas suman ** 405 tests en 27 suites**. No se suman a la ejecución ampliada, que contiene duplicados. El intento ampliado ocurrió al heredar la configuración/workspace Vitest: seleccionó el backend completo en vez de las dos observaciones aisladas. Se preserva `expanded-discovery-attempt.log`; fallos de carga por Prisma generado ausente, DATABASE_URL no configurada y binding nativo bcrypt faltante, más 11 tests de users que fallan por Prisma. No se generó Prisma ni se conectó/migró una base para forzar PASS. Luego se corrigió sólo la configuración de auditoría y se ejecutaron P08/P09 aislados. Otros intentos de arranque/config están conservados, no ocultados como PASS.

Las pruebas seleccionadas usan dobles de servicios/repositorios; el PostgreSQL local existente no se utilizó. No se enviaron emails ni se ejecutó proveedor IA. Se inició únicamente Vite local para la UI con interceptación de API, y se cerró al finalizar. Herramientas pueden crear cachés locales ignoradas; verificación final comprueba HEAD/status y hashes de cambios preexistentes, no promete detectar cada archivo ignorado.

Evidencia: `front-baseline.log`, `backend-baseline.log`, `wip-150.log`, `wip-151.log`, `browser-results.json`, `browser-provenance.json`, `probes.json`, `route-confirmation-observations.log`. Los PASS históricos citados por actas KAN-144/SF se consideran documentación, no pruebas repetidas en esta auditoría.

## Evaluación de las 13 dimensiones

| Dimensión | Conclusión | Base |
|---|---|---|
| 1 Integridad lógica | Funciones Core coherentes; target completo requiere cerrar fronteras | F-05/F-13/F-19–21/F-23 |
| 2 Continuidad de journeys | 114F fuerte; InitialReview y post Step 4 incompletos | F-04/F-13/D-05 |
| 3 Handoffs | Persistencia/autoridad de assignment presentes; revisión mapea mal semántica | F-05/E07 |
| 4 Dominio/estados | Accept!=Start y presented!=completed; activo reto abierto | F-19; resolver de cierre |
| 5 Roles/autoridad | Scopes nuevos conviven con rutas globales | F-01–03/F-17 |
| 6 Razonamiento IA | Límites declarados; fallback sin modo público; calidad no probada | F-07/F-14/F-22 |
| 7 Datos/evidencia/provenance | Truth/snapshots valiosos; estimación marcada como realized y propagación débiles | F-05/F-08/F-10/F-18 |
| 8 UX/modelo mental | Recovery Entry mejora; FAQ/Overview/Step 4 pendientes | F-06/F-11/F-16 |
| 9 Errores/idempotencia | Por frontera, no universal; F-04 y error de aprendizaje | F-04/F-12/P08 |
| 10 Cohesión técnica | Rutas de distintas generaciones y overlays compartidos; SF diverge | D-06/D-12/ADR-005 |
| 11 Seguridad/permisos | No certificable por tres S1 confirmados | F-01–03/F-15 |
| 12 Pruebas | 405 seleccionadas +15 browser útiles; runtime completo ausente | Logs y límites de entorno |
| 13 Valor/diferenciación | Potencial:decisión trazable/continuidad; resultado comparativo UNKNOWN | F-22/E2E-10 |

## Valor tangible y alternativas

La diferenciación potencial respecto de chat+documentos reside en conservar fuente, versión, autoridad, estado del ciclo y decisión, y respecto de una herramienta de tareas en ligar actividad con evidencia y resultado. El código contiene piezas para ello:Truth, DecisionRequest, snapshots, assignments y PortfolioLearning. F-05/F-08/F-10 afectan precisamente esa promesa; no son sólo problemas de presentación.

No se compararon productos comerciales actuales ni se emitió recomendación de compra. No hay estudio de usuarios/mercado en esta auditoría. El objetivo de evaluación propuesto es decidir si el output cambia una decisión y reduce reprocesamiento conservando evidencia; no puntuar el estilo de una respuesta como prueba de valor.

## Límites de certificación

- Repositorio esperado no accesible; se auditó el remoto alternativo identificado con evidencia.
- Sin entorno desplegado autenticado, DB desechable configurada, delivery real ni proveedor IA habilitado para esta auditoría. No se declara PASS de producción ni de todos los endpoints.
- Original Bere y fuente de 31 iniciativas no disponibles; no se reconstruyen sus resultados inventando datos.
- Contratos candidatos, freezes visuales y flags documentados no equivalen a runtime activo.
- No se ejecutó build como sustituto del análisis funcional ni se midió cobertura global de código.
- Se inspeccionaron todas las áreas obligatorias a nivel de rutas/modelos y los caminos críticos descritos; no se afirma revisión exhaustiva de cada línea, endpoint o dependencia.

## Cierre y navegación

Trabajo de auditoría concluido con alcance y limitaciones explícitas. **Sin correcciones implementadas, sin cambios de autoridad, sin commit/merge/push/migraciones.** Decisiones y reparaciones se entregan para revisión posterior. No hay aprobación de merge integral.

1. [STARTERIA_REPOSITORY_DISCOVERY_REPORT_v0.1.md](STARTERIA_REPOSITORY_DISCOVERY_REPORT_v0.1.md)
2. [STARTERIA_TARGET_MODEL_MANIFEST_RECONCILED_v0.1.md](STARTERIA_TARGET_MODEL_MANIFEST_RECONCILED_v0.1.md)
3. [STARTERIA_E2E_AUDIT_REPORT_v0.1.md](STARTERIA_E2E_AUDIT_REPORT_v0.1.md)
4. [STARTERIA_E2E_FLOW_COVERAGE_MATRIX_v0.1.md](STARTERIA_E2E_FLOW_COVERAGE_MATRIX_v0.1.md)
5. [STARTERIA_E2E_FINDINGS_REGISTER_v0.1.md](STARTERIA_E2E_FINDINGS_REGISTER_v0.1.md)
6. [STARTERIA_BERE_FEEDBACK_TRACEABILITY_v0.1.md](STARTERIA_BERE_FEEDBACK_TRACEABILITY_v0.1.md)
7. [STARTERIA_TARGET_DECISION_REGISTER_v0.1.md](STARTERIA_TARGET_DECISION_REGISTER_v0.1.md)
8. [STARTERIA_PRE_MERGE_REPAIR_RECOMMENDATIONS_v0.1.md](STARTERIA_PRE_MERGE_REPAIR_RECOMMENDATIONS_v0.1.md)
