# STARTERIA_E2E_FINDINGS_REGISTER v0.1

**Fecha:** 2026-10-14 · **Modo:** auditoría autónoma, producto read-only, sin implementación.

## Registro consolidado

** 23 findings:** 13 CONFIRMED, 5 NEEDS_EVIDENCE, 1 LIKELY, 4 CONTRACT_CONFLICT. Severidad y confianza son ejes independientes. No se registra S0 por falta de una reproducción que justifique esa severidad; los S1 confirmados y decisiones P0 bastan para bloquear readiness integral.

**Contexto técnico común:** repositorio `DarkCodePE/plataforma-starteria`, rama de integración `main`, commit `f365800288bd74d83985bfbd00e1b9bd6d74eeda`; lectura desde `eval/KAN-145-question-quality` en ese mismo HEAD. Probes ejecutados contra los mismos módulos sin cambios en `feat/KAN-151-s1a-known-session@bf66e2b…`. Los casos WIP especifican su rama y artefacto. Evidencia del código no prueba exposición desplegada.

`FACT`: observado en fuente/prueba. `INFERENCE`: conclusión razonada. `HYPOTHESIS`: causa o comportamiento por probar. `UNKNOWN`: no accesible/no medido. Un finding CONFIRMED puede contener causa probable como inferencia; su confirmación se limita al comportamiento descrito.

| ID | Título | Severidad | Verificación | Prioridad |
|---|---|---|---|---|
| F-01 | La ausencia de portfolio:read abre el scope global | S1_CRITICAL | CONFIRMED | P0 |
| F-02 | Portfolio Home carga asignaciones de handoff sin scope organizacional | S1_CRITICAL | CONFIRMED | P0 |
| F-03 | Operaciones Portfolio por ID no comprueban membresía del recurso | S1_CRITICAL | CONFIRMED | P0 |
| F-04 | La confirmación de ruta puede dejar un proyecto creado y una reserva irrecuperable | S2_HIGH | CONFIRMED | P0 |
| F-05 | Una actividad y una hipótesis se promueven a decisión y hechos conocidos | S2_HIGH | CONFIRMED | P0 |
| F-06 | El Copilot de revisión no explica “aprobaciones internas” | S3_MEDIUM | CONFIRMED | P1 |
| F-07 | Fallback de IA conserva forma de éxito sin identificar el modo al usuario | S2_HIGH | CONFIRMED | P1 |
| F-08 | Cambiar el mandato Portfolio no invalida sus derivados desde el CRUD | S2_HIGH | CONFIRMED | P0 |
| F-09 | La reconstrucción confunde tradeoffs con contradicciones | S2_HIGH | CONFIRMED | P1 |
| F-10 | Una estimación validada puede pasar a realized sin medición operacional | S2_HIGH | CONFIRMED | P0 |
| F-11 | Step 4 conserva etiquetas de presentación que ocultan su decisión | S3_MEDIUM | CONFIRMED | P1 |
| F-12 | Un error al leer aprendizaje se presenta como lista vacía | S3_MEDIUM | CONFIRMED | P1 |
| F-13 | El cierre metodológico no completa el ciclo operativo de Benefit Tracking | S2_HIGH | CONFIRMED | P0 para promesa de Target completo |
| F-14 | Fidelidad de cifras y duraciones de Bere todavía sin reproducción del modelo | S2_HIGH | NEEDS_EVIDENCE | P1, escalar a P0 si se reproducen cifras falsas materiales |
| F-15 | Privacidad, borrado y retención no certificados en todo el recorrido | S2_HIGH | NEEDS_EVIDENCE | P1 antes de piloto confidencial |
| F-16 | Valor de Overview, Step 0 y carga de preguntas todavía no validados | S3_MEDIUM | LIKELY | P1 |
| F-17 | Pérdida de owner y revocación no verificadas como journey completo | S2_HIGH | NEEDS_EVIDENCE | P1; bloquear cierre del E2E hasta evidencia |
| F-18 | Reevaluación de decisiones tras modificar evidencia pendiente de prueba | S2_HIGH | NEEDS_EVIDENCE | P1 |
| F-19 | Reto activo con o sin iniciativa: Core candidato y estados vigentes divergen | S2_HIGH | CONTRACT_CONFLICT | P0 estructural |
| F-20 | Portfolio personal/equipo y entitlement no tienen autoridad completa acordada | S2_HIGH | CONTRACT_CONFLICT | P0 para incluir E2E-03 como capacidad final |
| F-21 | Initiative-first universal no coincide con continuación pública aprobada | S2_HIGH | CONTRACT_CONFLICT | P0 estructural |
| F-22 | Valor diferencial y exactitud del Target con proveedor real no demostrados | S3_MEDIUM | NEEDS_EVIDENCE | P1 para piloto; P0 para afirmaciones comerciales no probadas |
| F-23 | El delta visual KAN-145 mantiene abierto el opt-in Guided antes de suficiencia | S3_MEDIUM | CONTRACT_CONFLICT | P0 para promover ese delta |

## F-01 — La ausencia de portfolio:read abre el scope global

- **Categoría:** Seguridad / autorización.
- **Severidad / estado:** `S1_CRITICAL` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio/portfolio-scope.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio-scope.ts:30>); [backend/modules/portfolio/portfolio.router.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio.router.ts:44>); P03 en [probes.json](probes.json).
- **Esperado:** Denegar o devolver un conjunto vacío cuando falta permiso; limitar por organización cuando procede.
- **Observado/proyectado:** FACT: resolvePortfolioReadScope devuelve all:true para un usuario no admin con permissions vacío; strategicFrontWhereForScope produce {}. GET strategic-fronts sólo exige autenticación en esta ruta.
- **Causa probable:** Rama de compatibilidad permisiva para usuarios sin portfolio:read.
- **Impacto negocio/usuario:** Un usuario autenticado puede recibir frentes de organizaciones ajenas; afecta confidencialidad y confianza enterprise. No se ha realizado una lectura de datos reales.
- **Componentes:** Portfolio scope, router, controller, listados.
- **Contratos relacionados:** Core v0.2 autoridad humana; ADR-004 autorización server-side por scope.
- **ADR/decisión:** No: aplicar autoridad ya definida.
- **Prioridad:** P0.
- **Recomendación:** Cambiar la política a denegación por defecto y comprobar explícitamente usuarios sin permiso, sin membresía, grant revocado y dos organizaciones mediante HTTP con fixtures aisladas.

## F-02 — Portfolio Home carga asignaciones de handoff sin scope organizacional

- **Categoría:** Seguridad / lectura agregada.
- **Severidad / estado:** `S1_CRITICAL` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio/portfolio-home.read-service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio-home.read-service.ts:219>) y :285; P04 en [probes.json](probes.json).
- **Esperado:** Cada sección del Home debe usar el mismo conjunto de organizaciones autorizado.
- **Observado/proyectado:** FACT: getHome recibe scope org-A, pero loadHandoffAssignments usa findMany sin where. El doble de repositorio devuelve una asignación org-B y el servicio la publica con rejectionReason.
- **Causa probable:** El scope se aplica a frentes, pero no se propaga al lector de proyecciones de handoff.
- **Impacto negocio/usuario:** Exposición de participantes, estado y razones privadas de rechazo entre organizaciones.
- **Componentes:** PortfolioHomeReadService, PortfolioHandoffProjection, Home.
- **Contratos relacionados:** ADR-004; PH0 Home read model; Activation v0.2.
- **ADR/decisión:** No.
- **Prioridad:** P0.
- **Recomendación:** Filtrar mediante relaciones canónicas del target y validar cada colección agregada. Incluir asignaciones sin target resoluble y datos huérfanos; no confiar en filtrado frontend.

## F-03 — Operaciones Portfolio por ID no comprueban membresía del recurso

- **Categoría:** Seguridad / mutación.
- **Severidad / estado:** `S1_CRITICAL` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio/portfolio.router.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio.router.ts:66>); [backend/modules/portfolio/portfolio.controller.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio.controller.ts:84>); [backend/modules/portfolio/portfolio.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio.service.ts:56>); [backend/modules/auth/auth.middleware.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/auth/auth.middleware.ts:143>); [backend/modules/portfolio-handoff/portfolio-handoff-invitation.router.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio-handoff/portfolio-handoff-invitation.router.ts:75>).
- **Esperado:** Una capacidad global no debe habilitar mutaciones de recursos ajenos; comprobar actor, organización y grant vigente.
- **Observado/proyectado:** FACT estático: updateStrategicFront y updateChallenge reciben ID/input, sin actor ni comprobación scoped. El middleware comprueba portfolio:write. Revocar invitación por assignmentId tampoco pasa actor al servicio.
- **Causa probable:** Convivencia de autorización antigua por rol y nueva autorización scoped de 114F sin adopción uniforme.
- **Impacto negocio/usuario:** Alteración de estrategia o invitaciones de otra organización por usuarios con permiso global. Confirmada la ausencia del control en la cadena inspeccionada; explotación HTTP/producción no ejecutada.
- **Componentes:** Portfolio CRUD; delivery/revoke de handoff; middleware.
- **Contratos relacionados:** ADR-004; permisos de Core.
- **ADR/decisión:** No para cerrar bypass; sí si se pretende cambiar el modelo aprobado.
- **Prioridad:** P0.
- **Recomendación:** Reutilizar una política server-side por recurso y transacción. Probar write org-A contra IDs org-B y revocación concurrente; conservar controles robustos ya presentes en 114F.

## F-04 — La confirmación de ruta puede dejar un proyecto creado y una reserva irrecuperable

- **Categoría:** Recuperación / idempotencia.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/initial-review/route-confirmation.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/route-confirmation.service.ts:32>); P08 en [route-confirmation-observations.log](route-confirmation-observations.log) y [route-confirmation.audit.test.ts](route-confirmation.audit.test.ts).
- **Esperado:** Un reintento debe recuperar el proyecto creado o completar una operación atómica sin duplicación.
- **Observado/proyectado:** FACT reproducido: routeConfirmation pending se crea; create Project termina; falla la transacción final. El retry no conoce createdProjectId, choca con unicidad y devuelve ROUTE_CONFIRMATION_IN_PROGRESS persistentemente en esta rama.
- **Causa probable:** Reserva, creación de Project y finalización tienen límites transaccionales distintos sin compensación/reconciliación de esa falla.
- **Impacto negocio/usuario:** Pérdida de continuidad tras la revisión inicial; proyecto existente no vinculado al recorrido.
- **Componentes:** RouteConfirmationService; InitialReview; Project.
- **Contratos relacionados:** Core continuidad/provenance; contrato de confirmación humana de iniciativa.
- **ADR/decisión:** No; decisión técnica de recuperación documentada.
- **Prioridad:** P0.
- **Recomendación:** Diseñar una transacción común o un estado durable recuperable con vínculo al proyecto. Inyectar fallo tras cada escritura y comprobar recuperación con DB aislada. No eliminar el proyecto para ocultar el fallo.

## F-05 — Una actividad y una hipótesis se promueven a decisión y hechos conocidos

- **Categoría:** Dominio / semántica IA / provenance.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/initial-review/adaptive-core.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/adaptive-core.ts:40>) y :141/:175; P02 en [probes.json](probes.json); [ai-service/agents/initial_reviewer.py](<C:/Users/User/proyect-starteria/starteria-KAN-145/ai-service/agents/initial_reviewer.py:73>).
- **Esperado:** Separar actividad para obtener evidencia, alternativa a decidir, hipótesis e información declarada.
- **Observado/proyectado:** FACT reproducido: “Realizar entrevistas con 10 clientes” acaba en decisions y upcomingDecision. “Hipótesis: reducir abandono 20%” acaba en knownFacts. El generador define nextRecommended Step como siguiente trabajo, no una decisión organizacional.
- **Causa probable:** Conversión directa de strings del InitialReview a campos semánticos del MasterContext.
- **Impacto negocio/usuario:** Step 0 puede heredar una falsa decisión o certeza y orientar preguntas y gates sobre ella; reproduce BERE-10.
- **Componentes:** InitialReview → Adaptive Core context; Brief/Step 0.
- **Contratos relacionados:** Core inv.03/05/09; separación evidencia/hipótesis; BERE-T07.
- **ADR/decisión:** No para corregir mapeo; ADR sólo si se cambia semántica de decisión.
- **Prioridad:** P0.
- **Recomendación:** Introducir validación semántica del handoff y conservar tipo/origen del dato. Mantener la actividad como próxima acción y pedir decisión explícita cuando falte, sin inventarla.

## F-06 — El Copilot de revisión no explica “aprobaciones internas”

- **Categoría:** UX / comprensión del lenguaje.
- **Severidad / estado:** `S3_MEDIUM` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [front/src/features/initiative-review/services/assistantFaq.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/features/initiative-review/services/assistantFaq.ts:15>); [front/src/features/initiative-review/services/assistantOrchestrator.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/features/initiative-review/services/assistantOrchestrator.ts:35>); P01 en [probes.json](probes.json).
- **Esperado:** Explicar términos que el propio producto introduce, con ejemplo y límite contextual.
- **Observado/proyectado:** FACT reproducido con la pregunta exacta BERE-T02: devuelve “No tengo una respuesta directa…” y remite a Agregar contexto/sponsor; el propio orquestador usa el término.
- **Causa probable:** FAQ por palabras clave sin cobertura del vocabulario emitido.
- **Impacto negocio/usuario:** Bloqueo de comprensión y pérdida de confianza antes de Step 0.
- **Componentes:** assistantFaq, assistantOrchestrator; revisión inicial con chat habilitado.
- **Contratos relacionados:** Core claridad funcional; feedback BERE-04, evidencia no contractual.
- **ADR/decisión:** No.
- **Prioridad:** P1.
- **Recomendación:** Alinear vocabulario emitido y explicaciones contextuales; probar la pregunta literal y paráfrasis sin transformar la duda en nuevo dato de negocio.

## F-07 — Fallback de IA conserva forma de éxito sin identificar el modo al usuario

- **Categoría:** IA / error / transparencia.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/initial-review/resilient-generator.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/resilient-generator.ts:23>); [backend/modules/initial-review/initial-review.router.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/initial-review.router.ts:27>); [backend/modules/initial-review/initial-review.types.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/initial-review.types.ts:67>).
- **Esperado:** Distinguir análisis de proveedor, salida determinista degradada y error, preservando utilidad sin aparentar una capacidad no ejecutada.
- **Observado/proyectado:** FACT: mode=real captura cualquier fallo y retorna fallback; registra warn servidor. GeneratedReview no incluye modo/degradación. Sin variable, el generador es mock. No se conoce el modo desplegado.
- **Causa probable:** Resiliencia diseñada sólo como continuidad estructural y observabilidad interna.
- **Impacto negocio/usuario:** Una respuesta aparentemente analítica puede ser plantilla; afecta evaluación de valor y diagnóstico BERE-07/12.
- **Componentes:** InitialReview generator, API output, UI de revisión.
- **Contratos relacionados:** Core límites IA/provenance; PRD de revisión subordinado a Core.
- **ADR/decisión:** No para transparencia; definir producto de degradación.
- **Prioridad:** P1.
- **Recomendación:** Exponer procedencia y degradación con copy comprensible, limitar conclusiones del fallback y medir frecuencia. Evaluar real, mock y fallo por separado.

## F-08 — Cambiar el mandato Portfolio no invalida sus derivados desde el CRUD

- **Categoría:** Versionado / continuidad.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio/portfolio.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio.service.ts:138>) y :56; P05 en [probes.json](probes.json); [backend/modules/adaptive-core/adaptive-core.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/adaptive-core/adaptive-core.service.ts:1337>).
- **Esperado:** Cambios materiales de objetivo/KPI/alcance deben conservar historia y activar requires_review o una evaluación de cambio en outputs dependientes.
- **Observado/proyectado:** FACT estático: updateChallenge/updateStrategicFront actualizan la fila sin publicar cambio ni evaluar dependencias. P05 observa únicamente update. El payload constraints del probe usa any: la confirmación no depende de que el endpoint acepte ese campo; título es campo soportado. Existe registerCriticalChange, pero no está conectado en este camino.
- **Causa probable:** Mutación de Portfolio y ciclo adaptativo se mantienen como mecanismos separados.
- **Impacto negocio/usuario:** Iniciativas y paquetes pueden parecer vigentes tras cambiar el mandato que los sustentaba.
- **Componentes:** PortfolioService; Challenge/StrategicFront; Adaptive Core critical changes.
- **Contratos relacionados:** Core inv.08/10; herencia de restricciones; PH0.
- **ADR/decisión:** No para propagación; decisión de qué cambios son materiales.
- **Prioridad:** P0.
- **Recomendación:** Definir evento/versionado de mandato y matriz de dependencias. Probar cambio material, cambio cosmético y dos ciclos activos sin reescribir outputs históricos.

## F-09 — La reconstrucción confunde tradeoffs con contradicciones

- **Categoría:** IA / importación / gates retrospectivos.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/reconstruction/reconstruction.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/reconstruction/reconstruction.service.ts:44>); P07 en [probes.json](probes.json).
- **Esperado:** Relacionar cada evidencia con su claim, métrica, alcance y periodo antes de declarar contradicción.
- **Observado/proyectado:** FACT reproducido: “Abandono bajó 20%” y “Coste subió 5%” se cruzan como contradicción y se pide explicar por qué no coinciden. Son compatibles; el servicio cruza supports y contradicts sin identidad de claim.
- **Causa probable:** Producto cartesiano de evidencias por polaridad global.
- **Impacto negocio/usuario:** Reentrada y preguntas innecesarias para trabajo importado; mala lectura de un resultado con costes y beneficios.
- **Componentes:** ReconstructionService; proposed retrospective gates.
- **Contratos relacionados:** Core inv.11; BERE-T11; distinción evidencia/interpretación.
- **ADR/decisión:** No.
- **Prioridad:** P1.
- **Recomendación:** Agrupar por claim y condiciones comparables; representar tradeoffs por separado. Conservar que la reconstrucción es USER_DECLARED y no valida ni reinicia automáticamente el trabajo.

## F-10 — Una estimación validada puede pasar a realized sin medición operacional

- **Categoría:** Evidencia / impacto.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/truth/truth.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/truth/truth.service.ts:358>) y :463; [front/prisma/schema.prisma](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/prisma/schema.prisma:1337>); P06 en [probes.json](probes.json).
- **Esperado:** L5 exige resultado observado en operación con fuente y condiciones; L6 exige atribución defendible y autoridad competente.
- **Observado/proyectado:** FACT reproducido en servicio: un ImpactAssertion de “Ahorro anual estimado” con valueJson.estimate=81000 EUR llega a realized usando validación supported y fuente user_input. La guarda comprueba vínculos, no medición operacional adicional.
- **Causa probable:** La misma condición de validación se reutiliza para validated y realized.
- **Impacto negocio/usuario:** Reporting puede presentar estimaciones como beneficios obtenidos. No se ha comprobado que una UI productiva ejecute esta promoción en un cliente real.
- **Componentes:** TruthService.transitionImpact; ImpactAssertion; reporting.
- **Contratos relacionados:** Core v0.2 inv.12, L5/L6.
- **ADR/decisión:** No para impedir promoción; decisión de contrato de métricas operativas.
- **Prioridad:** P0.
- **Recomendación:** Separar validación de hipótesis y observación de beneficio. Exigir medida, periodo, fuente operacional, responsable y criterio de atribución correspondiente al nivel declarado.

## F-11 — Step 4 conserva etiquetas de presentación que ocultan su decisión

- **Categoría:** UX / modelo mental.
- **Severidad / estado:** `S3_MEDIUM` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [front/src/app/pages/InitiativeOverviewPage.tsx](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/app/pages/InitiativeOverviewPage.tsx:30>); [backend/modules/initial-review/route-preview.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/route-preview.ts:15>); [front/src/app/pages/ProjectHomePage.tsx](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/app/pages/ProjectHomePage.tsx:61>).
- **Esperado:** Explicar Step 4 como paquete para decidir y su continuación; una presentación puede ser un formato del resultado.
- **Observado/proyectado:** FACT estático: Overview/preview usan “Presentar propuesta” y entrega tipo informe/pitch. Hay DecisionRequest, Decision y completion routing reales; no se afirma que Step 4 sea sólo un deck.
- **Causa probable:** Copy legacy no reconciliado con dominio adaptativo posterior.
- **Impacto negocio/usuario:** El usuario puede optimizar una presentación y no la suficiencia para decidir; BERE-13 no queda resuelto por Entry.
- **Componentes:** Overview, ProjectHome, route-preview, Step 4.
- **Contratos relacionados:** Core inv.06/09/12; BERE-13.
- **ADR/decisión:** No.
- **Prioridad:** P1.
- **Recomendación:** Unificar objetivo, CTA, output y criterio de éxito con la decisión y ruta posterior; validar comprensión con usuarios.

## F-12 — Un error al leer aprendizaje se presenta como lista vacía

- **Categoría:** Errores / observabilidad / aprendizaje.
- **Severidad / estado:** `S3_MEDIUM` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio/portfolio-home.read-service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/portfolio-home.read-service.ts:253>).
- **Esperado:** Distinguir ausencia de aprendizajes de fallo de lectura y permitir recuperación.
- **Observado/proyectado:** FACT: loadLearnings captura errores y retorna []; el consumidor recibe la misma colección que cuando no hay datos. Sí existe PortfolioLearning y una proyección de aprendizaje.
- **Causa probable:** Degradación tolerante sin estado de sección ni señal visible al cliente.
- **Impacto negocio/usuario:** Pérdida silenciosa de memoria organizacional percibida y decisiones con una vista incompleta.
- **Componentes:** PortfolioHomeReadService.loadLearnings; Home.
- **Contratos relacionados:** Core aprendizaje/trazabilidad; PH0 read model.
- **ADR/decisión:** No.
- **Prioridad:** P1.
- **Recomendación:** Devolver estado parcial y error correlacionable, preservar datos previos si son válidos y ofrecer reintento sin afirmar ausencia de aprendizaje.

## F-13 — El cierre metodológico no completa el ciclo operativo de Benefit Tracking

- **Categoría:** Cobertura de producto / continuidad.
- **Severidad / estado:** `S2_HIGH` / `CONFIRMED`.
- **Evidencia técnica y reproducción:** [backend/modules/adaptive-core/initiative-completion.resolver.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/adaptive-core/initiative-completion.resolver.ts:58>); [front/prisma/schema.prisma](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/prisma/schema.prisma:1048>) y :1337; [front/src/app/routes.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/app/routes.ts:99>).
- **Esperado:** Después de la decisión, mantener responsable, horizonte de beneficio, medida operacional y revisión/atribución L5/L6.
- **Observado/proyectado:** FACT delimitado al código accesible: existen rutas de continuación, ImplementationHandoff, ScalingHandoff, ClosureSummary, ImpactAssertion y etiqueta benefit_tracking; no se localizó un agregado/ciclo completo de seguimiento con revisión operacional/atribución L6. El resolver owner_completed completa una iniciativa autónoma tras Step 4, mientras Portfolio queda presented. Se clasifica el ciclo completo DEFINED_NOT_IMPLEMENTED, no se niegan esas piezas existentes.
- **Causa probable:** Cierre metodológico y derivación de handoff implementados antes del sistema completo de realización de beneficios.
- **Impacto negocio/usuario:** La promesa E2E hasta beneficios y aprendizaje sostenido queda incompleta aunque Steps funcione.
- **Componentes:** Adaptive Core completion/continuation; ImpactAssertion; superficies post-Step 4.
- **Contratos relacionados:** Core v0.2 inv.12; catálogo E2E; G-14.
- **ADR/decisión:** Sí si se modifica la semántica/niveles; no para implementar lo ya definido.
- **Prioridad:** P0 para promesa de Target completo.
- **Recomendación:** Cerrar contrato del ciclo postdecisión con medida, owner, revisiones y eventos hacia Portfolio. Mantener “completado metodológicamente” separado de “beneficio demostrado”.

## F-14 — Fidelidad de cifras y duraciones de Bere todavía sin reproducción del modelo

- **Categoría:** IA / fidelidad.
- **Severidad / estado:** `S2_HIGH` / `NEEDS_EVIDENCE`.
- **Evidencia técnica y reproducción:** [ai-service/agents/initial_reviewer.py](<C:/Users/User/proyect-starteria/starteria-KAN-145/ai-service/agents/initial_reviewer.py:233>) y :256; [backend/modules/initial-review/ai-generator.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initial-review/ai-generator.ts:49>); documento Bere BERE-08/09.
- **Esperado:** Conservar cifras, unidades y alcance del input; no añadir plazos sin fuente; señalar lo truncado o no conocido.
- **Observado/proyectado:** FACT: el input original se recorta por límite de longitud; el prompt prohíbe inventar. UNKNOWN: no hay traza original ni ejecución del proveedor que reproduzca “4–6 semanas” o las cifras perdidas de Bere.
- **Causa probable:** HYPOTHESIS: reducción semántica, truncamiento o esquema sin trazabilidad por afirmación; ninguna causa adjudicada al incidente original.
- **Impacto negocio/usuario:** Si ocurre, altera el caso de negocio y decisiones sobre esfuerzo/valor.
- **Componentes:** AI initial reviewer; guardrails; input/context extraction.
- **Contratos relacionados:** Core inv.05/07; BERE-T04/T05.
- **ADR/decisión:** No.
- **Prioridad:** P1, escalar a P0 si se reproducen cifras falsas materiales.
- **Recomendación:** Ejecutar un corpus con cifras y tiempos conocidos, proveedor/versión/prompt registrados; comprobar preservación y abstención. No usar fixtures con respuestas futuras para mejorar el primer análisis.

## F-15 — Privacidad, borrado y retención no certificados en todo el recorrido

- **Categoría:** Seguridad / privacidad.
- **Severidad / estado:** `S2_HIGH` / `NEEDS_EVIDENCE`.
- **Evidencia técnica y reproducción:** [backend/modules/initiative-pdfs/public-pdf.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initiative-pdfs/public-pdf.service.ts:118>) y :266; [backend/modules/initiative-pdfs/storage.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/initiative-pdfs/storage.service.ts:84>); BERE-02/T08.
- **Esperado:** Explicar qué se guarda/envía, minimizar información confidencial y comprobar eliminación/retención de originales, derivados y proveedor.
- **Observado/proyectado:** FACT: PDF público guarda original antes de extracción, enforceRedaction=true, TTL30min de runs y eliminación al evict/fallo. La limpieza de expirados depende de llamadas; UNKNOWN retención efectiva de proveedor, backups y configuración desplegada. Aviso de no subir datos sensibles visible en Entry móvil.
- **Causa probable:** No hay evidencia operacional de extremo a extremo disponible; redacción de PII no demuestra anonimización de secretos de negocio.
- **Impacto negocio/usuario:** Usuarios pueden sobreestimar la protección del contenido empresarial.
- **Componentes:** Public PDF, storage, ai-service, Entry/auth.
- **Contratos relacionados:** Core provenance/límites; BERE-02; políticas operativas por verificar.
- **ADR/decisión:** Decisión de retención/privacidad; no se emite juicio legal.
- **Prioridad:** P1 antes de piloto confidencial.
- **Recomendación:** Prueba con datos sintéticos de anonimización/borrado y reinicio, revisar política real del proveedor y comunicar límites por superficie. No afirmar incumplimiento legal sin evidencia.

## F-16 — Valor de Overview, Step 0 y carga de preguntas todavía no validados

- **Categoría:** Experiencia / valor.
- **Severidad / estado:** `S3_MEDIUM` / `LIKELY`.
- **Evidencia técnica y reproducción:** [front/src/app/pages/InitiativeOverviewPage.tsx](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/src/app/pages/InitiativeOverviewPage.tsx:332>); tests de Overview/MissionReview en [front-baseline.log](front-baseline.log); BERE-05/06/07/11/12.
- **Esperado:** Entender en 30s objetivo, incertidumbre, decisión y siguiente acción; cada pregunta debe tener utilidad y aceptar desconocimiento.
- **Observado/proyectado:** FACT: CTA “Revisar mi misión y empezar” permanece; tests comprueban interacción. INFERENCE: la combinación de misión/recorrido/revisión puede seguir exigiendo interpretación. No se ejecutó prueba real de usuario ni comparación de alternativas IA.
- **Causa probable:** Terminología interna y diferencia entre análisis útil y recapitulación aún no contrastadas con usuarios representativos.
- **Impacto negocio/usuario:** Fricción de activación y poco valor visible aunque los estados sean técnicamente correctos.
- **Componentes:** Overview; MissionReview; Step 0; review/chat; preguntas.
- **Contratos relacionados:** Core inv.06/09; ADR-002 sólo en Entry; feedback Bere.
- **ADR/decisión:** No para claridad; decisión de éxito experiencial.
- **Prioridad:** P1.
- **Recomendación:** Sesiones moderadas sin ayudas: comprensión30s, utilidad de cada pregunta, diferencia actividad/decisión y valor del output. No extender el límite de preguntas de Entry a todos los Steps sin contrato.

## F-17 — Pérdida de owner y revocación no verificadas como journey completo

- **Categoría:** Permisos / continuidad.
- **Severidad / estado:** `S2_HIGH` / `NEEDS_EVIDENCE`.
- **Evidencia técnica y reproducción:** [backend/modules/portfolio-handoff/application/portfolio-handoff-response.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio-handoff/application/portfolio-handoff-response.service.ts:22>); [backend/modules/portfolio-entry-continuation/portfolio-setup-continuity-write.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio-entry-continuation/portfolio-setup-continuity-write.service.ts:152>); tests seleccionados de handoff.
- **Esperado:** Owner vigente al aceptar/iniciar/decidir; revocación concurrente segura y reasignación con historial.
- **Observado/proyectado:** FACT: startAssignedWork verifica owner y expectedVersion; 114F bloquea filas de membership/grant durante commit. UNKNOWN: pérdida de owner después de inicio, reasignación y continuación hasta Decision/beneficios en DB y navegador real.
- **Causa probable:** Controles fuertes por servicio no equivalen a prueba de todos los cambios de rol entre subsistemas.
- **Impacto negocio/usuario:** Posibles iniciativas huérfanas o autoridad residual, todavía no reproducidas.
- **Componentes:** Assignments, OrganizationMember, Project team, DecisionAuthority.
- **Contratos relacionados:** Core autoridad/continuidad; Activation v0.2; ADR-004.
- **ADR/decisión:** Posible para política de reasignación y autoridad temporal.
- **Prioridad:** P1; bloquear cierre del E2E hasta evidencia.
- **Recomendación:** Ejecutar revoke/owner-change en cada transición con dos sesiones; verificar quién puede recuperar el trabajo y qué decisiones previas siguen vigentes.

## F-18 — Reevaluación de decisiones tras modificar evidencia pendiente de prueba

- **Categoría:** Evidencia / historia.
- **Severidad / estado:** `S2_HIGH` / `NEEDS_EVIDENCE`.
- **Evidencia técnica y reproducción:** [backend/modules/evidence/evidence.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/evidence/evidence.service.ts:48>); [front/prisma/schema.prisma](<C:/Users/User/proyect-starteria/starteria-KAN-145/front/prisma/schema.prisma:1279>); [backend/modules/adaptive-core/adaptive-core.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/adaptive-core/adaptive-core.service.ts:1588>).
- **Esperado:** Conservar el paquete usado para decidir y señalar cuando una modificación posterior afecta su validez sin reescribir historia.
- **Observado/proyectado:** FACT: existen snapshots de DecisionRequest/Decision y FK Restrict para evidencia con validaciones; no se afirma borrado libre de esa evidencia. El cambio de estado de Evidence no muestra propagación en el servicio inspeccionado. UNKNOWN efecto completo sobre decisión ya tomada, reporting y nuevos ciclos.
- **Causa probable:** Posible desconexión entre mutación de evidencia, truth validation y reevaluación de una decisión histórica.
- **Impacto negocio/usuario:** Confianza indebida en decisiones cuyo soporte cambió, si la hipótesis se confirma.
- **Componentes:** EvidenceService; TruthValidation; Decision snapshots; readiness.
- **Contratos relacionados:** Core inv.05/10; evidencia reproducible.
- **ADR/decisión:** Decisión sobre obsolescencia de decisión vs nueva decisión.
- **Prioridad:** P1.
- **Recomendación:** Probar modificación de estado y nueva evidencia contradictoria antes/después de decisión; verificar snapshot inmutable y señal needs_review sin destruir trazabilidad.

## F-19 — Reto activo con o sin iniciativa: Core candidato y estados vigentes divergen

- **Categoría:** Autoridad / dominio.
- **Severidad / estado:** `S2_HIGH` / `CONTRACT_CONFLICT`.
- **Evidencia técnica y reproducción:** [docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md>); [backend/modules/portfolio/challenge-state-machine.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/portfolio/challenge-state-machine.ts>); G-09 del catálogo.
- **Esperado:** Aplicar una sola semántica aprobada de activación y separar preparación, aceptación e inicio.
- **Observado/proyectado:** FACT documental: v0.3 candidata exige iniciativa seleccionada para reto activo; el modelo vigente conserva estados como activo_interno y activación/handoff diferido. No se aplica v0.3 como autoridad aprobada.
- **Causa probable:** Evolución del Core pendiente de promoción y reconciliación con Activation v0.2.
- **Impacto negocio/usuario:** Migración silenciosa cambiaría cobertura, activación y dashboards.
- **Componentes:** Challenge state machine; Activation; Coverage; Portfolio Home.
- **Contratos relacionados:** Core factual v0.2 vs v0.3 candidata; Activation v0.2; G-09.
- **ADR/decisión:** Sí — DECISION_REQUIRED D-03.
- **Prioridad:** P0 estructural.
- **Recomendación:** Comparar variante A (estado activo de preparación) y B (activo sólo con iniciativa), definir nombres/migración/compatibilidad y aprobar antes de cambiar invariantes.

## F-20 — Portfolio personal/equipo y entitlement no tienen autoridad completa acordada

- **Categoría:** Autoridad / producto.
- **Severidad / estado:** `S2_HIGH` / `CONTRACT_CONFLICT`.
- **Evidencia técnica y reproducción:** E2E-03/G-05; [doc/product-adr/ADR-004-authenticated-continuation-access-and-initiative-handoff-authority.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/product-adr/ADR-004-authenticated-continuation-access-and-initiative-handoff-authority.md>); [backend/modules/billing/entitlement.service.ts](<C:/Users/User/proyect-starteria/starteria-KAN-145/backend/modules/billing/entitlement.service.ts>).
- **Esperado:** El usuario puede organizar trabajo propio sin adquirir poderes corporativos por cantidad o pago.
- **Observado/proyectado:** FACT documental: E2E-03 propone Portfolio de equipo/área; Core candidato y ADRs describen autoridad corporativa/scoped. Billing no debe interpretarse como designación; no se ha aprobado aquí una nueva categoría.
- **Causa probable:** Superposición de empaquetado comercial, dominio Portfolio y rol organizacional.
- **Impacto negocio/usuario:** Riesgo de autoescalada conceptual o de prometer una experiencia aún no definida.
- **Componentes:** Mis iniciativas; Portfolio upgrade; entitlement; organization grants.
- **Contratos relacionados:** E2E-03 propuesta, Core v0.3 candidata, ADR-004.
- **ADR/decisión:** Sí — DECISION_REQUIRED D-04.
- **Prioridad:** P0 para incluir E2E-03 como capacidad final.
- **Recomendación:** Decidir workspace personal/equipo separado o Portfolio organizacional con grant explícito; definir límites de lectura, write, invitados y transferencia de iniciativas.

## F-21 — Initiative-first universal no coincide con continuación pública aprobada

- **Categoría:** Autoridad / journey.
- **Severidad / estado:** `S2_HIGH` / `CONTRACT_CONFLICT`.
- **Evidencia técnica y reproducción:** E2E-01/G-01; [doc/product-adr/ADR-003-public-entry-registration-continuation-boundary.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/product-adr/ADR-003-public-entry-registration-continuation-boundary.md>); [docs/STARTERIA_AUTHORITY.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/docs/STARTERIA_AUTHORITY.md>); implementación 114F.
- **Esperado:** La selección de recorrido debe concordar con autoridad aprobada y conservar la necesidad original.
- **Observado/proyectado:** FACT: ADR-003 define default Portfolio-first y excepción Initiative explícita; 114F entregado es Portfolio-first y 133G excepción Initiative diferida. El catálogo propone primer recorrido founder initiative-first. Una ruta legacy existente no prueba continuidad 114F equivalente.
- **Causa probable:** Catálogo futuro combina intención de producto con capacidades/rutas de generaciones distintas.
- **Impacto negocio/usuario:** Expectativas de entrada y destino inconsistentes; usuario nuevo puede no tener membresía/grant para continuar.
- **Componentes:** Public Entry; 114D/E/F; Auth/Claim; InitialReview.
- **Contratos relacionados:** ADR-003/004/005; E2E-01; 133G diferido.
- **ADR/decisión:** Sí si cambia default; DECISION_REQUIRED D-02/D-05.
- **Prioridad:** P0 estructural.
- **Recomendación:** Mantener A default aprobado y B excepción explicitly requested; decidir provisión segura y cierre de 133G antes de prometer journey público universal.

## F-22 — Valor diferencial y exactitud del Target con proveedor real no demostrados

- **Categoría:** Evaluación IA / valor de negocio.
- **Severidad / estado:** `S3_MEDIUM` / `NEEDS_EVIDENCE`.
- **Evidencia técnica y reproducción:** E2E-10; actas KAN-144 con PROVIDER_RUNTIME=UNVERIFIED; [browser-provenance.json](browser-provenance.json); Bere BERE-07/12.
- **Esperado:** Entregar razonamiento útil y decisiones trazables con esfuerzo menor que alternativas comparables, medido sobre casos representativos.
- **Observado/proyectado:** FACT: pruebas actuales seleccionadas usan mocks/fixtures y el navegador usa API interceptada. UNKNOWN exactitud, latencia, coste, utilidad con clientes/partners y diferencia frente a chat+documentos/PM tool.
- **Causa probable:** La aceptación visual y tests deterministas no evalúan resultados de usuario ni desempeño de proveedor.
- **Impacto negocio/usuario:** No es defendible afirmar diferenciación o readiness comercial integral con esta evidencia.
- **Componentes:** Entrada IA; review; Portfolio reasoning; partner journey; analytics.
- **Contratos relacionados:** Core límites IA; E2E-10; KAN-144 freeze acotado.
- **ADR/decisión:** No; decisión de criterios de éxito de evaluación.
- **Prioridad:** P1 para piloto; P0 para afirmaciones comerciales no probadas.
- **Recomendación:** Comparar outputs a ciegas sobre mismos inputs con baseline sencillo, medir evidencia preservada, incertidumbre, decisión habilitada, tiempo/errores y recuperación; separar hipótesis comercial de defecto técnico.

## F-23 — El delta visual KAN-145 mantiene abierto el opt-in Guided antes de suficiencia

- **Categoría:** Autoridad / convergencia Entry.
- **Severidad / estado:** `S3_MEDIUM` / `CONTRACT_CONFLICT`.
- **Evidencia técnica y reproducción:** [artifacts/KAN-145/KAN-145_VISUAL_CORRECTION_DIFF_v0.2.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/artifacts/KAN-145/KAN-145_VISUAL_CORRECTION_DIFF_v0.2.md:7>); [doc/product-adr/ADR-002-portfolio-entry-active-question-clarification-convergence.md](<C:/Users/User/proyect-starteria/starteria-KAN-145/doc/product-adr/ADR-002-portfolio-entry-active-question-clarification-convergence.md>).
- **Esperado:** Stop por no tener nueva pregunta no debe interpretarse como suficiencia ni habilitar un CTA reservado a otro estado.
- **Observado/proyectado:** FACT documental: V-145-01 está BLOCKED_BY_CONTRACT; mock COP-08 sólo muestra revisión y mantiene la elección gobernada en COP-09. El microcopy v0.2.2 está aprobado para preview; freeze delta e implementación no aprobados.
- **Causa probable:** Propuesta de ofrecer Guided antes del checkpoint exige resolver relación entre stop, suficiencia y elección.
- **Impacto negocio/usuario:** Si se incluyera sin reconciliar, podría ofrecer profundización fuera del estado autorizado. El mock actual conserva el bloqueo, por lo que no se registra defecto de runtime.
- **Componentes:** KAN-145 visual preview; KAN-146; ADR-002; COP-08/09.
- **Contratos relacionados:** ADR-002 §3.9; freeze KAN-144; delta KAN-145.
- **ADR/decisión:** Sí si cambia estado/CTA — DECISION_REQUIRED D-11.
- **Prioridad:** P0 para promover ese delta.
- **Recomendación:** Conservar variante A opt-in en COP-09; evaluar B sólo con aprobación explícita de estado y propósito. No convertir respuestas guionizadas en evidencia del Planner real.

## Contrapruebas que limitan los hallazgos

No se concluye que “no existe seguridad” ni que “no existe idempotencia”:114F tiene transacción serializable, revalidación de perfil/versiones, locks de grants; handoff tiene expectedVersion/idempotency; Adaptive Core verifica Truth bindings y autoridad de decisión. No se afirma que Evidence validada se elimine libremente:FK Restrict lo impide. No se afirma que todo error IA sea invisible:hay warn y modo real-strict. No se declara ausencia de aprendizaje:PortfolioLearning existe. No se considera PASS de valor a un PASS de test, ni defecto a la ausencia de test.

Los probes P01–P07 son llamadas directas a módulos con datos/repositories sintéticos; P08/P09 son pruebas observacionales, no assertions de comportamiento correcto. Su PASS confirma la observación, incluidos defectos. P09 acepta snapshot antiguo explícito; se registra en D-09, **no** como defecto independiente sin decisión sobre intención/versionado.
