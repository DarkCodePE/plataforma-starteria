# STARTERIA_BERE_FEEDBACK_TRACEABILITY v0.1

**Fecha:** 2026-10-14 · **Modo:** auditoría autónoma, producto read-only, sin implementación.

## Uso de la evidencia Bere

Se utilizó el Markdown aportado en Downloads, hash en source-hashes.json. Es feedback y catálogo de pruebas candidatas, **no contrato aprobado**. El documento/registro original de la sesión no fue accesible; no se atribuye una observación a un entorno desplegado específico sin SHA, flags e input original.

Dos fallos candidatos se reprodujeron directamente: **BERE-04 y BERE-10**. BERE-13 tiene inconsistencia de etiquetas confirmada en código. El resto conserva el nivel de evidencia indicado; no se presenta inspección de agente como prueba de usuario.

## BERE-01 a BERE-14

| ID | Preocupación | Tests candidatos | Contraste observado | Trazabilidad | Estado | ¿Lo resolvería el Target reciente? |
|---|---|---|---|---|---|---|
| BERE-01 | Importar información vs crear iniciativa | T01 | Crear/importar son rutas y objetos distintos; PDF público no crea Project por sí mismo. La UI puede confundir la intención. | E01/E08/E16; F-04/F-16 | PARTIAL_STATIC; no reproducción con persona | Entry textual/landing separados ayudan al acceso; 150/151 no cambian la creación/importación Initiative. |
| BERE-02 | Privacidad/confidencialidad | T08 | Aviso público visible; PDF usa redacción obligatoria y TTL con limpieza. No se verificó proveedor/retención integral. | F-15; public-pdf.service; captura móvil | NEEDS_EVIDENCE | Ningún overlay demuestra anonimización o borrado completos. “Espacio seguro” requiere evidencia operacional. |
| BERE-03 | Qué información dar al entrar | T01/T12 | Entry orienta a describir situación. KAN-145 separa promesa previa, objetivo contextual y resultado, sólo para preview. | KAN-145 microcopy v0.2.2; E02 | LIKELY mejora conceptual; runtime no resuelto | 144/145 mejorarían framing; freeze delta 145 no aprobado. 150A reduce duplicado y 151 preserva input ante fallo. |
| BERE-04 | Explicar el propio lenguaje | T02 | Pregunta exacta sobre aprobaciones internas devuelve fallback, aunque el sistema introduce el término. | P01; F-06; assistantFaq/Orchestrator | CONFIRMED reproducido | Los overlays Entry no modifican este FAQ de revisión inicial. No resuelto. |
| BERE-05 | Valor visible del Overview | T03 | CTA de misión persiste; tests de render/interacción pasan. No prueba comprensión en30s ni utilidad. | F-16; Initiative Overview/MissionReview tests | LIKELY; requiere usuario | Ningún WIP revisado redefine Overview productivo. No resuelto. |
| BERE-06 | Comprender para qué sirve Step 0 | T10 | Contrato lo define como encuadre/decisión; copy misión y handoff pueden ocultarlo. | F-05/F-16; Overview; Core inv.06 | LIKELY UX; semántica F-05 confirmada | 144/145 explican Entry, no Step 0. No resuelto. |
| BERE-07 | Análisis real frente a paráfrasis | T06 | Mock por defecto y fallback enreal; outputs tienen crítica/preguntas pero no evaluación humana comparativa ejecutada. | F-07/F-22; generator; initial_reviewer | NEEDS_EVIDENCE de calidad; fallback confirmado | Comprensión narrativa150A no demuestra razonamiento; B candidato podría mejorar procedencia, no calidad por sí solo. |
| BERE-08 | Duraciones/métricas no sustentadas | T04 | No hay traza original ni reproducción de 4–6 semanas. Prompt contiene prohibición; eso no certifica cumplimiento. | F-14; AI schema/guardrails | NEEDS_EVIDENCE | Ningún cambio elegible inspeccionado demuestra reparación de este comportamiento. |
| BERE-09 | Pérdida de cifras del input | T05 | Hay límites de longitud y ausencia de trazabilidad por cada número en initial review; no se recuperaron las cifras originales de Bere. | F-14; initial_reviewer input slicing | NEEDS_EVIDENCE | 150A no cambia extracción ni el modelo de revisión; no declarar resuelto. |
| BERE-10 | Actividad presentada como decisión | T07 | Entrevistar 10 clientes se copia a decisions/upcomingDecision; hipótesis a knownFacts. | P02; F-05 | CONFIRMED reproducido | Persistente en baseline y overlays de Entry. No resuelto. |
| BERE-11 | Carga/utilidad de preguntas | T09 | ADR-002 limita pregunta activa y presupuesto Entry; review/Steps tienen otros contratos. No se valida utilidad por contar preguntas. | F-16/F-22/F-23; sessions tests | PARTIAL_UNIT para Entry; experiencia pendiente | 145 propone propósito y stop, pero Guided anticipado sigue bloqueado; 150A mejora jerarquía, no valida Planner. |
| BERE-12 | Promesa y límites del producto | T12 | Entry puede ser provisional sin crear trabajo; la degradación del review no se distingue al usuario. | F-07/F-22; ADR-006; 114E; KAN-145 | PARTIAL_STATIC; no test real de comprensión | 144/145 explicitan límites; acceptance acotada no prueba que el usuario los entienda. |
| BERE-13 | Semántica Step 4 | T03/T12 como extensión | Dominio de decisión existe; etiquetas Overview/preview siguen centradas en presentar propuesta. | F-11; completion resolver; Decision schema | CONFIRMED inconsistencia de copy; impacto UX inferido | WIP Entry/visual no toca Step 4. No resuelto. |
| BERE-14 | Gating adaptativo | T09/T11 | Core impone suficiencia y evidencia; validaciones y checkpoints reales. Importación avanzada conserva procedencia, pero reconstrucción cruza claims distintos. | F-09/F-13; Truth/readiness tests | PARTIAL_UNIT; no declarar todos los gates defectuosos | No se debe reemplazar adaptación por formulario fijo ni marcar imported como validated. T-SF no cambia Core Steps. |

## BERE-T01 a BERE-T12

| ID | Caso | Trabajo realizado | Estado | Criterio para cierre |
|---|---|---|---|---|
| BERE-T01 | Distinguir crear vs subir información | Contraste estático de rutas y PDF; no sesión real de creación | PARTIAL_STATIC | Usuario elige correctamente; input no crea Project hasta confirmación autorizada |
| BERE-T02 | ¿A qué te refieres con aprobaciones internas? | P01, llamada directa real a assistantFaq | REPRODUCED_DEFECT F-06 | Explicación contextual sin pedir Agregar contexto ni inventar mandato |
| BERE-T03 | Entender Overview en 30 segundos | Tests Overview/MissionReview; no cronometraje humano | NOT_EXECUTED_WITH_USER | Usuario explica objetivo, incertidumbre y siguiente decisión con sus palabras |
| BERE-T04 | Input sin duración | Prompt/guardrails inspeccionados; proveedor no ejecutado | NEEDS_EVIDENCE | No devuelve 4–6 semanas ni otra duración como hecho sin fuente |
| BERE-T05 | Conservar números materiales | Input slicing/schema inspeccionados; sin input original de Bere | NEEDS_EVIDENCE | Número+unidad+baseline+horizonte conservados o marcado desconocido, no reemplazado |
| BERE-T06 | Comparar tres alternativas de análisis | No evaluación de proveedor ni jueces humanos | NOT_EXECUTED | Alternativas/materialidad/riesgos sustentados; evaluar utilidad frente a paráfrasis |
| BERE-T07 | Actividad colocada como decisión | P02: “Realizar entrevistas con 10 clientes” | REPRODUCED_DEFECT F-05 | Se clasifica actividad y se pide la decisión que esa evidencia habilita |
| BERE-T08 | Anonimizar/eliminar información | Redacción/TTL/deletePdf inspeccionados; no subir originales ni borrar datos | PARTIAL_STATIC | Verificar original, derivados, logs y proveedor con fixtures sintéticos |
| BERE-T09 | No lo sé todavía | Tests sessions/UI seleccionados; no toda conversación live | PARTIAL_UNIT | Desconocimiento conservado, no inventado ni preguntado indefinidamente |
| BERE-T10 | Comprender Step 0 | Contrato y CTA inspeccionados; no test con usuario | NOT_EXECUTED_WITH_USER | Explica encuadre/decisión/restricciones sin confundirlo con actividad burocrática |
| BERE-T11 | Iniciativa avanzada importada | P07 reconstrucción sintética; no importación completa con DB | PARTIAL_PROBE / DEFECT F-09 | Conservar trabajo previo, comparar claims equivalentes, validar retroactivamente sin autoaprobar |
| BERE-T12 | Explicar qué hace Startería y sus límites | Copy/fronteras contractuales y fallback inspeccionados | PARTIAL_STATIC | Usuario entiende salida provisional, autoridad humana, decisión y siguiente paso |

## Qué mejoraría el Target y qué sigue abierto

**KAN-151:** recuperación explícita, texto conservado y botón Comprobar estado en sesión incierta. Evidencia de navegador desktop/móvil con API simulada; no convierte un resultado desconocido en éxito. Mejora el acceso y la continuidad, pero no el razonamiento de InitialReview.

**KAN150A:** una comprensión sustentada y sin inventario duplicado; oculta controles de corrección cuando no hay lectura. Evidencia de 57 tests de componentes, no proveedor real. B todavía es contrato candidato; no se atribuye persistencia narrativa ni materialDelta.

**KAN-144/145:** freeze visual acotado y copy aprobado para preview ayudarían a claridad/expectativas. La promesa universal se formula antes del input; objetivo contextual y lectura sólo después de fuente suficiente. KAN-145 conserva conflictoV14501 y explícitamente prohíbe usar una lectura futura para justificar la primera pregunta. No cambia Overview/Steps.

**T-SF:** aporta comparación de gaps/capacidad y promoción humana con procedencia; podría aumentar valor Portfolio. No corrige assistantFaq, el mapeo actividad → decisión, el fallback ni la semántica Step 4.

**Conclusión:** no hay base para declarar resuelto el conjunto Bere. Se conservaron contraejemplos, pruebas parciales y limitaciones. La siguiente validación necesita usuarios y casos originales o sustitutos explícitamente delimitados, con proveedor/versión y estado inicial reproducibles.
