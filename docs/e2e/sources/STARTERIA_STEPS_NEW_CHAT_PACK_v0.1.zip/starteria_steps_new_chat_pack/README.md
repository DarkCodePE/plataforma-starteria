# Starteria Steps — New Chat Pack

Este paquete sirve para iniciar un nuevo chat dedicado a llevar la experiencia Initiative Owner / Adaptive Steps desde diagnóstico actual hasta Shaped Changes e implementación gobernada.

## Empieza así

1. Sube este ZIP al nuevo chat.
2. Indica: **“Lee `01_NEW_CHAT_PROMPT.md` y sigue esas instrucciones.”**
3. El primer output debe ser el Gap Matrix, no código.

## Archivos principales

### 00_MUST_READ/
Autoridad, Core, Crazy 8s, Change Shaping, modelo adaptativo, feedback y diagnóstico clave.

### STEPS_NEW_CHAT_HANDOFF_v0.1.md
Resumen de todas las decisiones tomadas en esta conversación.

### 01_NEW_CHAT_PROMPT.md
Prompt listo para iniciar el nuevo chat.

### INITIATIVE_STEPS_CURRENT_TO_TARGET_GAP_MATRIX_TEMPLATE_v0.1.md
Plantilla del primer entregable.

### diagnostic/
Extractos completos del paquete E2E de 2026-10-14.

## Qué no hacer en el nuevo chat

No empezar implementando.
No volver a rediseñar Steps desde cero.
No convertir todos los findings en una única mega-épica.
