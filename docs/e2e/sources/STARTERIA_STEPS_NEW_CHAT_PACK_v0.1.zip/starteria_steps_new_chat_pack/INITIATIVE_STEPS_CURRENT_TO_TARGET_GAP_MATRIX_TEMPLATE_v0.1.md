# Initiative Steps — Current → Target Gap Matrix

**Documento:** `INITIATIVE_STEPS_CURRENT_TO_TARGET_GAP_MATRIX_v0.1.md`  
**Estado:** TEMPLATE / A COMPLETAR EN NUEVO CHAT  
**Propósito:** Cruzar diagnóstico E2E actual con el target de Initiative Owner / Adaptive Steps y convertir divergencias en cambios trazables.

---

## 1. Fuentes

### Autoridad
- `STARTERIA_AUTHORITY.md`
- `STARTERIA_CORE_LOGIC_CONTRACT.md`
- ADRs aplicables

### Target / experiencia
- `STEPS_NEW_CHAT_HANDOFF_v0.1.md`
- `STARTERIA_CRAZY8S_E2E_BASE_LOGIC_v0.1.md`
- `STEPS_ADAPTIVE_MENTAL_MODEL_SOURCE.txt`

### Shaping
- `STARTERIA_CHANGE_SHAPING_PROPOSAL_v0.2.md`

### Evidencia / diagnóstico
- `STARTERIA_E2E_AUDIT_REPORT_v0.1.md`
- `STARTERIA_E2E_FINDINGS_REGISTER_v0.1.md`
- `STARTERIA_BERE_FEEDBACK_TRACEABILITY_v0.1.md`
- `BERE_STEPS_FEEDBACK_PRUEBA_1_2.pdf`
- `STARTERIA_TARGET_MODEL_MANIFEST_RECONCILED_v0.1.md`

---

## 2. Taxonomía

### Treatment
- KEEP
- ADAPT
- REPAIR
- REMOVE
- NEW

### Gap type
- correctness
- experience
- capability
- authority
- data/provenance
- security/trust
- cross-channel
- continuity

### Change Depth
- C0 Presentation
- C1 Experience / Behavior
- C2 System / Capability
- C3 Core / Architecture / Authority

### Change Reach
- R0 Local
- R1 Single Journey
- R2 Multi-Moment
- R3 Cross-Layer
- R4 Cross-Cutting

---

## 3. Matrix

| ID | Gap Type | Capability / Moment | Current State | Evidence | Target State | Gap | Severity | Treatment | Depth | Reach | Governing Contract | ADR? | Dependencies | Proof / AC | Proposed ShapedChange |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| STP-GAP-001 |  | Initiative Handoff / Overview |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-002 |  | Semantic / Provenance |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-003 |  | Step Function / Sufficiency |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-004 |  | Adaptive Router |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-005 |  | Question Decision Gate |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-006 |  | Guided Activity |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-007 |  | Method / Tool Knowledge |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-008 |  | Evidence Intake / Synthesis |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-009 |  | Support / Unblocking |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-010 |  | Upstream Change Impact |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-011 |  | Step 4 / Decision Package |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-012 |  | Continuity / Benefit Tracking |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-013 |  | Web / MCP parity |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-014 |  | Data Trust / Confidentiality dependency |  |  |  |  |  |  |  |  |  |  |  |  |  |
| STP-GAP-015 |  | Numerical Fidelity |  |  |  |  |  |  |  |  |  |  |  |  |  |

---

## 4. Priority clusters

### Cluster A — Correctness Foundation
TBD

### Cluster B — Steps Experience Convergence
TBD

### Cluster C — Adaptive Copilot Engine
TBD

### Cluster D — Evidence & Continuity
TBD

---

## 5. Shaped Changes
TBD after matrix approval.

---

## 6. Delivery gate

Do not progress to Tech Spec / implementation until:
- high-severity correctness gaps are shaped;
- authority conflicts are resolved;
- Core/ADR deltas are explicit;
- acceptance behavior exists for each approved Shaped Change.
