# Prompt de arranque — Nuevo chat para evolución de Steps

Quiero continuar la evolución de la experiencia **Initiative Owner / Adaptive Steps** de Starteria.

## Regla principal

No rediseñes Steps desde cero y no implementes todavía.

Trabaja bajo la jerarquía documental de Starteria:

1. `STARTERIA_AUTHORITY.md`
2. `STARTERIA_CORE_LOGIC_CONTRACT.md`
3. ADRs aplicables
4. Experience Contracts / target vigente
5. Agent / Skill Contracts
6. Tech Specs
7. PRDs
8. implementación actual

El código actual no redefine el producto.

## Lee primero, en este orden

1. `STEPS_NEW_CHAT_HANDOFF_v0.1.md`
2. `STARTERIA_AUTHORITY.md`
3. `STARTERIA_CORE_LOGIC_CONTRACT.md`
4. `STARTERIA_CRAZY8S_E2E_BASE_LOGIC_v0.1.md`
5. `STARTERIA_CHANGE_SHAPING_PROPOSAL_v0.2.md`
6. `STEPS_ADAPTIVE_MENTAL_MODEL_SOURCE.txt`
7. `STARTERIA_E2E_AUDIT_REPORT_v0.1.md`
8. `STARTERIA_E2E_FINDINGS_REGISTER_v0.1.md`
9. `STARTERIA_BERE_FEEDBACK_TRACEABILITY_v0.1.md`
10. `STARTERIA_TARGET_MODEL_MANIFEST_RECONCILED_v0.1.md`

Usa `BERE_STEPS_FEEDBACK_PRUEBA_1_2.pdf` como evidencia adicional de experiencia.

## Contexto que debes preservar

- Steps son funciones estables, no formularios rígidos.
- El Copilot es el principal canal de interacción/orquestación.
- El workspace es la memoria estructurada y gobernada.
- El motor adaptativo decide UNDERSTAND / ACT / TEST / DEEPEN / UNBLOCK / READY_FOR_STEP_TRANSITION.
- Antes de preguntar existe un Question Decision Gate.
- Starteria favorece acción sobre especulación cuando es responsable.
- Si el bloqueo es organizacional, debe intentar desbloquear antes de degradar la evidencia.
- GuidedActivity es genérico; no una pantalla por método.
- Method Knowledge sirve para cocrear acciones realistas, no imponer metodologías.
- Provenance, authority, hard/soft gates, sufficiency e historia versionada se preservan.
- Web y MCP deben trabajar sobre la misma lógica y estado.
- Step 4 produce Initiative Brief / Decision Package; no “solo un pitch”.
- La decisión organizacional sigue siendo humana.

## Primera tarea

Construye:

`INITIATIVE_STEPS_CURRENT_TO_TARGET_GAP_MATRIX_v0.1.md`

No hagas implementación.

Debes comparar el estado actual diagnosticado contra el target de Steps.

### Columnas mínimas

| ID | Capability / Moment | Current State | Evidence | Target State | Gap | Severity | Treatment | Change Depth | Change Reach | Governing Contract | ADR? | Dependencies | Proof / AC | Proposed ShapedChange |

### Treatment permitido

- KEEP
- ADAPT
- REPAIR
- REMOVE
- NEW

### Taxonomía de gaps

- correctness
- experience
- capability
- authority
- data/provenance
- security/trust
- cross-channel
- continuity

## Reglas

- distingue claramente lo observado de lo inferido;
- no inventes estado de implementación que el diagnóstico no soporte;
- no conviertas feedback de Bere en autoridad: es evidencia;
- separa problemas de Steps de problemas transversales de Starteria;
- no mezcles seguridad/global auth dentro de UX de Steps, pero marca dependencias;
- si un cambio contradice Core o autoridad, marca `ADR REQUIRED`;
- no propongas tecnología todavía salvo cuando sea necesario para localizar el gap;
- no crees una mega-épica “rediseñar Steps”;
- divide por capacidades y dependencias;
- identifica qué debe resolverse antes de Adaptive Copilot para no construir IA sobre estado semánticamente incorrecto.

## Después del Gap Matrix

Propón únicamente:

1. orden de prioridad;
2. clusters de dependencia;
3. lista de Shaped Changes que deberían abrirse;
4. qué contratos nuevos/delta serían necesarios;
5. qué blockers deben resolverse antes de Delivery Translation.

No implementes hasta que revise y apruebe el Gap Matrix.
