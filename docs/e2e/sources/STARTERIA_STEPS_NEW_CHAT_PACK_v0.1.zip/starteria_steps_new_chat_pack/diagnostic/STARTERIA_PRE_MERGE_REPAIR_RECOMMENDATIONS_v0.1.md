# STARTERIA_PRE_MERGE_REPAIR_RECOMMENDATIONS v0.1

**Fecha:** 2026-10-14 · **Modo:** auditoría autónoma, producto read-only, sin implementación.

## Dictamen pre-merge

**NO_READY_FOR_MERGE_INTEGRAL.** No se implementa ninguna reparación. Se distinguen bloqueos presentes del baseline, gates propios de WIP y capacidades futuras fuera del release. Un equipo puede tramitar una mejora aislada con su aceptación específica; no debe utilizar esta auditoría como aprobación automática de publicación.

## Orden recomendado de reparación y evidencia de salida

| Orden | Trabajo | Findings/decisiones | Criterio revisable de cierre | Alcance |
|---|---|---|---|---|
| P0-1 | Unificar autorización por organización/recurso y todas las colecciones Home | F-01–03 | Dos tenants; sin permiso, grant revocado, organización null, IDs ajenos; GET/PATCH/revoke; ninguna fuga ni mutación | Bloqueo actual de seguridad |
| P0-2 | Recuperar confirmación de ruta ante fallos parciales | F-04 | Fallo después de crear Project; reintento recupera exactamente un proyecto; prueba con DB aislada | Journey de creación actual |
| P0-3 | Corregir actividad/decisión y hecho/hipótesis en handoff | F-05 | Entrevistar no es decisión; estimación no es hecho; conservar provenance y confirmación | Razonamiento downstream |
| P0-4 | Versionar cambios materiales y revisar dependientes | F-08/F-18/D-09 | Cambiar KPI/alcance/evidencia; outputs históricos conservados y obsolescencia señalada | Integridad de decisión |
| P0-5 | Bloquear promoción de estimación a realizado | F-10 | L5 requiere observación operacional; L6 atribución defendible; negativo con 81k estimados | Impacto/reporting |
| P0-6 | Cerrar decisiones de alcance del Target | D-01–05/D-08/D-11 | Actas concretas; catálogo actualizado sin elevar candidatos | Target completo, no toda corrección aislada |
| P0-7 | Reconciliar overlays 151/150A y cadena SF con main | D-06/D-12 | Diff explícito, preservar 114F y nuevos handoffs; no duplicar auth/grants/migraciones | Pre-merge de overlays |
| P1-1 | Explicación de términos, transparencia de fallback y error parcial | F-06/F-07/F-12 | Pregunta literal resuelta; modo degradado visible; aprendizaje unavailable distinto de empty | Claridad/confianza |
| P1-2 | Revisión de reconstrucción/importación | F-09 | Claims heterogéneos no son contradicción; gates retrospectivos preservan trabajo previo | E2E-06/BereT11 |
| P1-3 | Unificar Step 4/Overview y validar preguntas/valor | F-11/F-16/F-22 | Sesiones reales +evaluación proveedor; indicadores de comprensión y utilidad | Experiencia |
| P1-4 | Probar números, no inventar duraciones y privacidad | F-14/F-15 | Corpus con unidades/plazos; redacción y eliminación sintéticas hasta proveedor/storage | Antes de piloto confidencial |
| P1-5 | Completar owner-change y revoke E2E | F-17 | Transiciones atómicas, autoridad vigente y recuperación del trabajo | Resiliencia organizacional |
| P0 Target final / fase específica | Diseñar e implementar seguimiento postdecisión cuando se autorice | F-13/D-08 | Owner, baseline, periodo, medida, fuente, revisión, atribución y retorno Portfolio | No declarar funcionalidad ausente del release parcial sin revisar scope |

## Gates específicos por rama

- **KAN-151:** conservar recovery GET-only para estado incierto; verificar servidor real/idempotencia en entorno aislado, revisión humana visual pendiente en R6. Las 15 pruebas actuales son sintéticas.
- **KAN150A:** aceptación acotada de UI no elimina dependencia de integración KAN-148 reportada en su closeout. Revalidar sobre destino exacto. No añadir B ni materialDelta por conveniencia.
- **KAN-144/145:** freeze visual/copy para preview no autoriza producción. Recuperar fuente 31 o declarar sustitución limitada; no contar fixtures como resultados del proveedor. Resolver V-145-01 antes del opt-in anticipado.
- **SF/KAN-41:** preservar snapshots de recomendación/disposición y promoción humana a draft; reconciliar schema/authsid/grants contra main. El scope de sección SF no sanea por sí solo la Home canónica. Ejecutar revocación concurrente y rollback parcial en DB desechable cuando esté autorizado, sin usar entornos compartidos.
- **Baseline 114F:** conservar sus comprobaciones robustas de ownership, membership, grant, profile, revisiones y stale snapshots; no reducirlas para hacer que un usuario nuevo complete el camino.

## Pruebas de aceptación propuestas, no ejecutadas en esta auditoría

Una única suite integrada debería cubrir E2E-01/05/06/09 con navegación real, backend, base aislada, email sink y proveedor controlado; variantes adversariales de la matriz antes de afirmar readiness. Registrar SHA, flags no secretos, schema/migraciones aplicadas por el operador autorizado, request IDs y evidencia de decisión. No basta compilar ni pasar mocks. No se requiere ejecutar todo para corregir copy reversible; cada gate debe corresponder al riesgo de su cambio.

Para valor: comparar el mismo caso y la misma información disponible en cada turno con chat+documentos y gestión de proyectos convencional. Medir fidelidad de cifras/fuentes, reducción de incertidumbre, tiempo hasta decisión revisable, reprocesamiento y continuidad posterior. No asignar éxito a un caso alimentado con respuestas futuras ni a una simulación de persona.

## Acciones realizadas

Sólo lectura/análisis, tests locales sin DB configurada, navegador con API simulada y artefactos aislados. No se aplicó ninguna recomendación; no se cambió producto, contratos ni modelos. Los informes no constituyen permiso para merge o despliegue.
