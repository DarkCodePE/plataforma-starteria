# Starteria — Handoff para nuevo chat: Initiative Owner / Adaptive Steps

**Versión:** v0.1  
**Fecha:** 2026-10-15  
**Estado:** Baseline de trabajo para continuar diseño, shaping e implementación  
**Objetivo:** permitir que un nuevo chat continúe el trabajo de Steps sin reconstruir desde cero las decisiones ya tomadas.

---

## 1. Objetivo de la siguiente etapa

No volver a rediseñar conceptualmente Steps.

El trabajo siguiente es:

1. contrastar la implementación / diagnóstico actual con el target ya definido;
2. identificar gaps reales;
3. separar correctness gaps, experience gaps y capability gaps;
4. convertir esos gaps en `ShapedChange` independientes;
5. resolver primero dependencias de autoridad, semántica, provenance y propagación;
6. después traducir los cambios listos a contratos, schemas, harness, Tech Spec e implementation slices.

La unidad de trabajo no es “rehacer Steps”.

La unidad de trabajo es:

> **Current State → Target State → Gap → Shaped Change → Contract/Test → Delivery Translation**

---

## 2. Tesis cerrada de Steps

Steps es la plataforma adaptativa de ejecución de iniciativas.

No funciona como:

`formulario → completar módulo → siguiente Step`.

Funciona como:

`contexto → decisión a habilitar → evaluar qué falta → elegir movimiento → actuar/preguntar/desbloquear → evidencia → aprendizaje → re-evaluar`.

Los Steps mantienen funciones estables:

- **Step 0 — Enmarcar el ciclo**
- **Step 1 — Establecer verdad y foco**
- **Step 2 — Preparar lo ejecutable + medición**
- **Step 3 — Ejecutar, observar y aprender**
- **Step 4 — Cerrar el ciclo y preparar decisión**

Los métodos, preguntas, actividades, profundidad y artefactos pueden adaptarse.

---

## 3. Modelo mental interno acordado

El motor cognitivo objetivo es:

```text
READ CONTEXT
↓
ORIENT
¿Qué intentamos mover?
↓
SITUATE
¿Qué sabemos realmente?
↓
FRAME DECISION
¿Qué decisión necesitamos poder tomar?
↓
ASSESS SUFFICIENCY
¿Qué nos impide tomarla responsablemente?
↓
ASSESS RISK + CAPABILITY
¿Cuánta profundidad necesitamos?
↓
ADAPTIVE ROUTER
UNDERSTAND / ACT / TEST / DEEPEN / UNBLOCK / READY_FOR_STEP_TRANSITION
↓
QUESTION DECISION GATE
¿Una pregunta humana cambiaría materialmente la ruta, acción, decisión o suficiencia?
↓
PLAN NEXT MOVE
ASK / ANALYZE_EXISTING / EXECUTE_ACTIVITY / CREATE_ARTIFACT /
REQUEST_SUPPORT / REQUEST_DECISION / REVIEW_CHANGE / CLOSE_STEP / REFRAME_CYCLE
↓
GATE / AUTHORITY CHECK
↓
EXECUTE
↓
CAPTURE EVIDENCE
↓
INTERPRET
↓
REASSESS / RE-ROUTER
↺
```

Reglas clave:

- no preguntar para completar información;
- preguntar solo cuando la respuesta pueda cambiar materialmente el siguiente movimiento;
- si actuar genera mejor evidencia con menor coste/riesgo, favorecer acción;
- si la barrera es organizacional, dejar de preguntar y desbloquear;
- profundidad proporcional al riesgo;
- preservar provenance, autoridad, sufficiency y hard/soft gates.

---

## 4. Interacción Web objetivo

### Regla

> El Copilot es el principal canal de interacción/orquestación.  
> El Workspace es la memoria estructurada, trazable y gobernada.

La Web debe tener un shell estable y composición adaptable.

### Shell candidato

```text
Mission Anchor
Cycle Navigator
Adaptive Workspace
Copilot Surface
Evidence / Support / History
```

### Bloques reutilizables candidatos

```text
ContextBlock
GapBlock
ActionBlock
GuidedActivityBlock
EvidenceBlock
InsightBlock
SupportBlock
ChangeAlertBlock
SufficiencyBlock
DecisionBlock
```

No construir una pantalla diferente para cada metodología.

---

## 5. Guided Activity

Starteria debe poder acompañar:

- entrevistas;
- shadowing;
- focus groups;
- análisis de documentos;
- análisis cuantitativo;
- stakeholder/ecosystem mapping;
- prototipos;
- landing pages;
- pilotos;
- etc.

Pero mediante una abstracción común:

```text
GuidedActivity
├── purpose
├── why_now
├── preparation
├── participants
├── duration
├── execution_steps
├── capture_requirements
├── recommended_tools
├── support_needed
├── expected_output
├── evidence_expected
├── limitations
└── completion_conditions
```

El Method Knowledge Base sirve para cocrear una actividad realista. No debe imponer metodologías.

---

## 6. Method / Tool Knowledge

Regla:

> Starteria no recomienda un método porque “toca en este Step”.

Debe usar:

`necesidad + evidencia + gap + tiempo + acceso + recursos + capacidad + riesgo`

para construir la forma mínima/suficiente de avanzar.

Separar:

- **Method:** qué trabajo realizar;
- **Tool:** con qué ejecutarlo.

Introducir variantes `lite / standard / deep` cuando tenga sentido.

---

## 7. Unblocking

Regla acordada:

> **Unblock before degrade.**

Si la mejor acción está bloqueada por acceso/capacidad/autoridad:

1. hacer visible por qué esa acción aporta valor;
2. ofrecer primero solicitar desbloqueo a la persona adecuada;
3. permitir trabajo paralelo cuando sea posible;
4. ofrecer proxy/alternativa solo explicando qué evidencia se pierde.

El Initiative Owner debe saber explícitamente que puede solicitar:

- acceso a personas;
- información/datos;
- soporte técnico;
- coordinación;
- recursos;
- aclaración de alcance;
- decisiones.

No asumir `Sponsor = decisor`. Usar Business Decision Authority configurada.

---

## 8. Evidencia y síntesis

Target:

```text
SOURCE
↓
EXTRACTION
↓
OBSERVATION
↓
PATTERN candidate
↓
FINDING
↓
INSIGHT candidate
↓
CLAIM
↓
DECISION RELEVANCE
```

No convertir inferencias IA en hechos.

Necesidades críticas:

- preservar números/unidades/fechas/horizontes;
- mostrar contradicciones;
- provenance explícita;
- abstenerse antes que inventar;
- evitar “parafraseo bonito” como sustituto del análisis.

---

## 9. Progreso

No usar principalmente porcentaje de completitud.

Usar **sufficiency conditions**:

```text
Listo para avanzar cuando:
✓ ...
✓ ...
● falta ...
○ pendiente ...
```

Un Step cierra por suficiencia, no por rellenar todo.

---

## 10. Ciclos y cambios upstream

Una iniciativa puede tener múltiples ciclos.

Cambios de:

- Reto;
- KPI;
- restricción;
- deadline;
- evidencia;
- decisión;

deben producir:

```text
Change Event
↓
version
↓
Impact Assessment
↓
unaffected / requires_review / cycle_reframe_candidate
```

Nunca reescribir historia silenciosamente.

---

## 11. Step 4

Step 4 no es “hacer pitch”.

Produce:

- `InitiativeBrief`
- `DecisionPackage`

Debe sintetizar:

- intención;
- alcance;
- qué se hizo;
- evidencia;
- expected vs observed;
- aprendizajes;
- incertidumbres;
- riesgos;
- límites;
- recomendación;
- alternativas;
- decisión solicitada.

Continuidades posibles:

- iterate;
- pivot;
- new cycle;
- implement;
- scale;
- transfer;
- pause;
- close with learning.

La decisión organizacional sigue siendo humana.

---

## 12. Feedback Bere que debe tratarse como acceptance evidence

Problemas observados:

- no sabe qué hacer al entrar;
- no sabe qué busca el Step;
- no sabe qué va a obtener;
- preguntas sin sensación de avance;
- sensación de juicio / miedo a equivocarse;
- no se entiende para qué se pide información;
- resultado percibido como parafraseo;
- pérdida de cifras relevantes;
- inferencias no explicadas (ej. duraciones);
- Overview confuso;
- no se entiende “validar con evidencia”;
- no se entiende qué tipo de ayuda ofrece Starteria;
- dudas sobre qué subir;
- PDF vs iniciativa;
- confidencialidad;
- deseo de saber con antelación qué información/acceso será necesario.

No declarar que todo está resuelto. Debe mapearse a gaps actuales.

---

## 13. Diagnóstico E2E: categorías a cruzar con Steps

Priorizar findings que impactan directamente Initiative Execution:

- semántica/provenance incorrecta en handoff/context;
- cambios de mandato que no invalidan derivados;
- fidelidad numérica / unidades / horizontes;
- decisiones históricas vs nueva evidencia;
- Overview / orientación;
- Step 4 / Decision semantics;
- continuidad post-Step 4;
- valor experiencial / análisis vs parafraseo.

Seguridad/privacidad son blockers transversales y deben tratarse por su capa, no esconderse dentro de Steps.

---

## 14. Programas de cambio recomendados

### A — Correctness Foundation
- semantic/provenance correction
- mandate propagation
- numerical fidelity
- decision/evidence invalidation
- security dependencies

### B — Steps Experience Convergence
- Overview target
- Mission Anchor
- Cycle Alignment
- Step Function/Sufficiency
- progressive readiness
- Step 4 decision semantics

### C — Adaptive Copilot Engine
- Decision Framing
- Adaptive Router
- Question Decision Gate
- Next Move Planner
- Guided Activity
- Method KB
- Support Router
- Re-router

### D — Evidence & Continuity
- Evidence Inbox
- Evidence Synthesis
- Insight/Claim lifecycle
- Initiative Brief
- Decision Package
- Continuity
- Benefit Tracking

---

## 15. Primera tarea del nuevo chat

**NO implementar todavía.**

Primera tarea:

> Crear `INITIATIVE_STEPS_CURRENT_TO_TARGET_GAP_MATRIX_v0.1.md`.

Debe cruzar:

1. Core / Authority;
2. diagnóstico E2E actual;
3. feedback Bere;
4. target mental de Steps;
5. Change Shaping v0.2.

Columnas mínimas:

| ID | Capability / Moment | Current State | Evidence | Target State | Gap | Severity | Treatment | Change Depth | Change Reach | Governing Contract | ADR? | Dependencies | Proof / AC | Proposed ShapedChange |

Clasificar `Treatment`:

- KEEP
- ADAPT
- REPAIR
- REMOVE
- NEW

Separar gaps en:

- correctness;
- experience;
- capability;
- authority;
- data/provenance;
- security/trust;
- cross-channel;
- continuity.

---

## 16. Después del Gap Matrix

Orden:

1. priorizar blockers;
2. agrupar gaps por dependencia;
3. crear Shaped Changes;
4. authority check;
5. resolver ADRs si aparecen;
6. derivar/delta contracts;
7. crear harness/acceptance;
8. delivery translation;
9. Tech Spec;
10. implementation slices.

---

## 17. No-gos

- no volver a convertir Steps en formularios rígidos;
- no crear una pantalla por metodología;
- no hardcodear metodología por Step;
- no preguntar por completitud;
- no permitir que Copilot Web y MCP tengan lógica distinta;
- no usar conversación como sistema de registro;
- no inventar evidencia;
- no reescribir historial ante cambios;
- no asumir Sponsor como autoridad universal;
- no hacer un rebuild completo sin auditar reutilización;
- no implementar antes de tener Gap Matrix + Shaped Change suficientemente claros.

---

## 18. Resultado esperado del próximo trabajo

Al terminar el siguiente bloque debe existir una ruta trazable:

```text
DIAGNOSTIC FINDING
↓
TARGET REQUIREMENT
↓
GAP
↓
SHAPED CHANGE
↓
CONTRACT DELTA
↓
TEST
↓
IMPLEMENTATION SLICE
```

Ese es el objetivo del nuevo chat.
