# Startería Portfolio Lead — CONTRATO DE IMPLEMENTACIÓN DEL MOCKUP v1.0

**Dependencia:** `01_FREEZE_DECLARATION.md` y HTML original SHA-256 `6eadaf4b...728b7bf4c846`.

## 1. Principio de implementación

**El producto debe reproducir la experiencia aprobada.** Se permite cambiar la tecnología que hace posible cada comportamiento, pero no su significado para el usuario. No separar o fusionar pasos, no sustituir análisis por etiquetas planas, no suprimir funciones porque la base actual sea más sencilla, ni modificar lógica Core por conveniencia del frontend.

**Estados de evaluación:** `PRESENT_IN_MOCKUP`, `PRESENT_IN_MAIN`, `ADAPT`, `IMPLEMENT`, `BLOCKED_BY_AUTHORITY`, `DEFER_BY_EXPLICIT_DECISION`. Nunca marcar `DONE` solo por compilar.

## 2. Secuencia E2E congelada

Los **siete momentos de configuración** que el HTML denomina `Contexto`, `Objetivo`, `Incorporación`, `Análisis`, `Organización`, `Briefs`, `Asignación` son experiencia visible de setup. No son nuevos objetos canónicos ni equivalen a Steps 0–4 del Core.

| ID | Momento (visible) | Acción del usuario y responsabilidad del Copilot | Output esperado | Frontera que se protege |
|---|---|---|---|---|
| PL-00 | Contexto | Pegar prompt procedente de Decision Brief externo; pedir revisión. | Entrada recuperable con fuente declarada, análisis provisional. | No repetir Decision ni autoaprobar datos externos. |
| PL-01 | Objetivo | Conversación multi-turn sobre resultado, contexto, guardrails, KPI/señal, horizonte, baseline/meta cuando existan y decisión buscada. Ayudas: «ayúdame a redactar», «qué significa», «no lo sé», «usar contexto». | **Ficha provisional del objetivo**, corregible y confirmable al cierre de conversación. | No formulario duplicado; no inventar KPI/resultado; no exigir completar todo. |
| PL-02 | Incorporación | Subir PDF/XLSX u otros permitidos tras acceso autorizado, pegar texto/CSV/TXT o avanzar sin iniciativas. | Lote revisable con fuente, carga y errores; o portafolio inicialmente vacío. | Sin análisis ficticio presentado como real; no crear entidades sin confirmar. |
| PL-03 | Análisis | Leer cada iniciativa en ficha: qué persigue, fuente, extracto, evidencia, etapa documental probable, vacíos, relación, duplicidades, otros frentes, corrección. | Lectura contextual y bandeja de revisión; vínculo `propuesto / confirmado / pendiente / comparar duplicidad / standby`. | Un Step estimado no es progreso real; solapamiento no equivale a duplicado confirmado. |
| PL-04 | Organización | Elegir una sola línea o agrupar en retos cuando sea necesario; revisar cobertura y relaciones. | Estructura revisada de objetivo/frente → retos (cuando aportan) → iniciativas; backlog de otros posibles frentes. | Respetar modelo corporativo y ADR; no activar retos/frentes por inferencia. |
| PL-05 | Briefs | Elaborar/revisar brief estándar de convocatoria de reto nuevo o de iniciativa existente. Editar antes de enviar. | Brief versionado con resultado, contexto heredado, fuentes, riesgos, límites, trabajo/entregable esperado, decisión solicitada. | No confundir el Decision Brief externo con este brief de encargo. |
| PL-06 | Asignación | Tabla de iniciativas y encargos; seleccionar responsable; ver brief por modal; enviar invitación; observar estados. | Envío auditable; `por asignar → invitación enviada/en espera → aceptada → Start → Step real`. | Invitar ≠ aceptar ≠ iniciar; idempotencia; acceso por identidad/organización. |
| PL-07 | Inicio | Al terminar setup abrir Home, no añadir wizard final de felicitación. | Dashboard con KPI, fuente, historial, distancia a meta, bloqueos/alertas, capacidad y decisiones. | La actividad no demuestra atribución de impacto. |
| PL-08 | Portafolio | Abrir retos y cobertura, iniciativa individual, equipos, Step real, evidencia, bloqueo o revisión. | Detalle de retos e iniciativas, diferente a la síntesis ejecutiva de Home. | No repetir Home bajo otro nombre. |
| PL-09 | Decisiones | Recibir Decision Package de Step 4; comparar evidencia/insights/resultados, ver archivos; autoridad humana elige. | Decisión confirmada/versionada, fuente, razón, owner y siguiente paso; retorno al frente/reto/Home. | Recomendación de IA no es decisión; Step 4 ≠ atribución L5/L6. |

## 3. Contrato de experiencia Copilot

1. Interacción primaria: **chat secuencial**; «Tu avance» es el único panel persistente de progreso.
2. El usuario recibe respuestas contextualizadas; preguntas mínimas y adaptadas a lo declarado, no un checklist mecánico de campos.
3. No pedir de nuevo KPI, plazo, objetivo o contexto conocidos, salvo contradicción material o necesidad de validación.
4. Ayudas activables sin perder la conversación: redacción sugerida **editable**, explicación de concepto, rescatar texto del prompt, «no lo sé todavía».
5. La **Ficha del objetivo** emerge como salida del diálogo, no como formulario permanente competidor. Revisar/editar/confirmar mediante acción humana.
6. Cada sugerencia debe identificarse como tal y tener una razón breve sustentada.
7. La conversación produce estado estructurado, persistente y versionado: no usar historial textual como único registro.
8. Un caso ambiguo puede avanzar con incertidumbres visibles. No inventar baseline/target para presentar una ficha «completa».
9. Conserva historial/snapshots de cambios materiales; no reescribir silenciosamente confirmaciones.

## 4. Contrato de análisis de iniciativas

Cada iniciativa revisable debe poder mostrar, **cuando la información exista**:

- Identificador/nombre y procedencia literal (documento, fila, texto o fuente).
- Qué se intenta conseguir, segmento o área y contexto de ejecución.
- Qué se ha realizado; entregables/datos previos; claims con origen y fuerza de evidencia.
- Tipo de relación con el objetivo (propuesta vs confirmación humana) y razón concreta.
- Step **documental estimado** con faltantes/gating retroactivo, separado de Step **real** activado después por owner.
- Comparación de solapamiento/duplicidad potencial con otras iniciativas: criterio, evidencia, acción de comparar/fusionar/proponer, sin fusionar automáticamente.
- «Aborda otro frente» como hipótesis/standby que no crea automáticamente otro frente.
- Bloqueos, responsables y solicitudes cuando existan; no inferir una persona.
- Acciones: corregir, confirmar vínculo, dejar sin clasificar, pendiente, revisar duplicidad, standby, ver fuentes.

**No permitido:** publicar todas las iniciativas con un selector por defecto, marcar alineamiento confirmado por similitud semántica o asignar una iniciativa sin revisión material.

## 5. Brief de convocatoria / asignación

**No confundir tres objetos:**

- `Decision Brief` externo: justificó por qué abordar Portfolio Lead.
- `Strategic/Challenge Brief` o brief de encargo: se construye **dentro de Portfolio Lead** para explicar un reto o una iniciativa a quien lo ejecutará.
- `Decision Package` de Step 4: resultado de una iniciativa que vuelve a un decisor autorizado.

Brief de encargo mínimo visible:

1. Nombre y tipo: convocatoria de reto / iniciativa existente.
2. Objetivo/frente y reto relacionados, cuando aplique; fuente y versión del contexto.
3. Por qué importa y qué resultado/cambio se busca; KPI/señal si se conoce.
4. Qué está respaldado y qué permanece supuesto, ambiguo o desconocido.
5. Alcance, restricciones, capacidad/fechas y guardrails disponibles.
6. Qué se espera que haga el equipo y qué entregable/evidencia debería producir.
7. Decisión que el resultado de trabajo permitirá preparar; quién tiene autoridad.
8. Responsables/destinatarios, accesos, invitación y estado separado del Start.

La tabla de gestión deja ver el brief en pop-up, permite editar según permiso y opera con estados auditables. Una aceptación no es Step 0 completado.

## 6. Home, Portafolio y Decisiones: trabajos distintos

| Sección | Pregunta de negocio que responde | Contenido que debe aparecer |
|---|---|---|
| **Inicio** | «¿Cuánto nos falta para nuestra meta, qué cambia con el tiempo y dónde debo intervenir?» | Frente/resultado, KPI, baseline, meta, lecturas con fecha/fuente, delta en puntos porcentuales o unidad correcta, tendencia temporal, estados globales, tiempo/capacidad/coste conocido o desconocido, alertas priorizadas y decisiones pendientes. |
| **Portafolio** | «¿Cómo están cubiertos los retos, qué iniciativas tiene cada uno y qué ocurre con sus equipos?» | Retos/líneas, cobertura, número de iniciativas, vínculos, responsables, estado de asignación y Step real, evidencia, duplicidades, blockers y siguientes acciones por reto/iniciativa. |
| **Decisiones** | «¿Qué se demostró, qué no, qué recomienda el equipo y qué decide la autoridad humana?» | Paquete de Step 4 completo, evidencias y fuentes, insights, documentos, prototipos, resultados vs baseline y meta cuando comparables, límites, riesgos, recomendación, opción de continuidad, responsable y decisión trazable. |

**Ejemplo puramente ilustrativo:** baseline 62 %, meta 72 %, última lectura 65 % → faltan **7 puntos porcentuales**. No se debe llamar «7 % de gap», atribuir ese movimiento a una iniciativa sin sustento ni mostrar resultado inventado. Si la lectura no existe, indicar «sin dato».

## 7. Trazabilidad técnica requerida

Para cada PL-00…PL-09 ingeniería debe entregar:

- ruta/página/componentes frontend existentes o nuevos;
- endpoint/controller/service + política de autorización;
- modelo, campos, versionado, procedencia y ciclo de vida;
- componente Copilot/AI/prompt y schema de salida, si aplica;
- test unitario/integración/E2E que demuestre el resultado;
- captura o video comparativo con el HTML v1.0;
- SHA del código probado y del entorno desplegado;
- estado `PASS / FAIL / BLOCKED_BY_AUTHORITY / NOT_TESTED`.

## 8. No regresión y casos adversariales

- Cero iniciativas; se puede preparar un encargo sin inventar un registro anterior.
- 8 iniciativas con dos posibles solapamientos; no se marcan como duplicadas confirmadas.
- Entrada con cifras desconocidas; no se completan ficticiamente.
- Entrada con cifras del brief; se identifica origen y se pide confirmación solo si material.
- PDF/XLSX con contenido parcial/contradictorio; se conserva fuente y se marcan faltantes.
- Abrir y editar brief antes de invitar; no se dispara envío en la edición.
- Invitación enviada sin aceptación; la iniciativa no salta a un Step activo.
- Invitación aceptada y Start no ejecutado; estado sigue diferenciado.
- Revocar/reasignar; permisos se aplican en backend y no se filtra información entre organizaciones.
- Resultado de Step 4 sin evidencia externa; no se afirma impacto observado ni atribuido.
- Lectura temporal de KPI no existente o de distinta unidad; no se inventa delta o tendencia.
- Modal de Decision Package conserva links/versiones reales en producción; no muestra archivos ficticios como existentes.

## 9. Evidencia y gobernanza

No usar las capturas de prototipo como prueba de runtime. La QA previa es evidencia de navegación **local y sintética**, no certificación de servidor, LLM, email ni datos reales. La aceptación exige E2E observable en un entorno seguro con dos usuarios/roles, permisos y base de datos reales, más validación UX de fidelidad al mockup.
