# Startería Portfolio Lead v1.0 — CHECKLIST CONTRACTUAL DE ACEPTACIÓN

**Regla:** Los ítems de producto no se consideran cumplidos por una captura, un mock o una prueba aislada. QA registra `PASS / FAIL / BLOCKED / NOT_TESTED`, SHA y evidencia. La cobertura al implementar debe preservar tanto el escenario de iniciativas existentes como el escenario sin ninguna iniciativa.

| ID | Criterio verificable | Prioridad | Estado antes de implementar |
|---|---|---|---|
| PL-001 | El HTML de referencia usado para desarrollo coincide exactamente con SHA-256 congelado. | P0 | NOT_TESTED |
| PL-002 | El flujo de Portfolio Lead parte del prompt externo; no exige rehacer Decision Brief dentro del producto. | P0 | NOT_TESTED |
| PL-003 | La entrada acepta lenguaje natural insuficiente, ambiguo o sin taxonomía. | P0 | NOT_TESTED |
| PL-004 | Copilot mantiene una conversación de varias preguntas útiles y evita repetir datos conocidos. | P0 | NOT_TESTED |
| PL-005 | Ayudas para redactar, explicar un término, usar prompt, y «No lo sé todavía» funcionan sin perder respuesta. | P0 | NOT_TESTED |
| PL-006 | El estado estructurado se actualiza con las respuestas y preserva declaraciones, inferencias, confirmaciones y dudas. | P0 | NOT_TESTED |
| PL-007 | Ficha provisional del objetivo aparece **después** de conversación; revisión humana explícita. | P0 | NOT_TESTED |
| PL-008 | KPI, baseline, target y horizonte ausentes permanecen desconocidos, no se inventan ni bloquean borrador indebidamente. | P0 | NOT_TESTED |
| PL-009 | Respuestas, revisión y correcciones sobreviven refresh/session-recovery de forma gobernada; sin duplicados. | P0 | NOT_TESTED |
| PL-010 | Permite subir archivos en workspace autorizado, pegar CSV/TXT o texto, y marcar origen. | P0 | NOT_TESTED |
| PL-011 | Permite avanzar con cero iniciativas sin generar falsas iniciativas o bloqueos. | P0 | NOT_TESTED |
| PL-012 | Cada iniciativa importada muestra fuente/extracto, contexto, trabajo previo y evidencia. | P0 | NOT_TESTED |
| PL-013 | El análisis muestra vínculo sugerido con razón; usuario puede corregir, confirmar, dejar pendiente y no vincular. | P0 | NOT_TESTED |
| PL-014 | Compara posibles duplicidades/solapamientos con criterios, sin afirmar que son definitivos. | P0 | NOT_TESTED |
| PL-015 | Puede derivar un posible «otro frente» a standby, sin crear automáticamente un nuevo frente. | P0 | NOT_TESTED |
| PL-016 | Step documental estimado es distinto de progreso y validación Core real. | P0 | NOT_TESTED |
| PL-017 | La organización en reto(s) se propone únicamente cuando genera sentido y conserva la jerarquía canónica autorizada. | P0 | NOT_TESTED |
| PL-018 | Puede conservar una sola línea de trabajo visible sin crear retos innecesarios a nivel UX. | P0 | NOT_TESTED |
| PL-019 | Ficha de reto muestra objetivo relacionado, iniciativas, cobertura, evidencia, alertas y decisiones. | P0 | NOT_TESTED |
| PL-020 | Brief estándar de convocatoria/iniciativa se prepara antes de enviar o asignar. | P0 | NOT_TESTED |
| PL-021 | Brief editable muestra qué se busca, por qué, fuentes, límites, resultado/entregable y decisión esperada. | P0 | NOT_TESTED |
| PL-022 | Brief incluye versión y restricciones heredadas; cambios materiales disparan revisión, no reescritura automática. | P0 | NOT_TESTED |
| PL-023 | Tabla de asignaciones permite ver brief, responsable, envío y seguimiento por iniciativa. | P0 | NOT_TESTED |
| PL-024 | Envío, aceptación, Start y Step real quedan como estados separados y auditables. | P0 | NOT_TESTED |
| PL-025 | Retry, doble clic y fallo de respuesta no crean proyecto, aceptación o invitación duplicados. | P0 | NOT_TESTED |
| PL-026 | Revocación, scopes y permisos funcionan por usuario/organización/recurso en backend, sin filtraciones. | P0 | NOT_TESTED |
| PL-027 | Finalizar configuración lleva a Inicio con información persistida, no a un wizard aislado. | P0 | NOT_TESTED |
| PL-028 | Inicio muestra KPI/baseline/meta/última lectura, unidad y fuente, sin impacto atribuido artificialmente. | P0 | NOT_TESTED |
| PL-029 | Inicio muestra evolución temporal legible; 65 vs 72 se expresa como 7 pp, no 7 %. | P0 | NOT_TESTED |
| PL-030 | Inicio muestra alertas priorizadas con qué pasó, por qué importa y a qué acción/usuario derivar. | P0 | NOT_TESTED |
| PL-031 | Inicio distingue costes, recursos y capacidad conocidos, estimados o ausentes. | P1 | NOT_TESTED |
| PL-032 | Portafolio presenta vistas de retos y cobertura, NO repite la síntesis de Inicio. | P0 | NOT_TESTED |
| PL-033 | Portafolio permite abrir iniciativa y ver owner, equipo, Step actual, evidencias y alertas/bloqueos. | P0 | NOT_TESTED |
| PL-034 | Modal de iniciativa permite revisar vínculos, solapamientos, otro frente y faltantes, según fuente disponible. | P0 | NOT_TESTED |
| PL-035 | Centro de Decisiones recibe un Decision Package realmente ligado a iniciativa/ciclo/versión. | P0 | NOT_TESTED |
| PL-036 | Decision Package incluye qué se hizo, qué ocurrió, insights, evidencia, entregables, prototipos y links reales. | P0 | NOT_TESTED |
| PL-037 | El paquete marca riesgos, límites y afirmaciones no sustentadas; no infiere impacto L5/L6 por completar Step 4. | P0 | NOT_TESTED |
| PL-038 | La decisión humana contiene autoridad, opción, razón, fuente/versionado y próxima acción; no la confirma IA. | P0 | NOT_TESTED |
| PL-039 | La decisión vuelve al reto, frente y Home preservando historial de cobertura y alertas. | P0 | NOT_TESTED |
| PL-040 | Navegación, textos y orden de interacción coinciden con la baseline v1.0, excepto cambios expresamente autorizados. | P0 | NOT_TESTED |
| PL-041 | Vista desktop y móvil sin duplicación de campos, sin desbordamiento horizontal y con componentes accesibles. | P1 | NOT_TESTED |
| PL-042 | Tests con usuarios/roles distintos y datos reales no sensibles comprueban flujos positivos y negativos. | P0 | NOT_TESTED |

## Gates de salida

- **G0 — Autoridad:** Core/ADRs identificados y contratos reconciliados; conflictos materialmente resueltos o bloqueados.
- **G1 — Fidelidad UX:** cada PL-001…PL-041 aplicable cuenta con prueba/snapshot y revisión UX; excepciones documentadas.
- **G2 — Servicios:** IA productiva, DB, auth, envío de correo, fuentes y estados probados, no simulados.
- **G3 — E2E:** iniciativa importada y encargo nuevo, destinatario distinto, Start, Step real, Step4, Decision Package, retorno al portafolio.
- **G4 — Seguridad:** multi-tenant, revoke, retry, idempotencia, error/recovery, datos/claims.
- **G5 — Product:** aceptación explícita contra v1.0 congelado; sin regresiones abiertas no autorizadas.

**No declarar `E2E_ACCEPTED`** por un PDF, 100 % de tests unitarios, un screenshot, el HTML o un run de IA determinista. Requiere recorrido integrado reproducido sobre SHA identificable.
