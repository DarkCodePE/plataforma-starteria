# STARTERÍA — Portfolio Lead v1.0 · ACTA DE CONGELAMIENTO UX

**Versión de diseño aprobada por el usuario:** `STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v1.0.html`  
**Estado:** `FROZEN_UX_APPROVED_FOR_IMPLEMENTATION_PLANNING`  
**Fecha de congelamiento:** 2026-10-19  
**Alcance:** Experiencia de Portfolio Lead representada en el HTML v1.0.  
**No equivale a:** publicación en GitHub, aprobación de Core/ADRs, implementación productiva, pruebas E2E ni autorización de despliegue.

## Identidad inmutable

- **Fuente única de diseño aprobado:** `baseline/STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v1.0.html`
- **Tamaño exacto:** `97,865` bytes.
- **SHA-256:** `6eadaf4b72b55107120cf0b097b65deeba3c7108c07d3f98dd81128b7bf4c846`
- **Comprobación:** copia idéntica byte a byte al HTML de v1.0 existente en los materiales aprobados.
- **Referencia de QA:** `evidencias/STARTERIA_PORTFOLIO_LEAD_v1.0_CONTROL_DE_CAMBIOS_Y_QA.md`, sin modificación.
- **Capturas:** en `evidencias/`, solo para comparación visual contextual; el HTML original es la referencia más completa del comportamiento ilustrado.

## Decisión de producto congelada

El usuario **aprueba la experiencia Portfolio Lead v1.0 y pide que se implemente sin rediseño ni variación silenciosa**. Deben preservarse todas las interacciones y vistas del HTML, incluidas las ramas menos visibles, las confirmaciones, las vistas detalle y los estados intermedios.

### Se congela

1. **Entrada Copilot-first desde un prompt externo**, elaborado a partir de un Decision Brief previo fuera de Portfolio Lead. No incorporar el diagnóstico comercial dentro de este flujo.
2. **Conversación real guiada**, con varias aclaraciones útiles y ayudas para usuarios que no saben redactar o interpretar un KPI, una baseline o una meta. No sustituir por formulario de campos y una sola pregunta.
3. **Output de entrada**: Ficha provisional del objetivo, entregada para revisión humana; campos conocidos, inferidos, propuestos y pendientes distinguibles.
4. **Incorporación flexible**: archivos, texto/CSV o cero iniciativas. Ninguna iniciativa inventada.
5. **Análisis de iniciativas avanzado y corregible**, con fuentes, evidencia, estimación de Step, vacíos, contribución, duplicidad/solapamiento, otro frente/standby y posibilidad de revisión humana.
6. **Vinculación no automática**: confirmar, posponer, dejar sin vínculo, comparar duplicidades. No publicar ni activar por inferencia.
7. **Organización contextual del trabajo**: retos o líneas de trabajo solo si ayudan. No exigir al usuario aprender la ontología ni crear más retos/frentes de los necesarios.
8. **Brief de convocatoria o iniciativa existente antes de la asignación**; visible, editable y con información operativa suficiente para la persona ejecutora.
9. **Tabla de asignaciones**: responsable, envío/invitación, estado, aceptación y Step efectivo; enviar ≠ aceptar ≠ Start.
10. **Home ejecutiva consultiva**, con KPI y serie temporal, distancia a meta explicada, estados, alertas accionables, recursos/capacidad y decisiones.
11. **Portafolio diferente a Home**: detalle por reto y cobertura, iniciativas, estado de equipos, evidencias, bloqueos y vista granular.
12. **Centro de decisiones**: Decision Package de Step 4 con resultados, fuentes, insights, evidencia, prototipos/documentos, entregable, limitaciones, recomendación y decisión humana explícita.

### No modificar silenciosamente

- Mensajes, estructura o orden del recorrido; arquitectura de información o navegación.
- Comportamiento de confirmación, estados y autoridad de decisiones.
- Fichas o modales; campos que expliquen por qué se recomienda una relación.
- Progreso de `Tu avance`, ni renombrar una pantalla o convertirla en fase canónica sin aprobación.
- Estados `pendiente`, `por revisar`, `sugerido`, `confirmado` y `en espera` como si fuesen equivalentes.
- Restricciones, proveniencia, idempotencia, Scope/Role o semántica de Steps para satisfacer visualmente el mockup.
- Ninguna simplificación bajo el argumento «el código actual funciona de otra manera» o «no existe el componente».

## Límite de autoridad y resoluciones de conflictos

Jerarquía consultada de Startería:

`Core vigente → ADR aprobado → Experience Contract → Agent/Skill/Tech Spec → PRDs → mockup aprobado → código actual`.

Este freeze **fija la aceptación del diseño de experiencia dentro de su ámbito**, pero **no reemplaza contratos superiores**. Si existe un conflicto con permisos, dominio, Step 0–4, gating, canonicalización u otra autoridad:

1. Marcar `BLOCKED_BY_AUTHORITY` en el punto concreto.
2. Registrar contrato afectado, archivos, estado del código, opciones y consecuencia visible.
3. Solicitar decisión humana o ADR antes de implementar ese punto.
4. No modificar el HTML congelado ni la lógica contractual para desbloquearlo en silencio.

El `STARTERIA_MVP_MASTER_PLAN_v1.2.md` consultado es **propuesta pendiente de aprobación**, no reemplazo automático de un contrato superior. El archivo de Core provisto está identificado como **v0.3 candidata / requiere retest**; verificar el Core vigente del repositorio seleccionado antes de intervenir.

## Qué no demuestra este freeze

- No hay IA productiva en el mockup: diálogo determinístico de demostración.
- PDF/XLSX no reciben extracción real en el HTML; CSV/TXT admiten lectura local limitada.
- Invitación por email, aceptación, grant y Step real son estados simulados.
- Las 8 iniciativas enriquecidas y cifras son **sintéticas**.
- Los documentos/prototipos mostrados no son archivos descargables reales del usuario.
- No hay persistencia productiva ni evidencia de piloto real.

**Regla de implementación:** implementar comportamiento equivalente con sistema real, preservar experiencias visibles, y señalar explícitamente la diferencia entre dato sintético y dato productivo. Una pantalla no se considera terminada por renderizar.

## Control de cambio obligatorio

Cualquier ajuste visible/semántico que altere lo congelado requiere **CR de producto**, con:

- ID de cambio y motivo;
- evidencia/problema real;
- «antes» v1.0 y «después» propuesto;
- impacto en UX, Core, estados, permisos, pruebas;
- aprobación explícita del responsable de producto;
- **nueva versión** (v1.0.1 o v1.1, según entidad del cambio), sin sobrescribir el archivo congelado.

La corrección técnica interna que **no cambia comportamiento** puede ejecutarse con pruebas de no regresión, dejando registro de la implementación. El cambio por capricho de diseño, conveniencia de ingeniería o preferencia del LLM no está autorizado.

## Declaración final

**FROZEN FOR IMPLEMENTATION REFERENCE — NO SILENT UX OR LOGIC CHANGE.**

Este paquete se entrega para ser integrado al repositorio como baseline protegida y trazable. Hasta hacerlo, el congelamiento está documentado y verificable en los artefactos entregados, **no protegido todavía por branch rules o CI del repositorio**.
