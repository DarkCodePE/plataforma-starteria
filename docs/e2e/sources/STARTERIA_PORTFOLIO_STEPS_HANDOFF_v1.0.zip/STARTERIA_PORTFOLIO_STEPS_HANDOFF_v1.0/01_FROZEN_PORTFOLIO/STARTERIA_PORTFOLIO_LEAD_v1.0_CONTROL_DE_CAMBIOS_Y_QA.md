# Startería Portfolio Lead — v1.0 · Convergencia sin regresión funcional del mockup

**Base de trabajo:** `STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v0.8.html`. Se consultó además la UX Spec v0.3/v0.4 y se descartó utilizar v0.9 como base porque simplificaba capacidades previamente representadas.

**Naturaleza:** prototipo local interactivo con datos ficticios. No es una certificación del runtime productivo ni un cambio contractual. No se ejecuta LLM, no se envían correos y no se crea ni se modifica información corporativa real.

## Secuencia de uso

1. Prompt preparado fuera de Portfolio Lead, procedente de un acercamiento previo; se recibe como contexto, no como verdad automáticamente confirmada.
2. Copilot conversa sobre resultado, realidad actual, restricciones, KPI cuando corresponda y decisión buscada. Ofrece ayuda para redactar, aclarar términos, reutilizar información y reconocer desconocidos.
3. Output: **Ficha provisional del objetivo** con resultado, señal, baseline, meta, horizonte, contexto, guardrails y decisión. Revisión humana antes de continuar.
4. Incorporar iniciativas: PDF/Excel/documentos (solo registro de archivo en el prototipo), CSV/TXT (lectura simple local), texto pegado o avanzar sin iniciativas.
5. Análisis por iniciativa: procedencia, fragmento, objetivo/segmento, etapa probable documental, evidencia, comparación de solapamientos, posible otro objetivo, corrección. Confirmación separada de vinculación, revisión sin vínculo o marcado para comparar duplicidad.
6. Organización opcional en retos / líneas de trabajo si existen varios focos. No multiplicar retos por obligación. No crear frentes automáticamente cuando algo parece fuera del objetivo.
7. Brief estándar de reto para convocatoria de iniciativa nueva **o** brief de una iniciativa existente vinculada; modal editable con contexto, resultado, fuentes, desconocidos, entregable esperado, límites y decisión buscada.
8. Tabla de asignaciones: responsable, estado, vista de brief, envío de invitación, aceptación y evento externo de Step. `Enviar ≠ aceptar ≠ iniciar`.
9. Home del Portfolio Lead: KPI y evolución temporal con fuente, distancia a meta expresada en **puntos porcentuales**, alertas con intervención, volumen/estado del trabajo, recursos conocidos o desconocidos, decisiones y lectura consultiva.
10. Portafolio: retos y cobertura (por reto, iniciativas, alertas, vínculos confirmados y pendientes) y lista de iniciativas/encargos (equipo, fuentes, estado real del Core separado de Step documental estimado).
11. Decisiones: Decision Package de Step 4 con qué se ejecutó, qué ocurrió, insights, evidencia, entregables, prototipos/documentos, riesgos, afirmaciones no sustentadas, recomendación y decisión humana/versionable en producto real.

## Lo que se conserva del mockup anterior

| Experiencia | Tratamiento en v1.0 |
|---|---|
| Copilot y prompt externo | KEEP + conversación real de demostración |
| Importar o avanzar sin iniciativas | KEEP |
| Lectura contextual, fuentes y corrección | KEEP + confirmación de vínculo explícita |
| Solapamientos y objetivos ajenos en standby | KEEP |
| Retos / líneas de trabajo solo cuando aportan | KEEP |
| Brief estándar editable antes de asignar | KEEP |
| Invitación, aceptación y Start separados | KEEP + vista de estado de envío |
| Home ejecutiva con KPIs, capacidad, alertas | KEEP + tendencia temporal y explicación de pp |
| Portfolio de iniciativas y detalle | KEEP + reto y cobertura, separado del Home |
| Decision Package y decisión humana | KEEP + artefactos, aprendizajes y entregables |

## Verificaciones ejecutadas

Pruebas de navegador en Chromium (render de HTML local vía `set_content`):

- Recorrido con 8 iniciativas sintéticas, revisión y vinculación de una, marcado de posible duplicidad de otra, organización, briefs, asignación, simulación de aceptación/Step, Home, portafolio, reto, ficha y Decision Package: **sin errores JavaScript observados**.
- Recorrido sin iniciativas: confirmar objetivo, omitir importación, encargo nuevo, confirmar brief, enviar invitación simulada, Home y detalle del reto: **superado**.
- Ayudas del Copilot, síntesis anticipada tras dos respuestas y confirmación del objetivo: **superado**.
- Historia del KPI ilustrativa, gráfico temporal y cambio de pestañas: **superado**.
- Viewport de 390 px: sin desbordamiento horizontal del documento en estado inicial.
- `node --check` del JavaScript embebido: **superado**.

Estas verificaciones **no** prueban calidad de LLM, accesibilidad completa, adjuntos reales ni backend. Los estados de simulación no sustituyen pruebas E2E de producción.

## Límites honestos del HTML

- El Copilot ofrece una conversación determinística con mensajes editables; no usa IA real.
- No realiza parsing o análisis real de PDFs/Excel; sí permite seleccionarlos. Puede leer texto o CSV simples en el navegador. Las 8 iniciativas enriquecidas son **datos ficticios preparados**.
- Las invitaciones, aceptación y Steps son estados simulados: no se envía correo ni se accede a la experiencia real del Initiative Owner.
- Los enlaces a documentos, prototipos y dashboards del Decision Package son ejemplos ilustrativos, no archivos existentes.
- La información del prototipo se conserva durante la sesión abierta del navegador, pero **no** se guarda en backend ni se persiste al recargar.
- La versión final de producto requiere reconciliar los flujos con autoridad/ADRs, permisos, estados Core, schema, source provenance y pruebas de integración.

## Feedback solicitado para validación UX

Evaluar si (a) la conversación da suficiente claridad antes de mostrar la Ficha del objetivo; (b) las acciones de revisión y confirmación de vínculos son comprensibles; (c) la diferencia Home vs. Portafolio/Reto vs. Decisiones es evidente; (d) el brief de convocatoria permite al Owner entender el trabajo y el valor de negocio esperado; (e) las alertas y el estado real de cada iniciativa se encuentran donde el Portfolio Lead los necesita.
