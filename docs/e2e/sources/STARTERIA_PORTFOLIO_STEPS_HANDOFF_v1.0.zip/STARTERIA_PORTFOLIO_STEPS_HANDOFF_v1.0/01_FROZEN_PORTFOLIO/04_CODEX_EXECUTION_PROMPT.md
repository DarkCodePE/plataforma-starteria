# PROMPT MAESTRO PARA CODEX — IMPLEMENTAR PORTFOLIO LEAD SIN ALTERAR LA V1.0

> Copia este documento a Codex junto con todo el paquete congelado. Su función es fijar el comportamiento esperado. **No te autoriza a modificar el Core ni los contratos superiores.**

Eres responsable de ejecutar una reconciliación técnica e implementación por vertical slices de **Startería Portfolio Lead**, tomando como baseline UX **exclusivamente** el HTML:

`baseline/STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v1.0.html`

SHA-256 esperado:

`6eadaf4b72b55107120cf0b097b65deeba3c7108c07d3f98dd81128b7bf4c846`

Antes de modificar código:

1. Verifica la huella SHA del HTML y registra el commit SHA de `main` y del branch de trabajo. Si la huella no coincide, DETENTE.
2. Lee el `README.md` del paquete, `01_FREEZE_DECLARATION.md`, `02_IMPLEMENTATION_BEHAVIOR_CONTRACT.md`, `03_ACCEPTANCE_CHECKLIST.md` y el documento de QA que acompaña la v1.0.
3. Lee en el repositorio `docs/STARTERIA_AUTHORITY.md`, el Core **vigente** (no asumir que v0.3 candidata fue aprobada), ADRs, Experience/Agent/Skill/Tech Specs y `AGENTS.md`.
4. Audita el código y las ramas antes de tocar una función. Clasifica cada parte `KEEP / ADAPT / IMPLEMENT / DEFER_WITH_APPROVAL / BLOCKED_BY_AUTHORITY`. Para cada elección cita archivos concretos y pruebas.
5. Produce una **matriz de trazabilidad PL-00…PL-09 y PL-001…PL-042** con rutas, componentes, endpoints, persistencia, esquema, pruebas y estado.
6. Da un plan de implementación por **slices pequeños y verificables**, con diff esperado, fallback, seguridad, rollback, data migration si aplica.
7. Identifica discrepancias con contratos superiores mediante `CONFLICT` (contrato, requisito, implementación, riesgo, resolución propuesta, ADR sí/no). NO las resuelvas silenciosamente.

Invariantes UX obligatorios:

- No rediseñar el flujo por gusto ni sustituir chat por formulario de campos.
- No obligar a elegir retos antes de entender negocio e iniciativas.
- No eliminar el camino sin iniciativas.
- No reducir análisis de iniciativas a nombre + alineado/no alineado.
- No convertir Step inferido a Step confirmado ni deduplicar automáticamente.
- No asignar antes de construir el brief, ni fusionar invitación/aceptación/Start.
- No perder Home ejecutiva, detalle granular de portafolio/retos ni Decision Package rico.
- No crear un segundo Adaptive Core ni alterar función Step 0–4.
- No autoaprobar objetivos, relaciones, inversión, fuentes o decisiones desde LLM.
- No inventar KPI, baseline, target, «progreso», ROI o impacto atribuido.
- No integrar Decision Brief comercial externo como wizard previo dentro de este Portfolio Lead.
- No borrar elementos de la v1.0 por un recorte de alcance sin aprobación de producto; registrar dependencias y bloquear el slice que aún no pueda completarse.

Durante cada PR:

- Mantén el HTML congelado fuera del diff.
- Identifica comportamiento UX implementado y ref test.
- Ejecuta tests baseline antes/después, incluyendo flujos negativos; aporta capturas/replay de browser.
- Si un test no se puede ejecutar, estado `NOT_TESTED` y causa. Nunca simules PASS.
- Cierra cada slice con resumen de `QUÉ EXISTÍA / QUÉ CAMBIÓ / QUÉ SE CONSERVÓ / QUÉ FALLÓ / TESTS / SHA / PENDIENTES`.

**Frontera de autoridad:** este prompt no sustituye la arquitectura existente. Si encuentra conflicto de dominio o seguridad, detiene ese bloque y solicita decisión humana. No implementes una alternativa supuestamente equivalente si reduce valor o altera semántica de la v1.0.

**Primer encargo solicitado a Codex al recibir este paquete:** AUDITORÍA Y PLAN DE SLICES, no implementación en el primer turno. No hacer commit, merge o deploy en esa primera fase salvo autorización explícita posterior.
