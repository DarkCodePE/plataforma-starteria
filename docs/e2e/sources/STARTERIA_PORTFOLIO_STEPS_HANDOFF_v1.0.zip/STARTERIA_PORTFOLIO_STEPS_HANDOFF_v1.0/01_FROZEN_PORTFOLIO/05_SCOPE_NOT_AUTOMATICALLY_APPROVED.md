# Registro de límites y decisiones técnicas reservadas

Este documento **no agrega funcionalidades a la v1.0**; identifica fronteras para que el equipo no resuelva una ausencia del mockup con supuestos personales.

| Tema | Fijo en v1.0 | No debe darse por decidido sin revisión |
|---|---|---|
| Entrada | El Decision Brief se elabora fuera de Portfolio Lead; se recibe un prompt para arrancar. | Formato definitivo de importación e identidad de sesiones; creación de Organization; permisos al acceder. |
| Conversación | La UX es Copilot-first, multi-turn y brinda apoyo de redacción y explicación. | Modelo/temperatura/prompts exactos; cuándo la IA puede sugerir 0 preguntas; límites de sesión canónicos. |
| Frente / retos | Usuario confirma objetivo y organización. Retos se muestran si agregan valor. | Si se puede omitir Challenge **en el dominio corporativo**: puede requerir ADR; solo se puede simplificar UX sin cambiar Core autorizado. |
| Adjuntos | Carga/pegado/seguir vacío son rutas visibles. | Formatos exactos productivos, políticas de seguridad, cuotas, retención y análisis real de PDF/XLSX. |
| Lectura IA | Puede inferir y sugerir relaciones, detectar posibles duplicados, Step probable y gaps. | Clasificaciones automáticas con certeza, promociones de evidencia, hard-gates o fusiones de registros. |
| Brief / asignación | Brief editable antes del envío, invitación, aceptación y Start distintos. | Canales/contratos de email, estados canónicos, grants, reenvíos y revocación detallada. |
| Home | KPI, evolución con fuente, meta, gap unitario, alertas, capacidad/recursos. | Series de tiempo reales si no hay datos; cálculo de ROI, atribución causal y beneficios L5/L6. |
| Portafolio | Vista granular de reto, cobertura, iniciativas, equipos, estado/alertas. | Alterar cardinalidades de dominio para facilitar vista de «línea de trabajo». |
| Decisiones | Paquete rico de Step 4 con resultado y evidencias, decisión humana. | Atribución de impacto, decisión automática, evidencia ficticia tomada como real. |

## Regla de conflictos

**Implementación no debe reinterpretar vacíos del mockup como permisos para cambiar la lógica.** El componente se deja pendiente/bloqueado, con asunto escalado a Product/Engineering y ADR si altera invariantes, y se mantiene fiel a la UI aprobada donde sea posible.
