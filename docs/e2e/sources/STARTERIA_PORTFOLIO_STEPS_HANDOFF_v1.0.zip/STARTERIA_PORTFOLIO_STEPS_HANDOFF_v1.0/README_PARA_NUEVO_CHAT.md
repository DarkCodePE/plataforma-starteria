# Startería — Paquete de traspaso Portfolio Lead v1.0 → Integración con Steps

**Fecha:** 2026-10-20  
**Propósito:** conservar el diseño Portfolio Lead **v1.0 aprobado** para integrarlo con el trabajo de Steps realizado en otro chat.  
**Estado:** REFERENCIA DE DISEÑO Y COORDINACIÓN. No autoriza cambiar Core, editar freezes ni programar.

## Qué debes compartir en el nuevo chat

Sube **este ZIP completo**, más **el paquete/MDs de Steps congelados del otro espacio** (no incluidos aquí).

### Lectura requerida, en orden

| Orden | Archivo dentro del ZIP | Función |
|---|---|---|
| 1 | `01_FROZEN_PORTFOLIO/01_FREEZE_DECLARATION.md` | Qué del Portfolio Lead v1.0 quedó aprobado y está prohibido cambiar silenciosamente. |
| 2 | `01_FROZEN_PORTFOLIO/02_IMPLEMENTATION_BEHAVIOR_CONTRACT.md` | Secuencia PL-00…PL-09 y comportamiento exacto en cada punto. |
| 3 | `01_FROZEN_PORTFOLIO/03_ACCEPTANCE_CHECKLIST.md` | Los 42 criterios de aceptación que el E2E unificado no debe vulnerar. |
| 4 | `04_REFERENCIA_VISUAL/STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v1.0.html` | Fuente visual/interactiva congelada; conserva el HTML exacto. |
| 5 | `01_FROZEN_PORTFOLIO/05_SCOPE_NOT_AUTOMATICALLY_APPROVED.md` | Evita dar por aprobadas decisiones técnicas que el mockup no determina. |
| 6 | `02_INTEGRACION/STARTERIA_PORTFOLIO_STEPS_E2E_HANDOFF_v0.1.md` | Contrato de coordinación preliminar: ida PL→Steps y vuelta Steps→PL, test y entregables. |
| 7 | **Aportar desde el otro espacio** | Freeze/Logic Contract de Steps + sus criterios de aceptación + mockup/guía + estado de implementación. |

### Complementarios (no son autoridad sobre el freeze)

- `01_FROZEN_PORTFOLIO/04_CODEX_EXECUTION_PROMPT.md`: útil cuando llegue el momento de auditoría/implementación, **no** necesario para rediseñar.
- `01_FROZEN_PORTFOLIO/STARTERIA_PORTFOLIO_LEAD_v1.0_CONTROL_DE_CAMBIOS_Y_QA.md`: evidencia previa de navegación sintética/UX.
- `03_CONTEXTO_PROPUESTO/STARTERIA_MVP_MASTER_PLAN_v1.2.md`: **propuesta** de alcance producto; contextualiza la separación entre Decision externo, Platform individual y Portfolio; no modifica Core/ADRs.
- `MANIFEST_SHA256.txt`: permite comprobar que no se editaron los archivos fuente.

## Qué NO mandar como fuente normativa

- Mockups v0.5, v0.6, v0.7, v0.8 y v0.9, porque son **iteraciones anteriores**, no la versión aprobada.
- El plan v1.1 como autoridad: fue sustituido en alcance propuesto por v1.2, que a su vez continúa siendo propuesta, no Core.
- Una versión candidata de Core v0.3 como si fuera aprobada. Leer en el repo el Core y ADRs vigentes.

## Puntos de preservación que el otro chat debe repetir correctamente

- Entrada del Portfolio Lead por prompt procedente de Decision Brief **externo**, no por diagnóstico dentro de la plataforma.
- Copilot **conversacional**, no formulario paralelo; Ficha provisional aparece como salida de esa conversación.
- Puede iniciar con iniciativas importadas **o sin ninguna**.
- Importación con fuentes, revisión, evidencia, Step documental estimado, duplicidades, solapamientos, otros frentes/standby y confirmación humana.
- Reto organizador solo cuando sea útil en la experiencia visible; no saltarse dominio Core.
- Brief de convocatoria/iniciativa existente **antes** de invitar.
- Envío ≠ aceptación ≠ Start ≠ Step real.
- Steps opera el mismo Core en iniciativas vinculadas e independientes.
- Step 4 retorna un Decision Package; Portfolio Lead gestiona decisión autorizada, cobertura y KPI sin inventar impacto.
- Inicio, Portafolio y Decisiones resuelven necesidades diferentes: executive overview, lectura granular y decisión.

## Entregable inicial a pedir al nuevo chat

**No comenzar implementando.** Comparar los freezes y entregar mapa E2E + matriz de handoff + matriz de conflictos/brechas antes de generar Tech Specs y backlog.

### Mensaje recomendado

> Quiero integrar el diseño **Portfolio Lead v1.0 congelado** con el freeze de **Steps** que adjunto de otro trabajo. **Ambos diseños se conservan tal cual; no propongas otro diseño completo por defecto.** Lee primero el ZIP `STARTERIA_PORTFOLIO_STEPS_HANDOFF_v1.0.zip`, el freeze de Steps y luego Core/ADRs aprobados del repo. Define el E2E compartido desde brief de encargo e invitación hasta Overview/Start/Steps 0–4/Decision Package/retorno al portafolio. Identifica contratos, datos, estados, permisos y pruebas; marca los conflictos como bloqueos. Empieza por `STARTERIA_PL_STEPS_E2E_UNIFIED_JOURNEY_v0.1.md` y la matriz de handoff; no modifiques código todavía.
