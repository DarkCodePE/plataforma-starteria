# Startería — Contrato de traspaso para integrar Portfolio Lead v1.0 y Steps

**Versión del traspaso:** v0.1 — 2026-10-20  
**Estado:** DOCUMENTO DE COORDINACIÓN PARA NUEVO CHAT / NO APROBACIÓN DE NUEVA LÓGICA CORE  
**Portfolio Lead:** UX v1.0 aprobada y congelada; fuente íntegra en `../04_REFERENCIA_VISUAL/STARTERIA_PORTFOLIO_LEAD_COPILOT_FIRST_v1.0.html`.  
**Steps:** sus contratos y su UX congelada deben proporcionarse por separado desde el espacio donde se diseñaron. **No están contenidos ni supuestos en este paquete.**

## 1. Encargo del nuevo chat

Diseñar una **única experiencia E2E** que conecte Portfolio Lead y Steps, con dos responsabilidades diferentes:

- **Portfolio Lead:** conectar objetivo de negocio, frentes/retos, iniciativas, responsables, evidencias, señales, alertas y decisiones del portafolio.
- **Steps / Adaptive Core:** desarrollar una iniciativa individual mediante el flujo Step 0–4 definido en sus contratos vigentes, con evidencia, checkpoints, autoridad y decisión.

El trabajo debe crear **un contrato de integración entre ambos** y detectar brechas, **no rediseñar ni reemplazar** los diseños congelados por un mockup nuevo simplificado.

## 2. Fuentes y su prioridad

1. Leer `STARTERIA_AUTHORITY.md`, **Core vigente del repositorio seleccionado** y ADRs aprobados, antes de decidir dominio, autoridad, permisos o gating.
2. Respetar los contratos congelados de Portfolio Lead (`01`, `02`, `03`, `05`) y la referencia HTML exacta (SHA-256 `6eadaf4b72b55107120cf0b097b65deeba3c7108c07d3f98dd81128b7bf4c846`) para UX/flujo de su ámbito.
3. Leer **el paquete freeze de Steps que el usuario agregará**. La lógica de Steps no se infiere del mockup de Portfolio Lead.
4. El `STARTERIA_MVP_MASTER_PLAN_v1.2.md` de este paquete es **propuesta de alcance de producto**, no autoridad Core aprobada; contextualiza la integración, pero no modifica contratos superiores.
5. Si existe conflicto entre freezes o con Core/ADRs: registrar `CONFLICT / BLOCKED_BY_AUTHORITY`, formular alternativas y pedir decisión. No resolver silenciosamente ni editar los freezes.

## 3. Decisiones de Portfolio Lead ya aprobadas: PRESERVAR

| Área | Obligación de UX/funcionalidad (fuente: PL v1.0) |
|---|---|
| PL-00 Contexto | El Decision Brief inicial se produce fuera de Portfolio Lead; se entra con prompt preparado externamente. No duplicar esa reunión dentro de este flujo. |
| PL-01 Objetivo | Copilot conversacional multi-turn, ayudas de comprensión/redacción y output **Ficha provisional del objetivo** revisable. «Tu avance» es el único panel de progreso persistente. |
| PL-02 Incorporación | Subir documentos en entorno autorizado, pegar texto/CSV/TXT o avanzar **con cero iniciativas**. |
| PL-03 Análisis | Reconstruir trabajo realizado/evidencia y proponer vínculo, Step documental **estimado**, faltantes, posibles duplicidades/solapamientos u otro frente, todo revisable. |
| PL-04 Organización | Retos/líneas visibles cuando aportan claridad; no forzar ontología al usuario; respetar jerarquía corporativa autorizada en dominio. |
| PL-05 Briefs | Crear/editar **brief de convocatoria o de iniciativa existente ANTES de asignar**. |
| PL-06 Asignación | Tabla con responsable, vista del brief, envío, aceptación y Start separados; estado real de Step solo después de Start. |
| PL-07 Inicio | Dashboard consultivo: KPI, baseline, meta, tendencia con fuente, brecha con unidad correcta, capacidad/recursos, alertas y decisiones. |
| PL-08 Portafolio | Detalle de reto/cobertura/iniciativas/equipos/evidencia/bloqueos, no repetición de Home. |
| PL-09 Decisiones | Decision Package proveniente de Step 4 con insights, pruebas, resultados, documentos/prototipos, límites, recomendación y **decisión humana** que retorna al portafolio. |

Los **siete momentos de configuración** de Portfolio Lead son setup de portafolio; **no son** Step 0–4 ni deben introducir un segundo Core.

## 4. Interfaz de ida: Portfolio Lead → Initiative Owner → Steps

Se debe modelar por separado:

1. **Brief externo inicial** (justifica el uso de Portfolio Lead): no es encargo a un equipo.
2. **Objetivo/frente confirmado y reto cuando corresponda:** contexto estratégico con procedencia, versión, KPI/señal, horizonte, restricciones y autoridad conocida.
3. **Iniciativa existente o nuevo encargo de reto:** no tratar invitación de reto como proyecto activo; no crear iniciativas vacías ni incrementar falsamente la cobertura.
4. **Brief del encargo elaborado/revisado por humano:** alcance, qué se sabe, qué falta, evidencias, restricciones, entregable esperado y decisión que se necesita habilitar.
5. **Asignación / envío:** destinatario, alcance de acceso, estado del envío y referencia estable al brief/contenido vigente.
6. **Recepción / aceptación por Initiative Owner:** identidad y autorización reales; la aceptación no significa Start ni Step 0 completado.
7. **Overview / Start:** un único registro de iniciativa/ciclo vinculado; hereda contexto confirmado y restricciones según contrato Core. Solo Start inicia la experiencia real de Steps.

### Datos mínimos que deberá poder consumir Steps (campos conceptuales, no schema técnico autorizado)

| Campo/relación | Fuente y precaución |
|---|---|
| `initiative_id` / identidad de trabajo | Backend canónico tras transición autorizada; no crear al mero analizar. |
| `organization/context_scope` | Scope legítimo, acceso por recurso, roles/grants verificados. |
| `strategic_front_id / challenge_id` cuando corresponda | Vínculo **confirmado**, no `AI_SUGGESTED`. Si no aplica por ruta independiente, no forzar invento corporativo. |
| `objective / metric / target / baseline / horizon` | Valor + unidad + procedencia + estado de confirmación; preservar desconocidos. |
| `challenge_constraints / guardrails / decision_horizon` | Heredados/versionados; cambio crítico exige revisión, no sobrescritura silenciosa. |
| `assignment_brief_id + version` | Encargo revisado; distingue fuente/propuesta/confirmación. |
| `evidence_existing / imported_artifacts` | Con fuente, estado y evaluación de suficiencia pendiente; importado ≠ validado. |
| `receiving_owner + permission_state` | Autenticación, aceptación, revocación e idempotencia. |
| `intended_decision + decision_authority` | Contexto de la decisión que se espera habilitar, no decisión ya tomada. |

**Nota:** la tabla es una interfaz de discusión E2E, no prescribe nuevos modelos Prisma, endpoints ni enum canónico sin auditar Steps y Core.

## 5. Dentro de Steps: frontera protegida

- Una iniciativa asociada al portafolio usa **el mismo Adaptive Core** de una iniciativa individual; no crear variante corporate.
- Mantener las **cinco funciones Step 0–4** y reglas de suficiencia/validación vigentes; no sustituir por las etapas del setup de Portfolio Lead.
- Cuando se importa trabajo ya avanzado, conservar su evidencia y ejecutar **gating retroactivo**, sin declarar automáticamente Step 2/3 completado.
- El **Step estimado** en Portfolio es una lectura documental; el **Step real** corresponde a ciclo/estado gobernado de Steps.
- Cada decisión y evidencia debe conservar procedencia, versiones y quién tiene autoridad humana.
- No imponer mentoría/validador universal nueva o eliminar un gate real por conveniencia visual; reconciliar primero contratos vigentes.

## 6. Interfaz de vuelta: Steps → Portfolio Lead

Después de Step 4, Steps debe poder publicar un **Decision Package** referenciado por `initiative_id / cycle_id / version` y con:

- Contexto estratégico heredado y objetivo/decisión solicitada.
- Qué se hizo y qué artefactos/prototipos se produjeron.
- Resultados observados, métricas, fechas y fuentes (si existen).
- Evidencia positiva, contradictoria, insuficiente, tradeoffs y límites.
- Insights/aprendizajes relevantes.
- Riesgos, incertidumbres pendientes y costes/recursos observados cuando se conozcan.
- Recomendación atribuida a equipo o IA como propuesta, no decisión automática.
- Decisión humana (cuando se adopta): quién, con qué autoridad, razón, fecha, siguiente acción y estado de continuidad.

Portfolio Lead debe reflejar el retorno en **Decisiones, detalle de iniciativa, reto/cobertura, frente y Home**, sin confundir actividad/Step terminado con avance del KPI ni atribución causal (L5/L6). Si falta una medición real, mostrar su ausencia.

## 7. Casos E2E de integración que el nuevo chat debe diseñar y probar

- **C1 — Portafolio con 6–12 iniciativas importadas:** clasificación revisada → una asignada → aceptación → Overview/Start → Core Steps → Decision Package → decisión vuelve al portafolio.
- **C2 — Sin iniciativas:** objetivo confirmado → encargo de reto → invitación → recepción → Start → nueva iniciativa → mismo Core → retorno.
- **C3 — Iniciativa avanzada importada:** evidencia en Step 3 pero Step 1 insuficiente; reconstrucción sin falsos aprobados ni pérdida de trabajo.
- **C4 — Duplicados/solapamientos:** sugeridos y explicados con fuentes; usuario decide revisar, poner en standby o confirmar sin fusión automática.
- **C5 — Cambios y permisos:** cambio material de reto, revocación de owner, reintento del envío, rechazo y refresh con idempotencia/scope.
- **C6 — Evidencia insuficiente:** Step 4 no afirma impacto L5/L6; Portfolio muestra decisión pendiente o resultado no comprobado.
- **C7 — Vista ejecutiva:** Home muestra KPI/última lectura/fuente, brecha con unidades correctas, alertas del equipo y decisión; Portafolio ofrece granularidad por reto.

La aceptación exige evidencia real de los recorridos, no solo wireframes, fixtures determinísticos o visualización en HTML.

## 8. Entregables que pediría al nuevo chat ANTES de implementación

1. `STARTERIA_PL_STEPS_E2E_UNIFIED_JOURNEY_v0.1.md`: journeys con roles, estados, pantallas, decisiones y transiciones para C1/C2; el usuario ve qué hace y por qué.
2. `STARTERIA_PL_STEPS_HANDOFF_INTERFACE_MATRIX_v0.1.md`: campo/evento/estado/owner/fuente/sistema de registro/test por ida y vuelta.
3. `STARTERIA_PL_STEPS_ASIS_TOBE_GAP_MATRIX_v0.1.md`: KEEP/ADAPT/IMPLEMENT/BLOCKED para ambos freezes vs `main` seleccionado; no inferir implementación a partir de mockup.
4. `STARTERIA_PL_STEPS_NO_REGRESSION_ACCEPTANCE_v0.1.md`: escenarios verificables que protegen los **42 PL** más los criterios de Steps que aporte el otro paquete.
5. `STARTERIA_PL_STEPS_IMPLEMENTATION_SEQUENCE_v0.1.md`: sólo después de aceptación de contratos/gaps; slices incrementales, pruebas y gates.

No generar nuevos mockups que sustituyan el freeze de Portfolio Lead ni el de Steps. Si es necesaria una vista integrada de handoff, proponer un **delta acotado** y solicitar confirmación.

## 9. Decisiones abiertas para tratar como conflictos, no supuestos

- ¿Qué contrato **vigente** regula la identidad/creación de una Initiative independiente o nacida de reto?
- ¿Cómo se representa la organización/retos opcionales en UX sin alterar cardinalidad canónica corporativa?
- ¿Qué estados de asignación/Start/Step son canónicos y cuáles solo UI?
- ¿Cómo migran evidencias importadas a Steps sin dar por aprobada su suficiencia?
- ¿Qué validaciones son requeridas por el Core de Steps en el freeze más reciente?
- ¿Cómo vuelve el resultado/decisión al portafolio preservando fuente y sin duplicar impacto?

## 10. Pedido de arranque para nuevo chat (copiar y pegar)

> Vamos a integrar **Portfolio Lead v1.0 congelado** con el **freeze de Steps** que adjunto por separado, para diseñar una experiencia Startería E2E real y unificada. **No rediseñes ni simplifiques ninguna de las dos experiencias ya aprobadas.** Primero lee el acta de freeze, contrato de comportamiento, 42 criterios PL, HTML v1.0, el freeze de Steps y el Core/ADRs vigentes. Identifica los handoffs y conflictos; conserva el mismo Adaptive Core Step 0–4. Separa qué está decidido, qué está implementado y qué aún es hipótesis. Propón los cinco documentos de la sección 8, empezando por el journey y la matriz de interfaces. No implementes ni modifiques código hasta que revisemos la propuesta.
