# Startería — línea base de auditoría funcional

**Corte:** 2026-10-20 04:51 UTC. **Modo:** audit only. **Resultado de entorno:** código y pruebas locales disponibles; journey autenticado bloqueado.

## Identidad verificada

| Campo | Valor / evidencia |
|---|---|
| Repositorio | `https://github.com/DarkCodePE/plataforma-starteria.git` |
| Referencia de matriz v0.2 | `origin/main@75fc358838c34174da858937f4b47b92b8fbf074` (commit local disponible) |
| Checkout usado para pruebas | `feat/KAN-153-recovery-ux@1e689ea5c54f7513e323e30f58e45e7168738c7c` en `starteria-KAN-153-recovery-ux` |
| Equivalencia de código | `git diff --exit-code 1e689ea 75fc358` devolvió 0; el merge de `main` no cambió el árbol de producto probado |
| Estado local inicial | Solo `artifacts/` preexistente sin seguimiento en este checkout; ningún archivo de producto modificado por esta auditoría |
| Backend / frontend / IA desplegados | SHA, URL, flags, proveedor y estado **desconocidos**. El éxito histórico de CD citado por v0.2 no identifica los pods actuales |
| Infraestructura local | `front/node_modules` presente; `ai-service/.venv` ausente; sin listeners en 3001, 5173 ni 8001; `DATABASE_URL` ausente en las pruebas |
| Tenant / cuentas | No se proporcionó tenant aislado, sesión Lead/Owner/viewer ni dataset Orion; no se ejecutaron escrituras, migraciones o acceso productivo |

## Fuentes y autoridad

Se leyó `AGENTS.md`, `docs/STARTERIA_AUTHORITY.md`, `CURRENT_STATE.md`, `STARTERIA_V2_MANIFEST.md` y los contratos Core/Activation del árbol equivalente a `main`. Core factual v0.2 figura **por validar**; Core v0.3 es candidato. El contrato de Activation v0.2 concluye en `Start`. Los freezes Steps/Portfolio del ZIP son TO-BE candidato. El HTML v0.6 y su QA son referencia y evidencia del prototipo, nunca del runtime productivo.

El ZIP de entrada se leyó directamente desde `C:\Users\User\Downloads\STARTERIA_E2E_AUDITORIA_SEGUNDA_PASADA_v02.zip`; no se copió al código. Incluye matriz v0.2, addendum, runbook, dos freezes, HTML y QA. La matriz mantiene 73 IDs: PE 6, PL 13, HO 10, IO 7, ST 17, AI 11, DC 9; 46 P0.

## Pruebas ejecutadas

| Evidencia | Comando focal ejecutado desde `front/` | Resultado | Alcance |
|---|---|---|---|
| [backend-focused-tests.txt](evidence/backend-focused-tests.txt) | `npx vitest run --config vitest.backend.config.ts` con 6 archivos Handoff, coverage, evidence policy, critical change y decision authority | 6 archivos, **36 tests aprobados** | Unitarios con dependencias falseadas; no DB ni navegador |
| [front-focused-tests.txt](evidence/front-focused-tests.txt) | `npx vitest run --config vitest.front.config.ts` con 4 archivos de checkpoint, Handoff shell, Overview y Home | 4 archivos, **28 tests aprobados** | Componentes con mocks; hubo avisos MSW por GET `/portfolio/home` y `/capacity` sin handler en una prueba |
| [security-decision-focused-tests.txt](evidence/security-decision-focused-tests.txt) | `npx vitest run --config vitest.backend.config.ts` con PDF team access, deck feedback y organizational decision | 3 archivos, **16 tests aprobados** | Guards/servicios locales; no certifican IDOR multi-org del despliegue |

Total: **80/80 pruebas focales aprobadas** en 13 archivos. PowerShell reportó `exit_code=1` del pipeline `rtk ... 2>&1 | Tee-Object` por el aviso de `rtk` enviado a stderr; los tres resúmenes de Vitest dicen `Test Files ... passed`, `Tests ... passed`. Ese código de salida de la envoltura queda registrado, no se oculta ni se interpreta como fallo de Vitest.

No se ejecutó `test:portfolio-steps`: `front/scripts/verify-portfolio-steps-integration.ts` crea y borra User, StrategicFront, Challenge y Project mediante Prisma; faltan DB/tenant desechables autorizados. Playwright `front/e2e/portfolio-steps-integration.spec.ts` exige stack Docker Compose y credenciales E2E. Tampoco se ejecutó un LLM real.

## Regla de interpretación

`PASS` en Vitest acredita exclusivamente la aserción local del archivo citado. Ningún T01–T25 obtiene `PASS` funcional por ello. `BLOCKED` significa que el caso tiene pasos definidos pero falta infraestructura o sesión segura; no significa fallo observado del producto. La comparación estática se registra en la matriz delta y no se extrapola a una versión desplegada desconocida.
