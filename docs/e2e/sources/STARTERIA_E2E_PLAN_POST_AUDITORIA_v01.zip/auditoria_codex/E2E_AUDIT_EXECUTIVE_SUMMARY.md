# Diagnóstico ejecutivo E2E — Portfolio Lead → Steps → Portfolio

**Dictamen al 20/10/2026:** la plataforma tiene piezas reutilizables de Portfolio, Handoff, Initiative Overview, Adaptive Core, PDF/deck y decisión. **La experiencia objetivo integrada no está acreditada**: 25/25 escenarios de navegador/API quedaron `BLOCKED` sin tenant/sesiones/versión desplegada; 80 pruebas focales locales pasaron y tienen alcance de componente/servicio. No se observó un fallo E2E en un despliegue, por lo que no hay `FAIL` ni `PASS` funcional.

## Qué existe y qué falta acreditar

| Tramo | Estado sustentado | Riesgo para el journey |
|---|---|---|
| Portfolio Lead | CRUD Front/Challenge, Home, capacity, overlaps y coverage presentes; pruebas locales de Home/coverage. | Import de 20 work items, contribución, alineamiento y lectura ejecutiva con fuentes no observados en UI. |
| Handoff | Assignment tipado, invitación, Accept/Reject/Start separados, versiones e idempotencia con 14 tests locales de respuesta/atomicidad. | `Start` en `HandoffInvitationPage.tsx:51–54` solo actualiza preview: no hay puente acreditado hacia formular o reanudar Initiative. |
| Initiative Owner | `DashboardPage` muestra «Mis iniciativas», `CreateProjectPage` e `InitiativeOverviewPage` existen; 9 tests locales Overview. | No se comprobó la composición de assignments + iniciativas sin duplicar ni los tres recorridos A/B/C con identidad estable. |
| Steps 0–4 | Adaptive Core, workspace, outputs, gates y agentes especializados existen; tests de checkpoint/critical change pasan. | `AdaptiveCheckpointWorkspace.tsx:368` muestra preguntas por lista; Copilot conversacional y Card semántica por cada input son TO-BE no verificados. |
| Archivos/evidencia | PDF con propuesta/confirmación/edición y guard team access; XLSX en Bootstrap Portfolio. | Selector de revisión inicial no admite XLSX. Ingesta «desde cualquier Step» y trazabilidad claim→Card no demostradas. |
| Decisión/retorno | Servicio DecisionRequest, propagación a Portfolio y feedback real del deck con tests locales. | No hay trace Step 4→decisor→Home/coverage, proveedor IA/credit ni separación observada de inversión prevista vs real. |

## Hallazgos críticos

1. **HO-07 / IO-01 — frontera post-Start de reto.** Esperado: Start → formulación → confirmación humana → una Initiative y Step 0. Observado en `front/src/app/pages/HandoffInvitationPage.tsx:51–54`: llamada a `startAssignedWork` y actualización de preview; no se encadena ese flujo desde el handler. Evidencia: lectura de código, T08 `BLOCKED`. **NEW** contrato/puente post-Start; **ADAPT** creación existente. Aceptar cuando un reintento no duplique Initiative, exista vínculo al Challenge y viaje contexto versionado.
2. **HO-08 / IO-04 — continuidad avanzada.** Esperado: la Initiative existente conserva ID, Step e historia. Observado: modelo y Overview disponibles, continuidad post-Start no acreditada; T09 `BLOCKED`. **ADAPT** enrutamiento/revisión. Aceptar con mismo project ID, fuentes preservadas y gaps explícitos sin aprobar Steps retroactivamente.
3. **ST-04/ST-05/AI-02/AI-09 — interacción de Steps.** Esperado: conversación contextual y Card que distingue hecho, hipótesis, duda y evidencia. Observado: `questions.map` y `textarea` por pregunta; 9 tests locales pasan ese componente, pero no el criterio semántico; T11/T25 `BLOCKED`. **ADAPT** workspace/outputs, **NEW** motor semántico acotado. Aceptar con entradas «no sé», resumen con varias fuentes y texto irrelevante sin promoción automática ni salto falso.
4. **AI-07/AI-08 — fuentes.** Esperado: Owner incorpora PDF+Excel temprano y corrige claims sin sobrescribir. Observado: `ReviewDocumentDropzone.tsx:10` acepta PDF/DOCX/TXT/MD; `PortfolioBootstrapHome.tsx:543` acepta CSV/XLSX; PDF/proposals tienen API. T12 `BLOCKED`. **ADAPT** integración tras decidir alcance XLSX. Aceptar con provenance por claim, versión y revisión humana.
5. **HO-06/AI-10 — desbloqueo.** Esperado: solicitud del Owner al Lead con estado y retorno. Búsqueda `SupportRequest` en backend/front sin circuito localizado; esto no prueba ausencia global. T17 `BLOCKED`. **NEW** tras inventario de alertas existentes. Aceptar con request trazable y respuesta de actor autorizado.
6. **DC-02/DC-04 — decisión y retorno.** Esperado: paquete con resultados, recursos, límites y solicitud; decisión humana repercute en Portfolio. Observado: servicios y 13 tests locales de decisión/deck; secuencia runtime pendiente; T20/T21 `BLOCKED`. **KEEP/ADAPT**. Aceptar con request ID causal y separación esperada/observada/atribuida.
7. **DC-07/PL-13 — seguridad.** Esperado: ninguna lectura/escritura cross-org, viewer sin escritura. Observado: 3 tests locales de guard PDF aprobados; no cubren todas las rutas ni el despliegue. T23 `BLOCKED`. **KEEP** guard existente, **ADAPT** cobertura. Aceptar con matriz de permisos por recurso y rol sin fuga de metadatos.

Las referencias de archivo, endpoint, expectativa, evidencia, tratamiento y aceptación por ID se amplían en [GAP_MATRIX_RUNTIME_DELTA.md](GAP_MATRIX_RUNTIME_DELTA.md). El [registro T01–T25](E2E_TEST_EXECUTION_REGISTER.md) explica cómo convertir cada bloqueo en observación.

## Riesgos y decisiones previas

- **Autoridad D-03:** Core factual v0.2 (por validar), Core v0.3 candidato y Activation v0.2 discrepan sobre cuándo un Challenge sin Initiative puede considerarse activo. Se necesita ADR de estados y cobertura antes de cambiar lifecycle.
- **B-01:** el contrato Activation acaba en Start. La creación/reanudación post-Start necesita contrato propio, permisos e idempotencia; no debe ser un efecto lateral del botón.
- **Evidencia/currentness D-09:** definir cómo cambios de KPI, documentos y snapshots marcan outputs dependientes `requires_review` y quién reconfirma.
- **Decisión/beneficios D-08:** separar contribución esperada, resultado observado y atribución; decidir actor/umbral para inversión o cierre. Evitar ROI generado sin fuente.
- **Migración:** `CURRENT_STATE`/Manifest sitúan Overview/Steps en runtime legacy. `PE-03` y `DC-08` proponen REMOVE condicionado a inventario de consumidores, compatibilidad y regresión.

## Secuencia propuesta por dependencias, sin cambios ejecutados

1. **Cerrar línea base runtime:** tenant aislado, cuentas y dataset ficticio, SHA/flags de tres servicios, acceso a navegador/Network y lectura DB del tenant. Ejecutar T01–T07 y T23 primero; registrar estado canónico y permisos.
2. **Resolver D-03 y B-01:** ADR para Challenge asignado/activo, evento post-Start, autoridad de confirmación, identidad de Initiative e idempotencia. Reutilizar Handoff y `CreateProjectPage`.
3. **Cerrar rutas A/B/C:** reto nuevo, Initiative avanzada e independiente convergen en Overview/Step 0 sin duplicar entidades. Ejecutar T08–T10 y reentrada T24.
4. **Card/evidencia/gates como slice de Step 0:** inventariar PDF, Bootstrap, outputs y planner; definir contrato claim/provenance/review; validar T11–T13/T25 antes de extender a Steps 1–4.
5. **Adaptación por Step y soporte:** integrar especialistas y SupportRequest con reglas de autoridad; validar refutación, proxy de KPI, dependencia y resultados negativos (T14–T19/T22).
6. **Decisión y retorno:** reutilizar deck feedback, DecisionRequest y return propagation; validar T20–T21 con recursos reales/previstos, fallos IA/crédito y decisor correcto.
7. **Regresión y retirada:** completar T23–T25 en versiones desplegadas y decidir `REMOVE` de rutas legacy solo tras consumidores identificados.

**Estado de la auditoría:** diagnóstico documental/local completado; certificación funcional E2E pendiente de entorno de prueba. Ninguna prioridad ni tratamiento provisional sustituye decisión de producto.
