# Preparación para implementar — decisiones y dependencias

**Estado:** propuesta técnica de secuencia; no autoriza editar código, contratos o datos. El árbol equivalente a `main@75fc358` y las pruebas locales muestran piezas aprovechables. La falta de tenant/versión desplegada impide declarar lista una solución E2E completa.

| Tramo / IDs | Puede prepararse con la autoridad actual | Decisión previa o validación requerida | Gate de entrada a implementación |
|---|---|---|---|
| Portfolio Home, cobertura, Handoff existente (PL-01/04/10/13, HO-01/03/04) | Inventario de consumidores, contratos API, trazas y pruebas focales; conservar servicios/guards. | T01–T07/T23 sobre tenant para separar defecto real de diferencia TO-BE. | SHA desplegado, roles y fixtures conocidos; regresión del flujo actual. |
| Post-Start Challenge (HO-07/IO-01) | Diseño de integración que reutilice assignment tipado y creación de Project; contrato de idempotencia para propuesta/confirmación. | ADR **D-03** de estado Challenge y decisión **B-01** del evento posterior a Start, actor y autorización. | T04/T06/T07 reproducidos; reglas de creación/coverage aprobadas. |
| Post-Start Initiative existente (HO-08/IO-04/05) | Mapa de identidad, snapshots, Step y evidence existentes; plan de no duplicación. | Política de revisión de evidencia heredada y gating retroactivo; confirmar si se retoma ciclo o se abre otro. | T09 con Initiative avanzada ficticia y misma ID antes/después. |
| Iniciativa independiente (IO-02) | Adaptación de `CreateProjectPage` y Overview sin vínculo corporativo obligatorio. | Validar experiencia objetivo con autoridad de Initiative Owner y contrato de creación; T10. | Una entidad, Step 0 coherente, sin requisito de Portfolio/Challenge. |
| Copilot/Card Step 0 (ST-03–07, AI-01–03/09) | Prototipo acotado sobre planner, outputs y workspace; dataset de evaluación con «no sé», texto irrelevante, párrafo con varias fuentes y fuente contradictoria. | Contrato de claim/provenance/confirmación y límites de autoridad IA frente a Adaptive Core; no promover freeze automáticamente. | T11/T13/T25 más casos de suficiencia semántica reproducibles. |
| PDF/Excel/evidencia (AI-07/08, T12/T15) | Inventario de PDF proposals, import XLSX de Bootstrap y dropzone de revisión; modelo de fuente/versión. | Decidir formato XLSX y fase permitida para Owner, seguridad de archivos, corrección y freshness D-09. | Dos archivos ficticios, corrección visible, fuente original inmutable. |
| SupportRequest (HO-06/AI-10) | Inventario de alertas/mensajería y contrato de actor/estado. | Producto decide categorías, SLA/cola, permisos y retorno; confirmar ausencia de circuito equivalente antes de NEW. | T17 con solicitud, recepción y respuesta trazadas. |
| Steps 1–4 (ST-08–17) | Adaptar agentes Research/Solution/Experiment/Narrative y checkpoints existentes; diseñar evals de refutación, proxy y resultados negativos. | Criterios de suficiencia por Step, política de revisión y validadores humanos; no usar texto presente como gate. | Step 0 estabilizado y T14–T19/T22 con evidencia real. |
| Decision Package/retorno (DC-01–05) | Reutilizar `DecisionRequest`, deck feedback y `decision-portfolio-return.ts`. | Autoridad de decisión, umbrales, inversión real vs prevista, atribución D-08, fallo IA/crédito. | T20/T21 con decisión de actor válido y lectura Portfolio causal. |
| Rutas legacy (PE-03/DC-08) | Solo inventario de tráfico, enlaces y consumidores. | Decisión de migración y compatibilidad; `REMOVE` no equivale a borrar ahora. | Alternativa probada y regresión de usuarios/rutas existentes. |

## Secuencia de trabajo propuesta

```text
S0 Entorno y evidencia T01–T07/T23
  → S1 ADR D-03 + contrato B-01 + política D-09
  → S2 puentes A/B/C con identidad/idempotencia
  → S3 contrato Card/claim/gates + Step 0 + T11–T13/T25
  → S4 Steps 1–3, SupportRequest y cambios de mandato + T14–T19/T22/T24
  → S5 Step 4, Decision Package, autoridad y retorno + T20/T21
  → S6 regresión cross-org y decisión de retirada legacy
```

**Criterio de promoción del diagnóstico:** las 46 P0 necesitan fuente confirmada, caso observable, deployment SHA, decisión de autoridad, responsable y tratamiento aprobado. Este entregable conserva esas casillas abiertas explícitamente en la matriz delta; los 80 tests locales no las sustituyen.
