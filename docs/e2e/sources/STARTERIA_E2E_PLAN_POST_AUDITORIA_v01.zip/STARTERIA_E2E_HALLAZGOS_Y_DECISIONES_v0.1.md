# STARTERÍA — Resumen de hallazgos y decisiones tras los informes de Codex

**Documento de lectura rápida, 2026-10-20.** Basado en `e2e-audit-results.zip` y en los freezes de diseño E2E. No prueba runtime, no crea autoridad de producto.

## Resultado acreditado

- Checkout equivalente por diff a `main@75fc358`: sí, según `RUNTIME_BASELINE.md`.
- 80/80 tests focales aprobados: 36 backend, 28 frontend, 16 seguridad/decisión. Tres grupos, 13 archivos. No equivalen a viaje E2E.
- T01–T25: todos BLOCKED por entorno. No hay PASS/FAIL funcional; ningún hallazgo del mockup v0.6 es automáticamente un fallo de producción.
- 73/73 capacidades trazadas y 46 P0 sin cierre funcional; KEEP/ADAPT/NEW/REMOVE siguen propuestas.

## Brechas que orientan la prioridad

| Prioridad | IDs | Hecho sustentado | Qué no debe asumirse |
|---|---|---|---|
| Alta | HO-07 / IO-01 | El handler Start no encadena formulación de Initiative nueva. | Que se puede escribir Initiative silenciosamente dentro de Start. |
| Alta | HO-08 / IO-04 | Existe infraestructura de Initiative/Overview, pero reanudación avanzada post-Start no acreditada. | Que el Step correcto sea siempre Step 0 o que haya aprobación retroactiva. |
| Alta | ST-04/ST-05/AI-02/AI-09 | Workspace hace preguntas por lista; semántica input→Card no acreditada. | Que los tests de componente demuestran Copilot adaptativo. |
| Alta | AI-07/AI-08 | PDF proposal e import XLSX están en superficies distintas. | Que basta habilitar selector de archivo para tener provenance de claims. |
| Alta | HO-06/AI-10 | No se localizó SupportRequest equivalente con la búsqueda realizada. | Que no existe ningún circuito alternativo en toda la plataforma. |
| Alta | DC-02/DC-04 | Hay servicios y tests de decisión/retorno; secuencia E2E sin prueba. | Que el estado se refleja correctamente en Portfolio Home en producción. |
| Alta | DC-07/PL-13 | Guards PDF focales probados; matriz cross-org global no. | Que todo el entorno tenga la misma política de acceso. |

## Resoluciones pendientes antes de implementación de dominio

- **D-03:** estados y cobertura Challenge/Initiative: requiere reconciliar Core factual y experiencia candidata.
- **B-01:** contrato post-Start: acción, actor, evento, confirmación, idempotencia y vínculo Challenge/Initiative.
- **B-02:** continuidad de iniciativa avanzada, identidad estable, history, Step legítimo y revisión retroactiva.
- **B-03:** actor que confirma contribución y cambios del mandato.
- **D-08:** impacto previsto / observado / atribuible; límites de ROI.
- **D-09:** versionado de mandato, evidence y `requires_review`.

## Secuencia práctica

1. Unificar en diseño Portfolio Lead final + UX Steps Copilot/Card + tres entradas + retorno a Portfolio, sin nuevas entidades canónicas.
2. Preparar tenant/roles/SHAs y verificar T01–T07/T23 para entender el runtime.
3. Resolver autoridad D-03/B-01/B-02 y después construir puente post-Start en slice controlado.
4. Integrar extracción semántica/claim/Card/gates en un Step 0 acotado antes de extender a 1–4.
5. Ejecutar tests de Steps, decisión y retorno con pruebas reales y roles correctos.

**Resultado:** avanzar el diseño ahora, pero no autorizar implementación masiva ni declarar cerrada la auditoría funcional.

**Fuente detallada:** `STARTERIA_E2E_PLAN_ACCION_POST_AUDITORIA_v0.1.md`.
