# STARTERÍA — Plan de acción integrado después de la auditoría E2E v0.1

**Fecha:** 2026-10-20  
**Estado:** PROPUESTA DE PLAN — NO AUTORIZA IMPLEMENTACIÓN, ADR NI MODIFICACIÓN DEL CORE  
**Objetivo:** convertir el diseño objetivo Portfolio Lead → Handoff → Initiative Owner/Steps 0–4 → Decision Package → Portfolio en una experiencia E2E unificada, conservando componentes existentes, probando los límites de autoridad y evitando validaciones ficticias.

## 0. Evidencia y límites

**Fuente primaria:** ZIP aportado por el usuario `e2e-audit-results.zip`, que contiene `RUNTIME_BASELINE.md`, `E2E_TEST_EXECUTION_REGISTER.md`, `GAP_MATRIX_RUNTIME_DELTA.md`, `E2E_AUDIT_EXECUTIVE_SUMMARY.md`, `E2E_IMPLEMENTATION_READINESS.md` y logs focales. **Referencias TO-BE:** `STEPS_TARGET_DESIGN_FREEZE_v0.1.md`, `STARTERIA_PORTFOLIO_STEPS_E2E_INTEGRATION_v0.1.md`. Ambas son propuestas de diseño; no cambian el Core factual ni ADRs.

- El checkout auditado `feat/KAN-153-recovery-ux@1e689ea` tiene el mismo árbol de producto que `main@75fc358`, según `git diff --exit-code` de Codex.
- 80/80 tests focales de 13 archivos pasaron: 36 backend, 28 frontend, 16 seguridad/decisión. Son pruebas de unidad/componente con dobles, no validación del journey.
- T01–T25: **0 PASS, 0 FAIL, 25 BLOCKED** por falta de tenant, sesiones, stack, versión desplegada y datos ficticios autorizados. No atribuir a producción fallos observados únicamente en el HTML v0.6.
- Matriz v0.2: 73 IDs, 46 P0. La cantidad de P0 no implica 46 desarrollos: varios dependen de la misma frontera, capacidad o entorno común.
- La inspección ha confirmado que `HandoffInvitationPage.tsx` ejecuta `startAssignedWork` y actualiza la vista, pero **no acredita** la formulación o reanudación de una Initiative desde esa acción. No se ha demostrado ausencia de cualquier otra ruta en el sistema.
- Este plan no depende de declarar todo como defectuoso y no presenta fechas, estimaciones ni certificación que no se hayan medido.

## 1. Norte del E2E que se protege

```text
Portfolio Entry / incorporación de trabajo existente / entrada directa
  → Portfolio Lead: entender objetivo de negocio, KPI/señal, frentes, retos, cobertura y prioridades
  → Assignment de Challenge o Initiative existente, con brief/historial/versiones
  → Invitation → Accept/Reject → Overview → Start (acciones distintas)
  → Post-Start según target:
       A. Challenge sin Initiative → formular propuesta → confirmación humana → Initiative única
       B. Initiative existente → identidad/Step/evidencia/historia preservados → revisión de gaps
       C. Independiente → definir propuesta propia → confirmación → Step 0, sin jerarquía corp. obligatoria
  → Steps 0–4: conversación contextual + Card viva tipada + herramientas cuando aporten
  → Evidencia y checkpoints de suficiencia, gobernados por Adaptive Core
  → Decision Package → decisión de actor autorizado
  → Portfolio Home: retorno causal de señales, coverage, aprendizaje, recursos y seguimiento
```

**Separación de responsabilidad:** Portfolio Lead establece y gobierna el resultado del negocio; Initiative Owner formula y ejecuta dentro del mandato. IA asesora, no canoniza estrategia, aprueba evidencia, concede permisos ni atribuye ROI automáticamente. La Card no es un contenedor arbitrario de respuestas ni una autoridad paralela al Core.

## 2. Tres carriles paralelos y un punto de convergencia

### Carril A — Producto/UX: unificación del diseño congelado (se puede comenzar ahora)

**A1. Reunir fuentes congeladas, sin rediseño de cero.** Portfolio Lead último mockup/contrato congelado, freeze de Steps, contrato E2E, HTML v0.6 solo como referencia de layout, QA de errores, registro de decisiones. El ZIP de auditoría no demuestra por sí solo cuál es el mockup final congelado de Portfolio Lead: traerlo a este carril antes de cerrar el HTML unificado.

**A2. Especificar las fronteras en una sola narrativa de experiencia:** creación/selección de objetivo, Challenge, Assignment, brief/antecedentes, Start, A/B/C y retorno a Portfolio. Pantallas y acciones deben referirse a los mismos IDs/mandatos, no recrearlos.

**A3. Definir para cada Step la misma gramática UX:** conversación como espacio principal, una Card viva de resultado esperado/lo construido/pendiente/estado de revisión, historial/evidencia accesible, herramientas contextuales; funciones y outputs propios de Step 0/1/2/3/4. Evitar menús separados «Retos recibidos» en la vista Initiative Owner.

**A4. Construir un solo prototipo E2E funcional de interacción, etiquetando explícitamente la IA simulada.** Debe representar los tres recorridos, las diferencias de autoridad y un ciclo de decisión. No usar respuestas simuladas para aprobar claims.

**Salida:** `STARTERIA_E2E_UNIFIED_EXPERIENCE_CONTRACT_v0.1.md` + prototipo navegable + QA con casos A/B/C. **Estado:** TO-BE candidato, sujeto a las decisiones de autoridad.

### Carril B — Entorno/pruebas: obtener verdad de runtime (Codex, audit only)

**B1. Identificar SHA desplegado de front/back/ai, URL, feature flags, storage, proveedor IA y permisos; no inferirlos de CI exitoso.**

**B2. Preparar un tenant E2E aislado y fixtures sintéticos autorizados:** Lead, Owner nuevo, Owner avanzado con historia, independiente, viewer, actor ajeno; reto sin iniciativa, iniciativa avanzada con material, PDF, XLSX y cambio de KPI. Registrar IDs y before/after en DB del tenant solamente.

**B3. Ejecutar tests T01–T07 y T23 primero; luego T08–T10, T11–T19, T20–T25, únicamente con los recursos/autoridad disponibles.** Capturar Network, respuesta HTTP, request ID, screenshot saneado y DB. Cada caso se etiqueta PASS/FAIL/BLOCKED/NOT_RUN; un FAIL requiere reproducciones, un BLOCKED no se convierte en FAIL.

**Salida:** `E2E_TEST_EXECUTION_REGISTER_v0.2.md` con evidencia runtime y matriz delta actualizada. **Estado:** ninguna afirmación de certificación sin resultados de sesión real.

### Carril C — Autoridad y arquitectura: resolver antes de codificar mutaciones de dominio

**C1 D-03:** distinguir Challenge creado/asignado/aceptado/en ejecución de Initiative existente/activa y cobertura. El contrato de Handoff admite Challenge Assignment sin Initiative y el Core candidato presenta tensión: proponer ADR donde corresponda, **no fabricar Initiative al aceptar**.

**C2 B-01:** definir el boundary post-Start: `Start` confirma comienzo de encargo, pero la creación de Initiative será acción posterior, explícita, idempotente, con actor y mandatos versionados. Determinar si el adaptador se monta en ruta/servicio existente; no esconder escrituras en el botón Start.

**C3 B-02:** continuidad de Initiative avanzada: preservar ID y fuentes; evaluar gaps con revisión retroactiva; no reabrir/reaprobar Steps automáticamente. Decidir regla de ciclo/Step legítimo.

**C4 B-03 + D-09:** confirmar autoridad para vínculo de contribución, cambios de mandato/snapshot y revisión de outputs dependientes; conservar historial, flags `requires_review` donde estén autorizados.

**C5 D-08:** definir lo mínimamente trazable de impacto: beneficio **esperado**, señal **observada**, contribución **no necesariamente atribuida**, inversión planificada y real con fuentes. No crear L5/L6 ni ROI atribuido por inferencia.

**C6 IA/Card:** especificar contrato no canónico de `input → interpretación → propuesta de deltas por claim → revisión humana material → estado estructurado → evaluación de suficiencia → siguiente intervención`, separado del command/permission layer existente. Comprobar primero reutilización de orquestador/agentes, planner, workspace, outputs y PDF extraction.

**Salida:** registro de decisiones con resolución humana, ADRs cuando corresponda, contrato funcional de motor IA y contratos de handoff/outputs. **No promover Core v0.3 automáticamente.**

### Convergencia — cuando A, B y C entreguen resultados verificables

Reconciliar TO-BE con matriz de brechas, identificar las APIs/modelos reales reutilizables, pactar IDs estables, actualizar acceptance tests y autorizar slices. Ningún mockup introduce entidad o rol canónico por sí solo.

## 3. Orden propuesto de slices de implementación (no ejecutados)

| Slice | Dependencia | Alcance mínimo | Reutilizar antes que crear | Gates de aceptación y T relacionados |
|---|---|---|---|---|
| S0 Baseline controlado | Tenant autorizado | Verificar roles, SHA, estado DB y journeys actuales | CI, API/routers, E2E actuales | T01–T07, T23 con observación; seguridad confirmada |
| S1 Gobernanza y puente post-Start | D-03, B-01 | Challenge Start → formulación y confirmación → una Initiative; existing → misma ID; independiente → creación propia | HandoffAssignment, CreateProjectPage, Overview, ProjectService | T08, T09, T10, T24; reintentos no duplican |
| S2 Contexto/ingesta temprana | B-02, D-09, permisos | Brief/historial y PDF o fuentes permitidas antes de Step; claims trazables | PDF proposals, Bootstrap import, Core outputs | T11, T12, T15, T22; fuente y versión intactas |
| S3 Step 0 conversación + Card | Contrato IA/card/gate | Copilot trabaja libremente, organiza semánticamente, no fuerza hipótesis ni completa por longitud | AdaptiveCheckpointWorkspace, planner, agentes y UI útil v0.6 | T11, T13, T25; desconocido/irrelevante no crea claim |
| S4 Steps 1–3 + desbloqueo | S3 estabilizado | Investigar/contrastar; idear/diseñar; probar/interpretar; decidir no iterar; SupportRequest si no existe equivalente | Research/Solution/Experiment agents, módulos Steps existentes | T14–T19, T22; proxy vs outcome explícito |
| S5 Step 4 / retorno Portfolio | S1–S4 + D-08 | Decision Package con evidence/risks/resources; solicitud, autorización y retorno causal al Challenge/Portfolio | deck feedback, DecisionRequest, decision-return y coverage | T20–T21; decisión solo humana, sin ROI inventado |
| S6 Regresión y limpieza | S0–S5 verificadas | Permisos cross-org, reentrada/error IA, consumidores legacy, gobernanza V2 | tests, métricas y read models existentes | T01–T25 según scope; REMOVE solo tras compatibilidad |

**No todos los slices son necesariamente PRs únicos.** Dividir por cambios atómicos y frontera de autorización, manteniendo rollback y tests de regresión. No presentar S3 (visual) como migración V2 completa si no hay IA, persistencia y gates reales.

## 4. Escenarios que deben proteger el valor del MVP

1. Lead prioriza objetivo y asigna Challenge sin Initiative → Owner entiende mandato, acepta, pulsa Start, formula y **confirma** una sola Initiative.
2. Owner recibe Initiative avanzada con evidencias en un Step posterior → misma identidad, trabajo preservado, gaps y fuentes visibles, sin aprobación retroactiva.
3. Owner independiente empieza sin necesidad de jerarquía corporativa artificial.
4. Owner sin contexto responde «no sé» → Copilot ayuda a encontrar proceso, responsables y fuentes; la Card marca desconocido, nunca propuesta ficticia.
5. Owner aporta documentos/antecedentes al inicio → síntesis propone claims con procedencia, revisiones y versiones; no sobrescribe con otro archivo.
6. Owner piensa que IA es solución → evidencia demuestra posible problema de coordinación; se reencuadra sin cambiar el mandato estratégico de Lead.
7. Step 2 quiere conseguir leads reales, pero solo tiene Figma → no se confunde validación de comprensión con adquisición real; se ofrece prueba alternativa o proxy explícito.
8. Step 3 evidencia refutada/mixta → no se declara éxito; se permite recomendar cierre/pausa/seguir sin forzar iteración ni aprobación IA.
9. Owner solicita desbloqueo; actor adecuado recibe y responde; no obtiene permisos automáticamente.
10. Step 4 presenta paquete sustentado → decisor legítimo actúa → lectura Portfolio cambia trazablemente, con inversión prevista/real diferenciada.
11. Fallo/timeout/recarga o acceso cross-org: no pérdida ni duplicación y no fuga de datos.

## 5. Qué NO hacer ahora

- No pedirle a Codex implementar todas las 73 filas/P0 en un solo cambio.
- No «arreglar» post-Start introduciendo creación implícita en Handoff antes de B-01 y D-03.
- No usar el HTML v0.6 como especificación de IA; su QA detectó asignación incorrecta en Card y gate engañoso.
- No imponer chat como única forma de edición: Card/workspace estructurado sigue siendo sistema de registro; ofrecer revisión directa.
- No afirmar que pruebas focales locales certifican runtime ni que los 25 BLOCKED son bugs.
- No borrar rutas legacy `PE-03/DC-08` hasta conocer consumidores y tener alternativa probada.
- No confundir una recomendación de IA con aprobación de StrategicFront/Challenge/Initiative/evidence/Decision.

## 6. Entregables de cierre antes de autorizar construcción

| Entregable | Dueño sugerido | Estado a producir |
|---|---|---|
| Diseño visual E2E único + mapa de pantallas de roles | Product Strategy/UX | Candidato para aprobación humana |
| Registro de decisiones D-03/B-01/B-02/B-03/D-08/D-09 y ADRs aplicables | Product Owner + responsable técnico | Aprobados / pendientes explícitos |
| Contrato de motor cognitivo / Card tipada y revisión | Product Strategy + AI Lead | Testable, compatible con Adaptive Core |
| AS-IS runtime (tenant/SHAs/flags) + resultados T01–T25 | QA/Codex | Evidencia observada; bloqueos honestos |
| Matriz final KEEP/ADAPT/REMOVE/NEW con owners, dependencies y pruebas | Tech Lead/Product | Backlog aprobado por slices |
| Smoke/regresión E2E en entorno controlado | QA/Engineering | Pass/Fail material, no inferencias |

## 7. Decisiones propuestas para discutir (no aprobadas)

| ID | Propuesta mínima | Por qué | Veredicto |
|---|---|---|---|
| D-03 | Challenge `asignado/aceptado` puede existir sin Initiative; `en ejecución`/coverage dependen de estados acordados, sin inferir «Initiative activa». | Evita entidad ficticia y métrica engañosa. | PENDIENTE ADR/ratificación |
| B-01 | Mantener `Start` como evento de Handoff separado; al salir mostrar acción post-Start explícita para formular o recuperar Initiative. | Respeta contrato Activation y human-in-the-loop. | PENDIENTE contrato |
| B-02 | Importar contexto/history y evaluar gating retroactivo; escoger Step legítimo solo con revisión/evidencia. | Preserva inversión previa sin validar automáticamente. | PENDIENTE contrato |
| B-03 | Lead/autoridad estratégica confirma cambios materiales y vínculos del mandato; Owner confirma lo que ejecutará dentro del alcance. | Evita mutaciones de jerarquía por IA. | PENDIENTE gobernanza |
| D-08 | MVP rastrea expected/observed/uncertain, sin atribución L5/L6 salvo evidencia. | Muestra valor y protege rigor de métricas. | PENDIENTE |
| D-09 | Cambio en mandato/fuentes crea nueva versión y requiere evaluar dependencias; no muta outputs históricos. | Protege currentness y auditoría. | PENDIENTE |

## 8. Siguiente acción concreta

**En producto/UX:** recuperar el último HTML/congelamiento específico de Portfolio Lead y unificar las pantallas con el shell de Steps; no rediseñar ambos sistemas. Resolver la interacción visual de tres entradas y el puente post-Start **como propuesta** condicionada a autoridad.

**En Codex/QA:** proporcionar en un entorno autorizado tenant/roles/SHAs/fixtures y correr la primera tanda T01–T07/T23; devolver registro con evidencia. Si no está disponible, seguir con diseño contractual y no llamar FAIL al BLOCKED.

**En gobernanza:** celebrar decisión breve D-03/B-01/B-02 con responsables antes de empezar código del puente; tratar IA/Card como segundo vertical controlado y no como refactor E2E masivo.

Al converger las tres líneas, actualizar esta propuesta a un plan de implementación autorizado, con acceptance tests, rollback y ownership por slice.
