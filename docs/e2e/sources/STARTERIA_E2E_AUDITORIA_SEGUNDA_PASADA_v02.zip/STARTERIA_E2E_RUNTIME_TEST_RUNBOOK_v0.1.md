# STARTERÍA — Runbook de pruebas funcionales E2E: Portfolio Lead → Steps → Portfolio

**Estado:** INSTRUCCIONES PREPARADAS / NO EJECUTADAS · 20/10/2026 · `AUDIT ONLY` · artefacto complementario a la matriz v0.2.  
**Objetivo:** convertir cobertura código+CI en comprobación de la **experiencia real**. Evitar que el mismo problema reaparezca al desplegar.

## A. Requisitos antes de empezar

- Ambiente: **tenant de prueba aislado**, sin PII ni clientes reales. Acceso autorizado a interfaz y endpoints de la versión objetivo.
- Participantes de prueba: un Portfolio Lead, un Initiative Owner que desconoce el trabajo asignado, un Initiative Owner que posee 2 fuentes (PDF/Excel) y una iniciativa avanzada, y un viewer/actor no autorizado; cuentas y permisos **creados por administración**, no copiados aquí.
- Registrar: URL efectiva, SHA de backend/frontend/IA realmente desplegado, flags activos, estado del servicio LLM, timestamp y prueba de acceso. No asumir que el commit `main` es la versión visible.
- Obtener snapshots previos de retos/iniciativas y datos de prueba y autorización para operaciones de escritura dentro del tenant. No hacer borrados ni migraciones productivas.
- Herramientas: navegador Chromium/Edge + capturas/Network HAR saneado, logs/request IDs, lectura DB en tenant de prueba cuando esté autorizado; Playwright para repetir caminos. No guardar secretos en evidencias.
- Si se usa GitHub Actions: CD [#39080710106](https://github.com/DarkCodePE/plataforma-starteria/actions/runs/39080710106) prueba release scoped, **no** este journey completo. El `prod-api-smoke.sh` realiza solo lecturas GET y puede ser omitido por flags.

## B. Protocolo de recorridos — ejecutar en orden y detenerse ante brechas materiales

### Recorrido 1. Portfolio Lead con contexto e iniciativas existentes

**Dataset:** empresa ficticia «Orion», objetivo reducir tiempo de onboarding, 2 Strategic Fronts, 4 Challenges, 20 work items: 3 potencialmente duplicados, 2 sin relación estratégica, 1 con evidencia de piloto anterior.

1. Ingresar con rol Lead. Confirmar home y contexto ya registrado (sin repetir onboarding de otra empresa).
2. Declarar o recuperar objetivo y señal, sin fabricar baseline, KPI, ROI ni avance.
3. Importar 20 work items. Confirmar orden, fuente, versionado, duplicidad, conflicto, alineamiento provisional y necesidad de confirmación humana.
4. Revisar que **Work Item ≠ Initiative** y que varios retos/iniciativas no se convierten en entidades duplicadas por abrir tarjetas.
5. Confirmar un reto sin Initiative y otro con Initiative existente. Tomar captura del resultado y estado canónico.
6. Generar assignment, recibir invitación y comprobar trazabilidad y estados del Lead; observar si se puede consultar ayuda.

**Casos:** T01–T05, T21 (parcial). **Bloqueos graves:** inventar alineamiento, crear una Initiative al importar/aceptar, exponer datos cross-org.

### Recorrido 2. Reto asignado — propietario sin conocimiento previo

1. Iniciar sesión como Initiative Owner que recibe un reto, no como Portfolio Lead.
2. Abrirlo desde **Mis iniciativas**; leer brief, objetivo, restricciones, responsable y qué se espera. No separar «Retos recibidos» en otro menú obligatorio.
3. Aceptar y cerrar navegador **antes de Start**. Volver: no debe haber Steps activados por Accept.
4. Ejecutar Start (con reintento idéntico) y observar qué UI/estado queda **después de Start**. Registrar assignmentId y si se crea/resuelve Initiative.
5. Iniciar Step 0 y contestar «no conozco el proceso», «no tengo datos», «no sé quién toma las decisiones»; comprobar que Copilot ofrece acciones posibles, no pregunta posicional ni convierte desconocimiento en propuesta.
6. Revisar Card viva: objetivos heredados vs suposiciones, fuentes, incertidumbres y resultado esperado; probar una respuesta irrelevante/sin sentido sin confirmación material.
7. Completar únicamente con evidencia suficiente; no forzar Step 1 si hay dependencias que obligan a aclaración/solicitud al Lead.

**Casos:** T04, T06–T08, T11, T17, T25. **Bloqueo grave:** Start sin salida entendible, salto automático de Step por presencia de texto, pérdida de mandato o duplicación de Initiative.

### Recorrido 3. Initiative Owner avanzado, con archivos al comenzar

1. Abrir assignment de **Initiative existente** con antecedentes verificables. Aceptar/Start con identidad preservada.
2. Antes de Step 0 o al entrar, intentar adjuntar PDF + Excel. Registrar botones reales, respuesta HTTP, propuesta de extracción, restricciones de upload y capacidad de revisar/corregir.
3. Corregir un hecho extraído; comprobar que no sustituye la fuente anterior y conserva estado provisional/confirmado.
4. Confirmar qué Step corresponde por evidencia heredada; no exigir rehacer entrevistas ni marcar trabajo importado como aprobado.
5. Probar resultados contradictorios entre 2 archivos, origen y justificación de cada Card.

**Casos:** T09, T12, T15, T23. **Bloqueo grave:** reseteo de Step, pérdida de historial, edición por viewer, documento interpretado como instrucción de IA.

### Recorrido 4. Initiative Owner independiente

1. Desde **Mis iniciativas**, crear iniciativa nueva sin Challenge corporativo.
2. Copilot ayuda a precisar propósito, alcance y condiciones sin exigir Portfolio Lead, empresa o KPI inventados.
3. Confirmar propuesta, comprobar que existe una única Initiative, con Step 0 accesible y Card heredando contexto correcto.

**Casos:** T10, T11, T13.

### Recorrido 5. Steps 0–4 y retorno de resultados

1. Step 1: entrar con hipótesis inicial e introducir evidencia que **refuta** la causa supuesta; comprobar que la lectura se reencuadra y Step 2 recibe el hallazgo correcto.
2. Step 2: usuario quiere leads reales, solo dispone de Figma: exigir distinción **interés/entendimiento proxy ≠ lead capturado**, explorar alternativa de menor costo y ruta de desbloqueo si faltan permisos.
3. Step 3: planear pruebas con persona/criterios relevantes; aportar resultado contrario, mixto e inconcluso; probar decisión de no iterar con justificación y sin aprobación automática.
4. Step 4: adjuntar deck PDF y comprobar contraste con outputs confirmados, costo/crédito, procedencia, limitaciones y fallo IA sin cobro. Generar Decision Package con inversión **real vs prevista**, KPI señal vs resultado y atribución.
5. Portfolio Lead recibe Decision Request, decide (continuar/pausar/cerrar etc. según autoridad), y observa cambio de coverage/alertas/historial. La recomendación del Copilot no puede aprobarse a sí misma.
6. Cambiar KPI del reto en medio de Step 2: verificar versionado, necesidad de review, preservación de evidencia e impacto sobre otras iniciativas.

**Casos:** T13–T22, T24. **Bloqueo grave:** el sistema presenta inferencia como dato corroborado, forzar éxito o iteración, inventar ROI o mutar decisiones sin permisos.

### Recorrido 6. Seguridad, recuperación y regresión

- Usuario externo → GET/POST PDF, evidence, Initiative, Decision Request y Front ajenos: 403/404 según política, sin filtrar metadatos.
- VIEWER lectura permitida y escritura denegada; EDITOR solo dentro de scope; Lead sin privilegios técnicos del owner si no corresponde.
- Invitation token expirado/revocado/otro correo: sin claim, Accept/Start no permitido.
- Doble clic e idempotency key repetida en Start/confirmaciones/guardado tras timeout.
- Simular IA 503/timeout y pérdida del response, verificar recuperación GET vs no reenvío de texto; comprobar payloads reales persistidos.

**Casos:** T07, T23–T25.

## C. Registro de resultados por caso (copiar 25 veces)

```yaml
test_id: T08
tested_at_utc: null
environment_url: null
deployment_sha:
  backend: null
  frontend: null
  ai_service: null
role: initiative_owner
dataset: Orion-sandbox
observed_navigation: null
entity_refs:
  assignment_id: null
  challenge_id: null
  initiative_id: null
  step: 0
request_ids: []
input_summary: null
expected: 'Start de challenge → formular iniciativa → confirmación → una sola Initiative → Step 0'
actual: null
result: NOT_RUN  # PASS | FAIL | BLOCKED | NOT_RUN
evidence_paths: []
source_provenance_verified: false
authority_guard_verified: false
notes: null
```

## D. Criterio mínimo de cierre

- Las **46 filas P0** de la matriz v0.2 deben tener fuente confirmada, resultado observable del caso relevante, `deployment_sha`, responsable de decisión y tratamiento acordado.
- Una prueba falla si el *comportamiento esencial* es incorrecto aunque el botón se pueda pulsar y no haya error de JS.
- No bloquear proyectos por preguntas accesorias si existe una acción reversible de bajo riesgo, pero no dispensar permisos/autoridad/evidencia material.
- Marcar `FAIL` solo tras reproducción real; marcar `BLOCKED` si falta sesión, fixture, bandera, red o servidor; no inventar `PASS`.
- Respetar `STARTERIA_AUTHORITY.md`: freezes son TO-BE candidatos, no autorización para alterar Core.

## E. Script de auditoría para ejecutar con Codex / asistente del checkout

> `AUDIT ONLY / READ ONLY` sobre `DarkCodePE/plataforma-starteria`. Identifica la rama, SHA y el SHA real desplegado; verifica autoridad vigente, cambios en `main` vs la matriz v0.2; ejecuta suites existentes con infraestructura de test y sin escribir a datos productivos. Reproduce T01–T25 **solo** en tenant de pruebas autorizado, siguiendo este runbook. Para cada caso agrega evidencia de captura y request/DB, resultado `PASS/FAIL/BLOCKED/NOT_RUN`, componente propietario y eventual discrepancia de autoridad. No modifiques código, migraciones, permisos, secrets ni contratos; no hagas commit ni PR. Devuelve: `RUNTIME_BASELINE.md`, `E2E_TEST_EXECUTION_REGISTER.md`, `GAP_MATRIX_RUNTIME_DELTA.md`, evidencias y lista de decisiones/ADR que requieren ratificación humana. No confundas ejecución CI con prueba de experiencia de usuario ni mockup con producto real.

## F. Lo necesario de la persona responsable

Acceso delegado a un navegador con sesión autenticada **en un tenant de pruebas** o ejecución autorizada mediante Codex en el checkout con entorno E2E. No hacen falta contraseñas en el chat. Si la red del asistente no accede al dominio productivo, ejecutar las pruebas en el entorno de despliegue o en el navegador del usuario.
