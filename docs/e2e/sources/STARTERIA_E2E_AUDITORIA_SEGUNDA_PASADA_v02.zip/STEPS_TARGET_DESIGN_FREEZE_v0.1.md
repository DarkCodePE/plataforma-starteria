# STARTERÍA — STEPS TARGET DESIGN FREEZE v0.1

**Fecha:** 2026-10-20  
**Estado de este documento:** **BASELINE DE DISEÑO CONGELADA PARA LA SIGUIENTE FASE**; pendiente de aprobación de integración en el repositorio y de reconciliación con las autoridades superiores.  
**Cobertura:** Initiative Owner; nuevas iniciativas desde un reto, iniciativas existentes/avanzadas e iniciativas independientes; Step 0–4.  
**No es:** una afirmación de implementación productiva, un ADR, una modificación automática del Core vigente ni una aprobación de las hipótesis UX.

## 0. Autoridad, fuentes y límites del freeze

Este freeze recoge **lo acordado como comportamiento objetivo** en el trabajo de Steps y conserva invariantes de los contratos de Startería. La autoridad vigente del repositorio identifica como Core factual `doc/CONTRATO_LOGICA_CORE_STARTERIA_MVP_v0.2_ES(1).md` (base fundacional revisada / por validar) y mantiene `docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md` v0.3 como **candidata no promovida**. Por tanto, las precisiones exclusivas de v0.3 deben pasar por reconciliación/ADR/re-test antes de emplearse para modificar el dominio.

Fuentes utilizadas:

1. `STARTERIA_AUTHORITY.md` del repositorio (`docs/STARTERIA_AUTHORITY.md` en GitHub).
2. `STARTERIA_CORE_LOGIC_CONTRACT.md` v0.3 candidata, §§3, 5, 12–21, 25–27; referencia de objetivo, no promoción automática.
3. `STEPS_NEW_CHAT_HANDOFF_v0.1.md`, especialmente §§2–14.
4. `STEPS_ADAPTIVE_MENTAL_MODEL_SOURCE.txt` y `Texto pegado.txt` (Modelo mental madre de Startería).
5. `STARTERIA_CRAZY8S_E2E_BASE_LOGIC_v0.1.md`, secciones de Initiative y retorno al Portfolio.
6. `STARTERIA_E2E_AUDIT_REPORT_v0.1.md` y `STARTERIA_TARGET_DECISION_REGISTER_v0.1.md` (evidencia y decisiones abiertas, no autoridad).
7. Test UX `Starteria_Steps_v06_QA_2_Perfiles.md`, evidencia del **mockup**; no prueba de producción.

**Límite jurídico/contractual del freeze:** se congela un **diseño de comportamiento**, sin declarar que el motor esté implementado, sin cambiar estados/relaciones canónicas y sin saltar checkpoints ni autoridad humana.

## 1. Tesis congelada

Startería Steps es un entorno adaptativo para **desarrollar iniciativas y convertir trabajo en evidencia y decisiones defendibles**, no un formulario por etapas. El usuario puede conversar, proporcionar documentos, realizar actividades, solicitar apoyo y revisar el resultado estructurado; el sistema conserva conocimiento con fuente, revisión y versión.

> **Copilot acompaña el trabajo; el workspace/card es el registro estructurado; la persona decide/valida cuando corresponde; el backend gobierna permisos, estados y transiciones.**

Ni una pregunta respondida ni una card con texto equivalen a un Step completado. Cada Step tiene una función permanente; las preguntas, métodos, intensidad y herramientas **no** son secuencias fijas.

## 2. Navegación mínima congelada del Initiative Owner

- Inicio principal: **Mis iniciativas**.
- Una misma pantalla contiene **asignaciones** (retos nuevos e iniciativas heredadas) y **mis iniciativas** (activas, pausadas o cerradas). No se exige menú separado de «Retos recibidos» para navegar entre ellas.
- CTA **Crear iniciativa** inicia exploración/estructuración por Copilot para una iniciativa propia.
- La recepción/aceptación de assignments precede a Start. La visualización de retos es contextual, no un dashboard de Portfolio Lead.
- El ejecutor no administra frentes estratégicos, coberturas ni cartera. Puede consultar el mandato y pedir aclaraciones/apoyo.
- Dentro de la iniciativa: encabezado persistente con propósito/mandato y navegación visible Step 0–4; conversación principal + **Card viva** del resultado esperado del Step, evidencias/archivos, apoyos/actividad e historial accesibles bajo demanda.
- En proyectos corporativos, las variaciones del mandato requieren revisión por la autoridad competente; el Initiative Owner no reescribe unilateralmente el objetivo del reto.

## 3. Entradas que deben converger al mismo sistema de Steps

| Entrada | Qué ya existe | Qué hace la experiencia antes de Step 0–4 | Regla |
|---|---|---|---|
| **A. Assigned Challenge (reto nuevo)** | Challenge y HandoffAssignment; no se presume Initiative. | Invitación → aceptar → overview → Start → Copilot ayuda a formular una iniciativa candidata; revisión del mandato → persona confirma creación → Step 0 para delimitar el trabajo inicial. | Accept no crea ni activa Initiative. |
| **B. Assigned Initiative (avanzada)** | Challenge + Initiative preexistente + evidencias/decisiones/historia. | Invitación → aceptar → overview → Start → brief narrativo de continuidad: qué se buscó, qué se hizo, qué se aprendió, qué falta y qué se espera ahora → revisión de completitud/evidencia y continuidad al Step legítimo. | No duplicar Initiative, no inventar porcentaje, no aprobar Steps retroactivamente. |
| **C. Iniciativa independiente** | Intención o idea del usuario, quizá fuentes previas; sin reto corporativo. | Crear iniciativa → Copilot ayuda a explorar y ordenar → usuario revisa lo entendido → confirma iniciativa → Step 0. | No exigir StrategicFront/Challenge ni autoridad corporativa inexistente. |

Los tres flujos comparten funciones Step 0–4 pero no comparten forzosamente el mismo contexto, pregunta inicial ni ruta de actividades.

## 4. Motor mental madre, transversal y no visible como wizard

**ORIENTAR → ENTENDER → ENFOCAR → ACTUAR → OBSERVAR → INTERPRETAR → ADAPTAR**.

En cada nuevo input (texto, archivo, corrección, resultado, decisión o solicitud), el motor objetivo:

1. Lee contexto, mandato/snapshot, Step activo, cards anteriores, fuentes, restricciones y autoridad.
2. Interpreta la **función semántica** de la entrada: dato, observación, supuesto, propuesta, incertidumbre, contradicción, bloqueo, evidencia o petición.
3. Distingue declaraciones de hechos observados, sugerencias de IA, material sin verificar y lo expresamente desconocido.
4. Reevalúa qué decisión o incertidumbre importa **ahora** para la función del Step.
5. Evalúa evidencia, riesgo/coste del error, reversibilidad, velocidad de feedback, capacidad y dependencias.
6. Selecciona **una siguiente intervención útil**: `ASK`, `ANALYZE_EXISTING`, `PREPARE_METHOD`, `EXECUTE_ACTIVITY`, `CREATE_ARTIFACT`, `REQUEST_SUPPORT`, `REVIEW_CHANGE`, `REASSESS`, `READY_FOR_CHECKPOINT`, `PAUSE_OR_CLOSE_RECOMMENDATION` (nombres conceptuales; no enums productivos).
7. Actualiza una propuesta de delta para la Card viva, **nunca una escritura canónica silenciosa**. Backend valida y aplica cambios conforme a las reglas de estado.
8. Tras nueva evidencia o acción, repite el ciclo. La *Stop Thinking Rule* detiene preguntas si no cambiarán la siguiente decisión y es más útil actuar.

### 4.1 Reglas críticas

- **No preguntar para llenar campos.** Preguntar solo si reduce una ambigüedad material.
- **No forzar hipótesis prematuras.** Una persona puede llegar sin saber nada o sin solución.
- **Reencuadrar ante evidencia contraria.** Una idea de IA puede terminar en un problema de coordinación, sin penalizar al usuario.
- **Unblock before degrade.** Si falta acceso/know-how/autoridad, ofrecer desbloqueo primero; explicar las limitaciones de un proxy.
- **No equivalencia falsa:** mockup/entrevista/landing no demuestra automáticamente impacto operacional o leads reales.
- **No input garbage → fact.** Texto irrelevante/insuficiente no se promociona como objetivo, hallazgo o evidencia.
- **No completar por porcentaje:** seguimiento de condiciones de suficiencia y estado de la evidencia.
- **No confundir un fallo de hipótesis con un fallo metodológico.** Refutación defendible es aprendizaje válido.

## 5. UX transversal congelada: conversación + Card viva + herramientas contextuales

**Shell estable:**

```text
Encabezado: objetivo / mandato / Step activo / estado
Stepper: Step 0 | 1 | 2 | 3 | 4
-----------------------------------------------------
IZQUIERDA: Conversación con Copilot  | DERECHA: Card viva
- leer, preguntar, orientar         | - resultado esperado del Step
- elegir siguiente movimiento       | - qué ya está sustentado
- generar actividad cuando aporte  | - qué permanece abierto
- recibir texto/fuente/archivo      | - propuesta de síntesis/resultado
- permitir pedir ayuda              | - procedencia y revisión
-----------------------------------------------------
Bajo demanda: actividad guiada, guía, upload, análisis, cambios, solicitudes
Checkpoint: revisar resultado, criterios de suficiencia, confirmaciones y gaps
```

La Card no es un almacén de cualquier respuesta. Sus bloques son **tipados por Step y por campo**, con evidencia, origen y estado de revisión. El Copilot puede sugerir cambios pero el usuario debe poder ver/corregir las interpretaciones materiales. Deben preservarse las versiones reemplazadas.

### 5.1 Comportamiento del Copilot ante distintos perfiles

- Usuario sin contexto: empieza explicando el mandato y determina dónde obtener contexto; ayuda a identificar personas, procesos o documentos; **no** rellena hipótesis ficticias.
- Usuario con información: ofrece subir/pastear datos **desde el inicio**, clasifica las fuentes, sintetiza, marca lo conocido y evita repetir preguntas.
- Usuario con solución preconcebida: preserva la propuesta, realiza reverse alignment con valor esperado y busca otras explicaciones/contraste, sin invalidarla ni confirmarla por defecto.
- Usuario con iniciativa heredada: reconstruye qué pasó, qué está documentado y qué fue verificado; **no** obliga a rehacer trabajo válido ni da por aprobada evidencia histórica.
- Usuario bloqueado: propone solicitud contextual al Portfolio Lead/actor adecuado, conserva contexto, permite trabajo paralelo cuando sea seguro.

### 5.2 Adjuntos

Debe poderse aportar documento, texto estructurado o resumen de LLM de confianza en el momento que sea útil, incluso en preparación de Step 0. Diferenciar: archivo almacenado, archivo procesado, contenido extraído, hallazgo sugerido y evidencia/claim revisado. Subir un archivo no debe sobrescribir información anterior ni aprobar su contenido. **El soporte de formatos, límites de seguridad y permisos queda para Tech Spec.**

## 6. Función / salida / checkpoint de Step 0–4

| Step | Trabajo de Copilot (adaptativo) | Card de salida del Step | Comprobación de suficiencia |
|---|---|---|---|
| **0 · Enmarcar** | Comprender mandato/idea, situación, alcance, propósito, restricciones, recursos, actores, supuestos y qué trabajo o incertidumbre abordar primero. Para reto corporativo revisar conexión propuesta→mandato sin reescribir el objetivo de Portfolio. | `Step0ContextAndIntentCard`: objetivo específico, contexto, alcance, supuesto(s) no probado(s), restricciones, valor esperado, primera decisión/aprendizaje/acción. | ¿Se comprende qué intenta lograr esta iniciativa **ahora**, para quién, dentro de qué marco y qué habrá que aprender o hacer a continuación? No exige hipótesis causal si no existe. |
| **1 · Establecer verdad/foco** | Partir del output Step 0, revisar fuentes existentes, decidir qué investigar y por qué, preparar entrevistas/datos/observación, solicitar accesos, capturar y **contrastar** evidencia con supuestos; permitir reencuadre. | `Step1EvidenceAndFocusCard`: fuentes, investigación realizada, resultados, contradicciones, hallazgos, supuestos apoyados/refutados, nuevo foco y gaps. | ¿Existe evidencia proporcional al riesgo que sostenga un foco útil para diseñar/preparar la siguiente acción? |
| **2 · Diseñar/preparar** | Explorar alternativas (HMW, Crazy 8s u otros métodos **solo si sirven**), evaluar impacto propuesto, relación con KPI/señal, nivel de fidelidad, tiempo, know-how, recursos, dependencias, construir/preparar demo/solución y plan de prueba. | `Step2SolutionAndTestReadinessCard`: alternativas, apuesta elegida, hipótesis de impacto, contribución propuesta, artefacto ejecutable, apoyo necesario, método/métrica/umbral cuando corresponda y límites de validación. | ¿Tenemos algo suficiente, viable y medible para confrontar con la realidad? ¿Qué demuestra el artefacto y qué **no** demuestra? |
| **3 · Ejecutar/observar** | Preparar participantes/entorno cuando corresponda, ejecutar prueba o acción, capturar feedback y medidas, comparar esperado/observado, interpretar resultados y determinar si falta iteración o basta para decidir. | `Step3ExperimentResultCard`: prueba realizada, hipótesis, evidencia, resultados observados, diferencias, aprendizajes, impacto observado/provisional, recomendación. | ¿Queda claro qué ocurrió y qué podemos sostener? Soporta apoyada/refutada/mixta/inconclusa. |
| **4 · Cerrar/preparar decisión** | Consolidar historia, evidencia, restricciones, recursos, resultados vs esperado, fortalezas/limitaciones y opciones; generar paquete para autoridad de decisión, no convertir en pitch como único objetivo. | `Step4DecisionPackageCard`: `InitiativeBrief` + `DecisionPackage` con decisión solicitada, razón, evidencia/claims, coste-tiempo-capacidad, riesgos, alternativas, siguiente actor/acción. | ¿Existe paquete suficientemente trazable para decisión humana y continuidad/handoff si corresponde? |

**Step 2:** un mockup Figma puede sustentar usabilidad o interés percibido, pero **no** constituye por sí mismo leads generados, conversión comercial ni impacto operativo; se debe explicitar la brecha con la meta del reto. Si falta desarrollo/IT, se solicita apoyo antes de degradar el resultado esperado.

**Step 3 sin iteración:** el usuario puede recomendar pausar, cerrar o llevar los resultados disponibles a decisión; no obliga a repetir prueba pero tampoco convierte la evidencia insuficiente en validada. Si hay hard gate irresuelto, no se autoriza promoción indebida.

## 7. Contrato mental de paso entre Steps

```text
Step N card confirmada con evidencia + gaps conservados
                 ↓
      checkpoint (suficiencia, gates, autoridad)
                 ↓
      salida estructurada y versionada
                 ↓
Step N+1 recibe: propósito, síntesis, evidencia, supuestos, límites,
                 siguiente incertidumbre, restricciones, dependencias
```

Si falta una condición material, el sistema puede: profundizar, solicitar apoyo, preparar acción o registrar propuesta de pausa/cierre. La confirmación no se deriva de texto suficiente en apariencia.

## 8. Provenance y calidad de evidencia

Cada claim material de una Card incluye conceptualmente:

```text
claim_id, statement, step_id, field_path, source_refs[], origin,
review_disposition, evidence_level, status, version, observed_at/created_at
```

Las etiquetas `USER_DECLARED`, `EXTRACTED`, `AI_INFERRED`, `AI_SUGGESTED` y los estados de revisión no se mezclan. Las métricas conservan unidades, rangos, baseline, horizonte y limitaciones. Una revisión aprobada no borra la anterior; un cambio material produce nueva versión e invalida dependencias cuando corresponda.

La escala L0–L6 está detallada en el Core v0.3 **candidato**; su utilización normativa exacta requiere reconciliación con el Core factual vigente.

## 9. Cambios del reto, ruta de desarrollo y continuidad

- Un cambio material del reto produce evento/versionado; la iniciativa conserva snapshot original; Startería propone revisión de alineamiento sin reescribir su Card ni su ciclo silenciosamente.
- **Ruta de desarrollo** responde cómo producir evidencia dentro del Step activo; **ruta de continuidad** responde qué hacer tras la decisión. Son conceptos distintos.
- Un mismo Step puede usar actividades/profundidades muy distintas según corrección, crecimiento o exploración, contexto y madurez.
- Las iniciativas independientes comparten Steps, con opciones de continuidad propias; no se insertan ficticiamente en un reto de empresa.
- Un ciclo de trabajo adicional requiere una decisión material, no se crea porque el usuario completó un formulario.

## 10. Congelado vs deliberadamente abierto

**Congelado como target UX/lógica:** funciones Step 0–4; Copilot conversacional; Card viva por Step; inputs desde cualquier momento permitido; reuso de evidencia; ruta adaptativa; salida versionada; checkpoints por suficiencia; solicitudes de apoyo; Step 4→paquete de decisión; diferenciación entre ejecutivo/decisor; no porcentajes inventados.

**No congelado:** prompts exactos, cantidad de preguntas, métodos específicos, plantillas de artefactos, nombres visibles definitivos, tipo/modelo LLM, layout/posición responsive, categorías técnicas de eventos/enums, thresholds generales, políticas de confidencialidad por formato, diseño de routing entre agentes, tiempo del Step, número de actividades.

## 11. Pruebas mínimas para pasar de target a implementación

| ID | Caso | Resultado obligatorio |
|---|---|---|
| ST-01 | Usuario no sabe nada del proceso | Copilot identifica fuentes/actores, no inventa solución ni fuerza hipótesis. |
| ST-02 | Usuario pega resumen con entrevistas, cifras, fechas y fuentes en Step 0 | Se interpreta por semántica, no por turno; conservación de números/refs; Card correcta. |
| ST-03 | Usuario añade un archivo y después otro | Se preservan ambos; no se sobrescriben hallazgos previos ni se dice que adjuntar equivale a validar. |
| ST-04 | Texto irrelevante `asdasdasd` | No se rellena Card como resultado ni se habilita checkpoint material. |
| ST-05 | Hipótesis IA contradicha por datos Step 1 | Se registra contraste/refutación, nueva explicación candidata y cambio de foco. |
| ST-06 | Step 2 propone Figma pero reto busca leads | Se explica brecha de impacto; ofrece prueba/proxy o apoyo que conecte a evidencia comercial. |
| ST-07 | Faltan datos/permiso/dev | Solicitud a Portfolio con referencia, motivo, impacto y estado; alternativa solo con limitaciones. |
| ST-08 | Iniciativa avanzada llega con contenido tipo Step 3 y lagunas Step 1 | Ingesta retroactiva, marcas de revisión, no reescribe historia ni aprueba sin fuente. |
| ST-09 | Resultado Step 3 contradice hipótesis | Checkpoint distingue aprendizaje suficiente de hipótesis validada. |
| ST-10 | Usuario elige no iterar | Se puede proponer paquete de decisión con límites; no forzar aprobación de hipótesis. |
| ST-11 | Cambio de reto mientras Step 2 activo | Versiona, marca dependencias a revisar, no cambia scope silenciosamente. |
| ST-12 | Step 4 emite paquete | Portfolio recibe evidencia, límites y recomendación; ningún `decision approved` automático. |
| ST-13 | Dos recorridos distintos del mismo Step | El motor difiere preguntas/actividades por contexto pero persiste mismo tipo de Card/suficiencia. |
| ST-14 | Respuesta útil ya incluida en fuente previa | Evita preguntar otra vez; propone siguiente acción de valor. |

## 12. Brechas/condiciones de promoción

Este documento **no** declara operativo el motor mental completo. Existen Adaptive Core, checkpoint planner y agentes especializados en la rama revisada de GitHub; **no se ha certificado** una integración E2E con interpretación semántica continua, router de siguiente acción, Card viva confiable, ingestión general de archivos ni reglas de suficiencia probadas con LLM real. La v0.6 era mockup con fallos de asignación semántica y ausencia de carga temprana. Estas diferencias deberán entrar en Current→Target Gap Matrix y tests antes de modificación del repositorio.

**Criterio de freeze:** una modificación funcional que altere la función de un Step, cambie autoridad o suavice gates debe tratarse como cambio contractual / ADR cuando aplique. Las variantes de copy, método, diseño o actividad son iteración ordinaria si cumplen invariantes y tests.
