# STARTERÍA — Diagnóstico integral AS-IS → TO-BE y matriz de brechas E2E

**Documento:** `STARTERIA_E2E_ASIS_TOBE_GAP_MATRIX_v0.1.md`  
**Versión:** 0.2 — **auditoría estática + evidencia GitHub CI/CD complementaria; journey autenticado pendiente**  
**Fecha de corte:** 20 de octubre de 2026  
**Producto:** Startería Platform — Portfolio Lead, Handoff, Initiative Owner, Steps 0–4, evidencia y decisiones  
**Repositorio inspeccionado:** [`DarkCodePE/plataforma-starteria`](https://github.com/DarkCodePE/plataforma-starteria)  
**Rama observada:** `main` · **commit:** [`75fc358838c34174da858937f4b47b92b8fbf074`](https://github.com/DarkCodePE/plataforma-starteria/commit/75fc358838c34174da858937f4b47b92b8fbf074), fechado 17/10/2026 23:53 UTC  
**Modo:** `AUDIT ONLY` — no se modificó código, esquema, contratos, datos ni repositorio.  
**Decisión de producto:** la experiencia objetivo está expresada en los freezes de diseño de Steps y de integración E2E del 20/10/2026; **no** se presume que esos freezes estén promovidos a autoridad del repositorio.

> **Alcance y honestidad de la evidencia.** Este documento **sí contiene un contraste inicial completo del journey E2E y una matriz de brechas accionable**. La columna AS-IS procede de inspección estática de rutas/servicios/componentes del `main` indicado, del `CURRENT_STATE.md`, del `STARTERIA_V2_MANIFEST.md` y de auditorías ya disponibles. **No** se ejecutaron directamente la aplicación, bases de datos, proveedores LLM, suites locales ni pruebas del despliegue mediante este entorno. La segunda pasada verificó la ejecución histórica de CI/CD y su alcance, pero no ejecutó un journey autenticado propio. Por tanto, `EXISTE_EN_CÓDIGO` o `IMPLEMENTED_VERIFIED_LOCAL` **no significan** `PRODUCCIÓN_VERIFICADA`. Los renglones marcados **NV** siguen pendientes de prueba funcional y no deben usarse como diagnóstico certificado de producción.

---

## 1. Resumen ejecutivo

### 1.1 Qué buscamos evaluar

Verificar si Startería puede ofrecer **una experiencia integrada y gobernada** que permita:

```text
Entrada / primera claridad de negocio
        ↓
Portfolio Lead: objetivo y señal → frente → reto → cobertura y decisiones
        ↓
Asignación → invitación → aceptación/rechazo → overview → Start
        ↓
A: formular iniciativa para reto | B: continuar iniciativa avanzada
        └────────────────────────────────────────────┐
C: crear iniciativa independiente ──────────────────┤
                                                     ↓
                        Initiative Owner: Step 0 → Step 1 → Step 2 → Step 3 → Step 4
                        Copilot contextual + actividades + evidencia + Card viva
                                                     ↓
                          Decision Package / solicitud de decisión
                                                     ↓
                Portfolio Lead / autoridad: decisión, cobertura, seguimiento, aprendizaje
```

### 1.2 Dictamen preliminar

**La base técnica es reutilizable, pero el E2E objetivo todavía no está acreditado como un recorrido integrado de extremo a extremo.** Hay rutas, servicios y contratos sólidos en algunas fronteras (Portfolio Entry, Handoff, Adaptive Core, evidencia, decisión); persisten diferencias entre comportamiento legacy, V2 por slices, candidatos de producto y el nuevo TO-BE. La mayor intervención prevista es **integrar y adaptar** —no reconstruir toda la plataforma—, especialmente **post-Start, Copilot para Steps, Cards vivas, evidencia y retroalimentación hacia Portfolio**.

**Hallazgos decisivos:**

1. **Autoridad de producto no reconciliada:** `docs/STARTERIA_AUTHORITY.md` identifica el Core factual **v0.2 / por validar**; `docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md` v0.3 es **candidata**, no promovida. El TO-BE congelado no sustituye esa jerarquía [E01, E02].
2. **Migración visual incompleta:** `CURRENT_STATE.md` y el Manifest ubican Initiative Overview y Steps 0–4 fuera de la frontera V2 visual migrada; requieren análisis de consumidores legacy antes de intervenir [E02, E03].
3. **Handoff implementa transiciones reales:** hay endpoints diferenciados `accept`, `reject` y `start`, con idempotencia, versión e identidad; sin embargo **Start no define por sí mismo qué Initiative se crea o reanuda** [E09–E11].
4. **Portfolio tiene dominio y read models:** hay CRUD de frentes/retos, iniciativas por reto, solapamientos, cobertura, estado derivado y Home read-only; no está acreditada la lectura integral de impacto/contribución y decisión a través del nuevo E2E [E06–E08].
5. **Adaptive Core existe:** configura checkpoints, outputs, suficiencia, versiones, transiciones y decisión; el **Checkpoint Planner es predominantemente determinista**, no el motor crítico/analítico/sistémico conversacional propuesto [E15–E17].
6. **IA especializada existe:** Research Assistant, Solution Design, Experiment Coach y Narrative Builder; el orquestador actual enruta por Step/acción, pero no constituye aún un coordinador único que interprete **cada** input y decida la próxima intervención útil [E18].
7. **El Copilot transversal está acotado:** existe persistencia de conversaciones/planes, pero el capability registry inspeccionado contempla `CreateStrategicFront`, usa assessment determinista y no habilita por sí mismo el Copilot de Steps [E19].
8. **Evidencia parcial y heterogénea:** hay Evidence Service, extracción PDF y estructuras de verdad/checkpoints, pero falta confirmar ingesta desde cualquier Step, síntesis semanticamente correcta hacia Card, procedencia exhaustiva y no reemplazo de contenido [E20–E22].
9. **Existe camino para decisiones y retorno:** `DecisionReadinessResolver` y `decision-portfolio-return.ts` son reutilizables; requieren prueba E2E contra el contenido real del Decision Package y la autoridad correspondiente [E23].
10. **El HTML v0.6 demuestra UX, no IA real:** su QA reprodujo asignación posicional de respuestas, falta de carga temprana y checkpoints falsamente superables. No debe usarse como prueba productiva ni como especificación técnica de semántica [E27].

### 1.3 Lectura por bloque

| Bloque de producto | Estado AS-IS del checkout auditado | Brecha principal al TO-BE | Prioridad |
|---|---|---|---|
| Landing / Portfolio Entry | Runtime por slices, con evidencia local y compatibilidad legacy | Continuidad inequívoca y sin canonización prematura | P1 |
| Interpretación / contexto Portfolio | Contexto provisional, bootstrap, first value y framing con madurez desigual | Coherencia a través de todas las entradas (pública, directa, portafolio existente) | P1 |
| Portfolio Lead | Servicios CRUD, Home, cobertura, iniciativas y alertas presentes | Anclar lectura ejecutiva en contribución y decisiones con evidencias; consolidar UX | P1 |
| Importación / iniciativas existentes | Bootstrap import/work items y propuestas; ruta de iniciativas legacy | Distinguir work item de Initiative, confirmar alineamiento, reconstruir sin autorizar pasos | P0 |
| Assignment / Handoff | Servicios/versiones y `accept/reject/start` presentes | Unión gobernada después de Start; bandeja de Mis iniciativas; claridad de contexto | **P0** |
| Creation / advanced / independent | Rutas existentes separadas; candidato post-Start | Convergencia de los 3 journeys sin duplicar entidades ni forzar empresa | **P0** |
| Steps 0–4 | Adaptive Core + páginas extensas con módulos/checkpoints | Copilot conversacional, Card viva y métodos adaptativos sin romper gates | **P0** |
| IA cognitiva transversal | Agentes por tarea + copilot de portfolio determinista + harness experimental | Interpretación por input, criticidad sistémica, router de siguiente movimiento | **P0** |
| Evidencia / procedencia | Servicios y modelos de extracción/verdad | Entrada en cualquier punto, trazabilidad por claim y card, review/corrección | **P0** |
| Checkpoints | Estados y evaluaciones estructurales | Suficiencia semántica comprobable, no completar por presencia de texto | **P0** |
| Portfolio ↔ decisiones | Decision Readiness, authority y retorno en servicios | E2E con recursos, resultados e impacto esperado/observado separados | **P0** |
| Seguridad / pruebas / observabilidad | Pruebas y guardas por slices | Suite E2E integrada y evidencia de despliegue, permisos y fallos | **P0** |

**Leyenda de prioridad:** `P0` habilita valor, integridad o autoridad E2E y bloquea promoción; `P1` afecta experiencia/decisión relevante; `P2` mejora o escala sin bloquear primer piloto.

---

## 2. Criterios de autoridad y fuentes TO-BE

### 2.1 Autoridad (no confundir con fecha de archivo)

1. `docs/STARTERIA_AUTHORITY.md` y el Core factual `doc/CONTRATO_LOGICA_CORE_STARTERIA_MVP_v0.2_ES(1).md` (**base revisada / por validar**).
2. ADRs de producto aceptados en `doc/product-adr/`.
3. Contratos Experience aprobados por bounded context; entre ellos `STRATEGIC_FRAMING_EXPERIENCE_CONTRACT_v0.1.md` y `PORTFOLIO_TO_INITIATIVE_ACTIVATION_EXPERIENCE_CONTRACT_v0.2.md` (**termina en Start**).
4. Contratos de agente, skill y specs cuando correspondan, según autoridad.
5. **Referencia TO-BE candidata, no autoridad automáticamente promovida:**
   - `STEPS_TARGET_DESIGN_FREEZE_v0.1.md` (20/10/2026);
   - `STARTERIA_PORTFOLIO_STEPS_E2E_INTEGRATION_v0.1.md` (20/10/2026).
6. Artefactos de UX y evidencia (no normativos): `Starteria_Steps_Conversacion_Card_Viva_v06.html` y `Starteria_Steps_v06_QA_2_Perfiles.md`.

**Regla de conflicto:** Core/ADR prevalecen. Si se propone cambiar una cardinalidad, autoridad de decisión, lifecycle canónico, función de Step o gating, registrar ADR/decision y **detener únicamente la parte afectada**. No usar el mockup para cambiar el dominio.

### 2.2 Definición operativa de estados de esta auditoría

- `EC` — **Existe en código:** componente o endpoint localizado; comportamiento no ejecutado aquí.
- `PV` — **Parcial / mixto:** piezas implementadas, pero integración o semántica incompleta.
- `EL` — **Evidencia local histórica:** tests/QA reportados por slices; no son prueba del runtime actual.
- `NV` — **No verificado:** requiere ejecución, acceso a despliegue o inspección adicional.
- `BR` — **Brecha documentada:** un contrato/manifest/QA declara el alcance pendiente.
- `CONFLICTO` — Contrato actual, candidato o implementación contienen reglas no reconciliadas.

**Tratamiento único por fila:** `KEEP` conservar como está (sujeto a regresión), `ADAPT` adecuar un elemento existente, `REMOVE` retirar comportamiento legacy **después** de comprobar consumidores, `NEW` crear una capacidad nueva tras inventario. `ADAPT` incluye reparación y conexión de componentes; no ordena reescribirlos.

### 2.3 Nivel de verificación

- **Acreditado en esta entrega:** lectura de código/docs del commit de referencia; inventario de módulos, rutas, métodos, guards y componentes citados; contraste estático con los freezes; utilización del QA v0.6 como evidencia del prototipo.
- **No ejecutado:** pruebas unit/integration/E2E del checkout local; DB/Postgres; navegador sobre la app del repo; proveedor IA real; red de producción; cross-org/roles en runtime; comparación con ramas WIP no fusionadas; cobertura completa de dependencias.
- **No inferir:** «no encontré ruta exacta» ≠ «esa feature no existe en ninguna rama»; «test presente» ≠ «PASS hoy»; «evidencia histórica PASS» ≠ «funcionalidad desplegada».

---

## 3. AS-IS: mapa de recorridos y fronteras actuales

### 3.1 Entrada / Portfolio (lectura estática)

```text
Landing / Portfolio Entry (/public/start)
  → Portfolio Entry runtime/session, análisis/handoff provisional
  → confirmación / Portfolio Setup Continuity cuando aplica
  → Portfolio Setup / Bootstrap, Anchor y first value
  → vistas de Portfolio Lead: Home / Strategic Fronts / Challenges / Initiatives
```

Hay rutas legacy hacia creación de Project desde draft/piloto, coexistiendo con la ruta Portfolio-first; `CURRENT_STATE.md` marca una de esas conversiones como deuda de retirada, no como autoridad para la experiencia objetivo [E02, E03, E04]. El Bootstrap permite importar *work items* e identificar conexiones provisionales [E05]. Esas unidades no deben confundirse automáticamente con Initiatives corporativas confirmadas.

### 3.2 Handoff (lectura de rutas reales)

```text
Portfolio: crear/seleccionar Challenge o Existing Initiative
  → HandoffAssignment + invitación/token
  → /handoff/invitation/:token
  → autenticación / claim de identidad
  → Accept | Reject
  → Activation Overview
  → Start (evento/estado)
  → [FRONTERA DEL CONTRATO DE HANDOFF]
```

El servicio comprueba identidad, owner, versión e idempotencia para Start. La página `HandoffInvitationPage.tsx` actualiza estado y renderiza `HandoffShell`; **no observé en ese handler un comando post-Start que cree/resuelva la iniciativa ni navegación directa al Copilot de formulación** [E09–E11]. Esto necesita un contrato nuevo, no un efecto secundario oculto de `start`.

### 3.3 Initiative Owner / Steps

```text
Project / Initiative Overview
  → Step 0 (formulario legacy + checkpoints Adaptive Core)
  → Step 1 (módulos de problema/investigación/captura + checkpoints)
  → Step 2 (ideación, elección, propuesta/experimento + checkpoints)
  → Step 3 (ejecución/registro/experimentos + checkpoints)
  → Step 4 (narrativa/cierre/decisión + checkpoints)
```

Las páginas `Step0Page` y `Step1Page` son extensas y mezclan módulos históricos con Adaptive Core. `AdaptiveCheckpointWorkspace` muestra preguntas mínimas en `textarea`, respuestas y confirmaciones. El planificador consulta contexto y valores conocidos, **pero sus variables provienen de catálogo**. Ninguna de estas piezas, aisladamente, acredita el Copilot conversacional que propone/ejecuta actividades y modifica una Card por significado en cada entrada [E15–E17].

### 3.4 Retorno a Portfolio

Existen `DecisionReadinessResolver`, `decision-portfolio-return.ts`, estados derivados de Step (`initiative-progress.ts`) y un `PortfolioHomeReadService` de solo lectura. También existe lectura de cobertura de un reto. **Debe probarse** que Step 4 genera la solicitud y que la autoridad toma una decisión con información, recursos y evidencia actuales, que después modifica la lectura del reto/Portfolio de forma idempotente y trazable [E07, E08, E23].

---

## 4. TO-BE común: una experiencia, tres maneras de empezar

**A — Reto asignado sin iniciativa:** asignación → aceptar → brief legible/solicitud de aclaración → Start → **Copilot ayuda a formular propuesta** conectada con el reto → usuario confirma creación (según autoridad) → Overview → Step 0.

**B — Reto + iniciativa existente:** asignación de Initiative → aceptar → brief narrativo de continuidad («qué se buscó, hizo, comprobó, aprendió, falta») → Start → **reconstrucción y revisión de evidencia/gating retroactivo** → Step apropiado, sin duplicar la Initiative ni inventar porcentajes.

**C — Iniciativa independiente:** `Mis iniciativas` → `Crear iniciativa` → conversación para delimitar idea/oportunidad, revisión del encuadre → confirmación de Initiative independiente → Overview → Step 0; sin forzar StrategicFront/Challenge ni permisos de Portfolio Lead.

**Steps compartidos:** una navegación Step 0–4, interacción principal **Copilot + Card viva del Step + herramientas contextuales**, subida de contexto desde cualquier momento permitido, checkpoint por suficiencia, provenance/versionado y resultado hacia el siguiente Step. Un resultado negativo/refutación es aprendizaje válido. Step 4 prepara `Decision Package`; el decisor conserva la autoridad de inversión/implementación/cierre.

**Funciones (no formularios):**

| Step | Propósito estable | Card / salida exigida conceptualmente | No equivale a |
|---|---|---|---|
| 0 | Comprender mandato/situación, delimitar trabajo e incertidumbre | propósito, contexto, alcance, supuestos, criterio de decisión, qué debe abordarse/contrastar primero | «tener una solución IA» o llenar N campos |
| 1 | Investigar/contrastar, descubrir evidencia y enfocar | fuentes, observado vs supuesto, hallazgos, contradicciones, foco sustentado y límites | contar entrevistas o validar la hipótesis por defecto |
| 2 | Idear, seleccionar, preparar/construir lo ejecutable | alternativas, hipótesis de impacto, valor y limitaciones del artefacto, recursos, solución preparada y plan de medición | mockup = impacto/ventas/leads reales |
| 3 | Ejecutar/pruebas, observar e interpretar | test y su evidencia, esperado vs observado, aprendizajes, hipótesis respaldada/refutada/inconclusa y opciones | marcar «éxito» por completar la prueba |
| 4 | Sustentar recomendación/solicitar decisión | resultados, fuerza de evidencia, inversión/capacidad, riesgo, opciones y Decision Package trazable | IA decide inversión o cierre |

**Modelo mental madre de orientación**, aplicado transversalmente y no como siete pasos visibles: `ORIENTAR → ENTENDER → ENFOCAR → ACTUAR → OBSERVAR → INTERPRETAR → ADAPTAR`.

---

## 5. Matriz integral AS-IS → TO-BE

> **Cómo leerla.** `Estado` describe este checkout (no despliegue). `Tratamiento` es la **hipótesis de intervención** sujeta a revisión técnica; no orden de cambio. `AC` indica el criterio mínimo observable que convertiría el gap en verificado. Las referencias `[E##]` aparecen desarrolladas en §10.

### A. Entrada / Portfolio Entry / continuidad (PE)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | Criterio de aceptación (AC) |
|---|---|---|---|---|---|---|---|
| PE-01 | Landing y entrada natural | `LandingPage`, Portfolio Entry y `/public/start`; slices V2 con QA local [E02–E04] | EC/EL | Entrada comprensible, sin forzar registro ni taxonomía y derivación correcta | KEEP | P1 | Los casos público/empresa llegan a la experiencia adecuada sin crear objetos no autorizados. |
| PE-02 | Interpretación provisional de necesidad | Runtime de Portfolio Entry, análisis y sesión con budget, gaps y procedencia [E04] | EC/EL | Mantener interpretación separada de verdad corporativa, sin loop de preguntas | ADAPT | P1 | Consulta multivuelta no crea Front/Challenge/Initiative y conserva correcciones. |
| PE-03 | Doble ruta legacy de conversión | `CURRENT_STATE` registra conversiones piloto/PublicDraft → Project/Step 0 [E02, E04] | BR/PV | Portfolio-first no desemboca por accidente en iniciativa independiente | REMOVE | P0 | Retirada por consumidores identificados, compatibilidad explícita y pruebas antiguas/new; nunca eliminar sin plan de migración. |
| PE-04 | Confirmación/continuidad post Entry | Portfolio continuation y ruta 114F acotada, verificación local [E02, E03] | EC/EL | Restaurar contexto y autoridad scoped sin duplicar sesiones o canonizar inferencias | KEEP | P1 | Reanudación y reload conservan snapshot, identidad, confirmación y destino. |
| PE-05 | Ingreso directo de empresa/portafolio existente | `Strategic Framing SF-1` identificó deuda para entradas no públicas; existen slices SF posteriores [E12] | PV/NV | Todos los puntos de entrada comparten referencia estratégica gobernada | ADAPT | P1 | Un líder autenticado con cartera no rehace un Entry público para encuadrar su situación. |
| PE-06 | Referencias de diseño/QA | HTML v0.6 y QA muestran defectos de Card/gates [E27] | BR | Usar solo como UX, no motor productivo | KEEP | P2 | Tests semánticos corrigen cada finding antes de adoptar UX a producción. |

### B. Portfolio Lead: objetivo, estrategia, retos, iniciativas (PL)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| PL-01 | Inicio ejecutivo | `GET /portfolio/home`, `PortfolioHomeReadService`, `PortfolioLeadHomePage` y composiciones/flags [E06, E08] | EC/EL | Centro de atención por contexto, acciones y decisiones; no datos estáticos huérfanos | ADAPT | P1 | Home muestra atención y justificación desde fuentes reales, sin contar assignments como iniciativas. |
| PL-02 | Objetivo estratégico, KPI y horizonte | CRUD `StrategicFront`; framing SF-0 aprobado, provisional SF-3B [E01, E06, E12] | PV | Una referencia estratégica suficientemente clara con provenance y confirmación | ADAPT | P1 | KPI/señal sin baseline inventado; confirmación humana y versión. |
| PL-03 | Lenses/drivers/gaps estratégicos | SF-0 aprobado y ruta provisional de framing [E12] | PV/NV | Contexto adaptativo, no checklist de lentes obligatorios | ADAPT | P1 | Abordaje LIGHT no bloquea por lentes opcionales; discrepancias se declaran. |
| PL-04 | Crear/editar frentes y retos | `PortfolioService` y rutas `portfolio.router.ts` [E06] | EC | Preservar jerarquía canónica Front → Challenge → Initiative | KEEP | P0 | Create/update con permisos/scoping y sin crear reto inferido automáticamente. |
| PL-05 | Multiplicidad frente→retos→iniciativas | Servicios `listChallenges`, `listInitiativesForChallenge`, linked projects [E06] | EC/NV | Varias iniciativas por reto, retos por frente, navegación contextual | ADAPT | P1 | Un mismo reto registra 2+ iniciativas, owners/evidencias separados y sin conteos duplicados. |
| PL-06 | Retos sin iniciativa y activación | `challenge-state-machine` y Handoff target challenge-only; tensión Core v0.3 [E01, E09] | CONFLICTO | Un reto puede estar en asignación sin Initiative, sin contarse como ejecución activa | ADAPT | **P0** | ADR/decisión sobre estados, cobertura y «activo» antes de cambiar modelo. |
| PL-07 | Importar trabajo previo | `portfolio-bootstrap.service` expone import batch, preview, mapping, work items [E05] | EC/PV | Importación gobernada + clasificación + revisión humana; WorkItem ≠ Initiative | ADAPT | P0 | Se preservan fuentes, se revisan duplicados/conflictos y no se crean iniciativas automáticamente. |
| PL-08 | Alineamiento de iniciativa | Bootstrap `StrategicConnectionProposal`, InitiativePortfolioMeta y governance [E05, E06] | PV | Separar sugerencia de alineamiento confirmado y relación con KPI | ADAPT | P0 | Iniciativa no alineada/pendiente no se presenta «alineada» por IA. |
| PL-09 | Duplicidades / solapamientos | CRUD `listOverlaps/createOverlap` y análisis de coverage [E06, E07] | EC/NV | Hallazgo explicable con revisión de alternativas (fusionar/separar/cerrar) | ADAPT | P1 | Detección/sugerencia con razones y fuente; la IA no fusiona automáticamente. |
| PL-10 | Cobertura del reto | `ChallengeCoverageReadService` read-only y agregados [E07] | EC | Cobertura por trabajo real, hipótesis y contribución, no solo cantidad | ADAPT | P1 | Reto con 0, 1, 3 iniciativas distingue sin cobertura, parcial, suficiente y sobrecobertura con evidencia. |
| PL-11 | Capacidad, tiempo, recursos e inversión | Existe `portfolio-capacity.read-service.ts` y metadata de iniciativa [E06] | EC/NV | Mostrar coste/recursos actual y previsto con fuente, no ROI inventado | ADAPT | P1 | Estimado ≠ invertido ≠ aprobado; faltantes explícitos. |
| PL-12 | Reporte ejecutivo/priorización | Portfolio Executive Outputs, home alertas y decision lists [E06, E08] | PV/NV | Reportes vinculados a retos, evidencia y decisión accionable | ADAPT | P1 | Reporte explica resultado, incertidumbre, necesidad de decisión y versión de fuentes. |
| PL-13 | Acceso Portfolio por rol | `requirePermission('portfolio:write')`, `portfolio-resource-guard`, scope [E06, E24] | EC | Lead gobierna; ejecutor no obtiene acciones de gobierno por navegar Steps | KEEP | **P0** | Pruebas cross-org e IDOR para Front, Challenge, Project, decisiones y recursos. |

### C. Assign → Accept / Reject → Start → Post-Start (HO)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| HO-01 | Assignment tipado a reto o iniciativa | `portfolio-handoff` domain, repositorios Prisma y contrato v0.2 [E09] | EC | Conservar target_kind y referencia existente sin crear Initiative en Accept | KEEP | **P0** | Assigned Challenge aceptado no suma iniciativa; Assigned Initiative no duplica entidad. |
| HO-02 | Invitación email, token, identidad | Service de tokens/claim, delivery attempts, invitation router [E09] | EC/NV | Handoff entendible, seguro y recuperable incluso sin cuenta inicial | ADAPT | P0 | Token expirado/revocado, identidad ajena, reintento y registro preservan assignment. |
| HO-03 | Accept / Reject separados | `portfolio-handoff-response.service` requiere reason para Reject, owner para Start [E10] | EC | Aceptar responsabilidad no inicia Steps | KEEP | **P0** | `ACCEPTED` sin iniciativa nueva ni StepState; Reject no se reactiva silenciosamente. |
| HO-04 | Start independiente, versionado | `/:assignmentId/start`, `expectedVersion`, idempotency key [E10] | EC | Start registra inicio del encargo, sin crear Initiative por efecto invisible | KEEP | **P0** | Dos reintentos idénticos no duplican inicio; versión obsoleta rechazada. |
| HO-05 | Activation Overview / Brief del mandato | `HandoffShell`, `HandoffInvitationPage`; contrato frozen [E09, E11] | EC/NV | Contexto suficiente: qué recibí, objetivo, evidencia, restricciones, equipo y qué se espera de mí | ADAPT | P1 | Usuario entiende encargo y puede localizar sus fuentes antes de Start. |
| HO-06 | Consulta/aclaración al Portfolio Lead | Contrato TO-BE y hints de alertas; no se verificó circuito SupportRequest E2E [E25] | BR/NV | Mensaje contextual vinculado a reto/asignación, cola de atención y respuesta | NEW | **P0** | Solicitud emitida, visible para responsable, estado, retorno al owner; no concede permisos. |
| HO-07 | **Puente post-Start: reto→nueva Initiative** | Start retorna assignment; `HandoffInvitationPage.start()` no invoca formular iniciativa; `CreateProjectPage` tiene ruta legacy separada [E10, E11, E13] | **BR/PV** | Nuevo bounded context de formulación + confirmación + creación idempotente y vinculada | NEW | **P0** | Start → brief → Copilot → iniciativa candidata → confirmación → Initiative única + Step 0. |
| HO-08 | **Puente post-Start: Initiative existente** | Target kind existente y Project/Overview disponible, no se acreditó router/gating post-Start [E09, E11, E13] | PV/NV | Continuar misma identidad con historial/evidencia, no generar nueva iniciativa | ADAPT | **P0** | Start → brief narrativo → revisión → Step legítimo sin pérdida ni aprobación ficticia. |
| HO-09 | Mis iniciativas como única home del ejecutor | `CreateProjectPage`, páginas de participant/handoff y vistas Project legacy [E11, E13] | PV/NV | En una vista, assignments y mis iniciativas; sin sección Portfolio de ejecutor | ADAPT | P1 | Dos retos distintos y una iniciativa activa aparecen sin contar ni duplicar; navegación contextual. |
| HO-10 | Equipo y ownership | Handoff contract propone owner explícito y hasta 2 colaboradores; existen modelos de team [E09, E13] | EC/NV | Visibilidad y permisos de participación, transferencia de responsabilidad trazable | ADAPT | P1 | Owner exacto, cambio formal de ownership, colaboradores no pueden decidir en nombre del Lead. |

### D. Initiative Overview, nuevas / avanzadas / independientes (IO)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| IO-01 | Creación desde reto | `CreateProjectPage` hace `createProject` con `challengeLink` opcional [E13] | EC/PV | Crear solo después de formulación guiada y confirmación, bajo autoridad post-Start | ADAPT | **P0** | Reintento no crea duplicados; contexto del reto/mandato viaja a Step 0. |
| IO-02 | Iniciativa independiente | `CreateProjectPage` soporta creación sin `challengeLink` [E13] | EC | Entrada conversacional propia, sin Front ni Challenge obligatorio | ADAPT | P1 | Crear → Copilot → confirmar → Overview → Step 0 sin pedir datos corporativos. |
| IO-03 | Initiative Overview existente | `InitiativeOverviewPage.tsx` presenta estado y Step desde Adaptive Core [E13] | EC/legacy | Brief ejecutivo contextual y siguiente movimiento; no catálogo redundante de tarjetas | ADAPT | P1 | Vista explicita qué se espera, qué falta y Step activo desde estado real. |
| IO-04 | Iniciativa heredada avanzada | `reconstruction.service.ts` interpreta apoyo/contradicción de evidencia [E14] | PV/NV | Brief narrativo de continuidad y gating retroactivo | ADAPT | **P0** | Preserva resultados Step 3 históricos aunque Step 1 tenga gaps; no «avance 60%» inferido. |
| IO-05 | Contexto heredado y proveniencia | Step 0 prefill, contexto del reto y datos previos aparecen en varios modelos [E13, E15] | PV | Snapshot enlazado a mandato y revisiones, no copiar texto como verdad | ADAPT | **P0** | Cada claim de entrada lleva origen/versión/fecha y confirmación cuando aplique. |
| IO-06 | Cambio material de reto | `critical-change-*` y Adaptive Core tienen mecanismos de revisión dependiente [E15] | EC/NV | Alertar al owner, comparar versiones e identificar qué outputs quedan obsoletos | ADAPT | **P0** | Cambio de KPI a mitad de Step 2 no reescribe anteriores, marca `requires_review`. |
| IO-07 | Reentrada/resume/fallos | Controles de idempotencia/Handoff + API de Steps [E10, E15] | PV/NV | Recuperación de conversación, archivos, card y acción en curso sin pérdida | ADAPT | **P0** | Error de red/reload no pierde último input ni repite efectos. |

### E. Steps 0–4 y Cards de resultados (ST)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| ST-01 | Función estable de los 5 Steps | `AdaptiveCoreService` define Steps 0–4; manifiesto V2 separa lógica y UI legacy [E02, E03, E15] | EC/PV | Mantener funciones del Core sin crear un segundo playbook | KEEP | **P0** | La función de cada Step y su salida se conserva en todas las rutas. |
| ST-02 | Navegación de Steps / estados | `InitiativeOverviewPage`, `AdaptiveCheckpointWorkspace` [E13, E16] | EC | Conservar Stepper/contexto real, ocultar burocracia no útil | ADAPT | P1 | El usuario entiende Step actual/objetivo/siguiente acción sin ver acciones de Portfolio. |
| ST-03 | Entrada con contextos diferentes | Step 0 combina formulario legacy + checkpoint con prefill [E15, E16] | PV | Copilot acepta «no sé», documentos previos, hipótesis, tarea ya definida | ADAPT | **P0** | Tres perfiles recorren el mismo Step con acciones diferentes y sin preguntas irrelevantes. |
| ST-04 | Copilot conversacional real por Step | `AdaptiveCheckpointWorkspace` itera `questions.map()` en textarea [E16]; IA worker por tarea [E18] | BR | Conversación como interfaz principal, con input abierto y herramientas contextuales | NEW | **P0** | Un input nuevo altera próxima acción y Card por significado, no por orden de turno. |
| ST-05 | Card viva por Step | Adaptive Core guarda outputs/checkpoint responses; `outputSummaryRows()` los resume [E15, E16] | PV | Card con output esperado, hechos/hipótesis/gaps, evidencia y versiones | ADAPT | **P0** | «No sé» no va a propuesta; un párrafo puede completar 2+ campos correctos con confirmación. |
| ST-06 | Step 0: enmarcar y alinear con mandato | Planner determina variables como objective/scope/hypothesis, con filtros contextuales [E17] | EC/PV | Comprender primero contexto, propósito y trabajo a comprobar; evita sesgo IA | ADAPT | **P0** | No exige solución prematura; distingue alineamiento con reto de autoridad para cambiar mandato. |
| ST-07 | Step 0 → Step 1 | Output `AlignmentBrief + ValidationContract`; tests de Adaptive Core [E15, E17] | EC/NV | Entregar **una incertidumbre/trabajo verificable** y su porqué | ADAPT | **P0** | Step 1 recupera lo que falta contrastar y no pregunta lo ya aclarado. |
| ST-08 | Step 1: orientar investigación | `Step1Page.tsx` integra ResearchModuleV2 y CaptureSynthesis; agente Research Assistant [E18, E21] | PV | Determinar con quién/dónde/qué investigar según objetivo y fuentes disponibles | ADAPT | **P0** | Usuarios con/sin datos reciben métodos diferentes, justificados. |
| ST-09 | Step 1: evidencia/contraste | Research, síntesis/AS-IS y evidencia en módulos [E21, E22] | PV | Compara lo supuesto en Step 0 vs observado, permite reencuadrar | ADAPT | **P0** | Hallazgo contrario (no es falta de IA, sino coordinación) actualiza Card y conserva historia. |
| ST-10 | Step 2: alternativas y método | `Step2Page`, SolutionDesignAgent (HMW/ideate/routes) [E18, E21] | EC/PV | Primero comprender e idear, después recomendar Crazy 8s/HMW/u otra técnica contextual | ADAPT | **P0** | No inicia con Figma/Power Apps por defecto; pregunta por ideas disponibles si cambia la estrategia. |
| ST-11 | Step 2: artefacto viable e impacto | Experiment routes y output de Step 2 [E15, E18, E21] | PV | Impacto exigido vs proxy demostrable, tiempo, know-how, recurso y apoyo | ADAPT | **P0** | Figma no se presenta como prueba de leads reales; ofrece prueba comercial o solicitud de apoyo. |
| ST-12 | Step 3: ejecución y feedback | `Step3Page` y Experiment Coach (prototype/analyze), outputs adaptativos [E18, E21] | PV | Diseñar plan/medición, registrar malla receptora/resultado, interpretar esperado vs real | ADAPT | **P0** | Hipótesis queda soportada/refutada/inconclusa según evidencia, no por completar card. |
| ST-13 | Step 3: no iterar | Decision Readiness tiene rutas de continuidad/pausa/cierre [E23] | EC/NV | Elegir no iterar sin afirmar validación; preparar decisión adecuada | ADAPT | P1 | «No iterar» conduce a recomendación con límites, no a éxito automático. |
| ST-14 | Step 4: cerrar y sustentar | `Step4Page`, Narrative Builder y Decision Readiness [E18, E21, E23] | PV | Preparar Brief/Decision Package para Portfolio con recursos, evidencia y recomendación | ADAPT | **P0** | Decisor visualiza fundamento, coste/tiempo, riesgo y opciones, sin repetir trabajo. |
| ST-15 | Transiciones/gates por suficiencia | AdaptiveCore, Checkpoint Evidence Policy y Planner [E15, E17] | EC | Validar evidencia, coherencia, vigencia y autoridad, no longitud de texto | ADAPT | **P0** | Respuesta irrelevante/no sé no habilita transición; soft gaps informados pueden coexistir. |
| ST-16 | Mentor / validadores | AI feedback, mentor endpoints y reglas del Core [E15, E18, E21] | PV/NV | Validador según tipo de decisión, criticidad y requisitos; sin inventar aprobación | ADAPT | P1 | Gate exige actor autorizado donde aplique; IA no se aprueba a sí misma. |
| ST-17 | Herramientas/contexto por Step | UI y agentes poseen módulos específicos [E18, E21] | PV | Superficie contextual que abre guía, plan, adjuntos, prototipo, registros según necesidad | ADAPT | P1 | No se obliga a abrir módulos vacíos; actividad de Copilot conserva output/evidencia. |

### F. IA, orquestación, ingestión, verdad y soporte (AI)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| AI-01 | Modelo mental universal | Existen harness/modelos por tareas, pero no se observó uso integral por cada Step [E17–E19, E26] | BR/PV | ORIENTAR→ENTENDER→ENFOCAR→ACTUAR→OBSERVAR→INTERPRETAR→ADAPTAR invisible como wizard | NEW | **P0** | 3 perfiles generan movimientos diferentes sobre el mismo Step manteniendo invariantes. |
| AI-02 | Extracción semántica cada input | Entry posee provenance; Steps conservan respuestas estructuradas por variables [E04, E16] | PV | Clasificar dato, evidencia, supuesto, contradicción, duda, bloqueo, propuesta y corrección | ADAPT | **P0** | Card recibe los campos semánticamente correctos con fuente; error detectado sin escribir. |
| AI-03 | Siguiente intervención/router | Orquestador Python dirige por `(step, action)`; no selecciona acción autónomamente desde contexto total [E18] | EC/PV | Elegir ASK, ANALYZE, PREPARE_METHOD, ACT, REQUEST_SUPPORT, CHECKPOINT... | ADAPT | **P0** | Cierre del turno explica intervención y por qué es útil ahora, sin loops infinitos. |
| AI-04 | Agentes especialistas | research/solution/experiment/narrative/mentor existen [E18] | EC | Reutilizar bajo motor madre, no crear 5 chats separados | KEEP | P1 | Mismo hilo/estado, agente correcto usado por actividad y salida validada por schema. |
| AI-05 | Portfolio Copilot | Conversaciones y action plans persisten; registry acotado a `CreateStrategicFront`; adapter determinista [E19] | EC/PV | Evitar confundir este copilot con el Copilot adaptativo de Initiative Steps | ADAPT | P1 | Capability de Steps explícita y sometida a permisos, sin expandir autoridad IA. |
| AI-06 | Revisión crítica y pensamiento sistémico | IA research y reconstrucción pueden analizar; no se observó loop global estructurado [E14, E18] | PV | Contrastar explicación inicial, causalidad, dependencias y alternativas en cada Step | NEW | **P0** | Caso IA-onboarding cambia foco por datos contrarios sin perder mandatos. |
| AI-07 | Ingesta en cualquier Step | PDF extraction por rutas del proyecto y EvidenceService; v0.6 no lee archivos [E20–E22, E27] | PV | Subir/pegar fuentes desde brief y Step 0–4, distinguiendo recibido/procesado/revisado | ADAPT | **P0** | Ingesta no reemplaza evidencia previa, vincula fuente, estado y permisos. |
| AI-08 | Provenance por claim y revisión | `truth`, `AutofillContext`, propuestas de PDF, adaptive evidence policy [E20–E22] | EC/PV | Origin, source ref, fecha, estado de revisión y contradicción por claim | ADAPT | **P0** | AI_SUGGESTED nunca aparece como hecho humano confirmado sin aprobación. |
| AI-09 | «No sé» / texto irrelevante | Mockup QA reproduce error; Planner permite unknown según spec [E17, E27] | BR | Diferenciar ausencia de conocimiento, error y bloqueo; ofrecer vía de comprensión | ADAPT | **P0** | «No sé» deja desconocido, genera pregunta o acción útil, no altera propuesta. |
| AI-10 | Solicitudes de desbloqueo | TO-BE SupportRequest; no se verificó circuito único de petición hacia cola Portfolio [E25] | BR/NV | Ayuda con datos, área, permiso, dev, presupuesto, scope y decisiones | NEW | **P0** | Solicitud con contexto/riesgo/estado/owner recibida y respondida por actor válido. |
| AI-11 | Fallback/fallo IA | Fallbacks y circuitos de retry en Entry/AI; diferente cobertura en Steps [E04, E18] | PV/NV | Input, card y fuentes persisten ante timeout, reintento seguro y error visible | ADAPT | **P0** | Simular 500/timeout no duplica ni borra, no confirma output inválido. |

### G. Decisión, retorno, beneficios, seguridad y calidad (DC)

| ID | Capacidad | AS-IS observado (fuente) | Estado | TO-BE / GAP | Tratamiento | Prioridad | AC |
|---|---|---|---|---|---|---|---|
| DC-01 | Resultado Step→Portfolio | `syncInitiativeProgress` y `PortfolioHomeReadService` proyectan señales [E07, E08, E23] | EC/PV | StepResultEnvelope o equivalente, con resultado/evidencia/autoridad y versión | ADAPT | **P0** | Al completar Step 1/2/3, Portfolio ve estado relevante sin escribir StepState. |
| DC-02 | Decision Package | Adaptive Core y DecisionRequest/Step4 output en servicios [E15, E23] | EC/PV | Comparar meta, evidencia/resultado, consumo de recursos, límites y recomendación | ADAPT | **P0** | Paquete legible para decisor, con links a fuentes y decisión solicitada. |
| DC-03 | Autoridad de decisión | `decision-authority.resolver.ts`, `DecisionReadinessResolver`, servicios de decisión [E23] | EC | IA recomienda; actor autorizado decide; Portfolio Lead prepara y coordina | KEEP | **P0** | Rechazo de decide/approve por owner o rol no autorizado y trazabilidad del actor. |
| DC-04 | Persistencia/retorno de decisión | `decision-portfolio-return.ts` actualiza cobertura y estados vinculados [E23] | EC/NV | Retorno atómico visible en Home/reto con historial y reintentos | ADAPT | **P0** | Un cierre impacta la lectura de cobertura correctamente, sin doble aplicación. |
| DC-05 | Impacto y atribución | Metadatos KPI/impacto y estados; `BenefitTracking` no localizado en código inspeccionado [E07, E23] | PV/NV | Separar esperado, proxy, observado y atribuido; beneficio posterior requiere ADR/re-test | NEW | P1 | Un ROI estimado nunca aparece como L5/L6 realizado/atribuido sin evidencia y autorización. |
| DC-06 | Observabilidad E2E | Tests unit/integration/E2E presentes por módulos; QA histórica por slices [E02, E03, E26] | EC/EL | Trazas correlacionadas entry→reto→assignment→initiative→step→decision | ADAPT | P1 | ID de seguimiento y eventos causales en todos los handoffs. |
| DC-07 | Seguridad cross-org | Resource guards, roles, scoped API de Portfolio, Handoff checks [E06, E09, E24] | EC/NV | Prueba transversal de roles/identidad y fuentes; no solo guards unitarios | ADAPT | **P0** | Intentos de leer/editar reto, evidencia o decisión ajena denegados y auditados. |
| DC-08 | Convivencia V1/V2 | Manifest distingue Steps legacy, migración por slice [E02, E03] | CONFLICTO/PV | Retirar vistas duplicadas al cerrar migraciones sin romper usuarios antiguos | REMOVE | P1 | Todos los consumidores conocidos migran y hay pruebas de no regresión antes de borrar. |
| DC-09 | Piloto real E2E | Informes locales; esta auditoría no ejecutó E2E [E02, E03, E26] | NV | Tres journeys completos, LLM real o piloto controlado, revisión humana UX | NEW | **P0** | 0 hard failures de autoridad, truth, datos, handoff y transiciones en escenarios definidos. |

**Cobertura de matriz:** 6 filas PE + 13 PL + 10 HO + 7 IO + 17 ST + 11 AI + 9 DC = **73 capacidades**. Las filas con `NEW` representan **capacidades no acreditadas de extremo a extremo en la lectura realizada**, no una afirmación absoluta de que no exista código en otras ramas.

---

## 6. Dependencias críticas y decisiones que NO deben resolverse silenciosamente

| ID | Decisión pendiente | Riesgo | Propuesta de tratamiento | Dueño recomendado |
|---|---|---|---|---|
| GOV-01 / D-03 | ¿Cuándo se considera un Reto activo y qué cobertura se exige si tiene 0 iniciativas? | Fabricar Initiative al aceptar o bloquear challenge-only | Reconciliar Core v0.2 vs candidata v0.3, contrato Handoff v0.2 y lifecycle real; ADR si cambia dominio | Product + Tech Lead |
| POST-01 / B-01 | ¿Qué comando post-Start crea la Initiative desde reto? | Duplicados e ownership sin trazabilidad | Experience Contract post-Start y comando idempotente con confirmación | Product + Backend |
| POST-02 / B-02 | ¿Cómo se determina Step legítimo de iniciativa avanzada? | 60%/Step falso, saltarse evidencia | Reconstrucción por función/evidencia + sufficiency + review humana cuando aplique | Product + Core |
| POST-03 / B-03 | ¿Quién confirma vínculo de contribución y cambios materiales de mandato? | Initiative Owner modifica estrategia | Matriz de responsabilidades y checkpoints humanos | Product + Portfolio |
| AI-BOUND-01 | ¿Cómo se integra motor madre con Adaptive Checkpoint Planner sin duplicar autoridad? | Segundo motor de gating, drift semántico | Motor propone intervención y Card delta; Adaptive Core valida y gobierna transiciones | AI Lead + Core |
| CARD-01 | ¿Qué schema/versión/provenance gobierna Card viva por Step? | «No sé» como dato canónico, pérdida de evidencia | Definir tipado, lifecycle de propuestas y revisión | Product + Backend |
| SUPPORT-01 | ¿Quién recibe/autoriza SupportRequest y cómo se resuelve? | Solicitudes sin dueño o permisos indebidos | Diseñar evento/cola, estado, destinatario y permisos | Portfolio + Backend |
| BENEFIT-01 / D-08 | L5/L6 y seguimiento de beneficios post Step 4 | ROI ficticio | Limitar primer piloto a resultado/impacto observado defendible; ADR/re-test para extensión | Product + Core |
| SNAPSHOT-01 / D-09 | Currentness de mandato y evidencia tras corrección | Decisiones sobre data obsoleta | Versionar source revision y re-review de outputs dependientes | Core + Backend |
| V2-01 / D-12 | Ramas/targets vs `main`, flags y consumidores V1 | Implementar encima de código desactualizado | Baseline branch/commit/flags, matriz de consumidores y PRs; repetir auditoría en branch de trabajo | Tech Lead |

**Bloqueantes de implementación:** `GOV-01`, `POST-01`, `POST-02`, `POST-03` y `AI-BOUND-01` cuando afecten dominio/gating/autoridad. La UX puede prototiparse y testearse aislada sin modificar esos invariantes.

---

## 7. Plan de pruebas AS-IS y aceptación del TO-BE

**Estado:** casos propuestos, **NO ejecutados en este informe**. Primero ejecutar como *baseline AS-IS*, luego repetir contra la integración TO-BE.

| Caso | Recorrido / estímulo | Qué verifica | Prioridad |
|---|---|---|---|
| T01 | Público → Portfolio Entry → login → setup → Portfolio Home | Origen/conversión sin creación canónica temprana, identidad y continuidad | P0 |
| T02 | Portfolio Lead directo con 2 frentes y 4 retos | Multiplicidad, permisos, contextualización y priorización | P1 |
| T03 | Importar 20 iniciativas con 3 posibles duplicados | No inventar alignment, clasificación y confirmación por humano, provenance | P0 |
| T04 | Crear reto y asignarlo sin Initiative existente | `Assign ≠ Accept ≠ Start`; no Initiative prematura | **P0** |
| T05 | Usuario recibe 2 retos y 1 iniciativa | Vista `Mis iniciativas` sin duplicación y con estado real | P1 |
| T06 | Aceptar reto, no dar Start, cerrar navegador | No Step iniciado; recuperación segura | **P0** |
| T07 | Start con mismo idempotency key dos veces | Una transición y un único evento | **P0** |
| T08 | Tras Start de reto nuevo, formular iniciativa y confirmar | Una Initiative vinculada y Step 0 precargado, autoridad correcta | **P0** |
| T09 | Start de Initiative avanzada con resultados Step 3 previos | Misma entidad; preservar historial y marcar verificaciones faltantes | **P0** |
| T10 | Crear iniciativa independiente sin empresa | No forzar Reto/Frente/Portfolio y Step 0 accesible | P0 |
| T11 | Step 0: «no sé cómo funciona onboarding» | Copilot ofrece reconstrucción/contexto sin convertirlo en propuesta | **P0** |
| T12 | Step 0: usuario sube 2 archivos y luego corrige un dato | Fuentes no se sobrescriben, Card clasifica contenido, provenance | **P0** |
| T13 | Step 0: solución IA preconcebida | Reverse alignment sin sesgo; pregunta solo lo que cambia enfoque | P0 |
| T14 | Step 1: evidencia refuta causa inicial | Reframe motivado; Step 2 recibe hallazgo, no hipótesis obsoleta | **P0** |
| T15 | Step 1: reporte cualitativo + cuantitativo previo | No obligar entrevistas adicionales; guía contextual por necesidad | P0 |
| T16 | Step 2: KPI captar leads + solo Figma | Distinguir señal proxy de leads reales; apoyo o experimento adecuado | **P0** |
| T17 | Step 2: usuario sin know-how o permisos TI | SupportRequest válida y trabajo paralelo sin violar restricciones | P0 |
| T18 | Step 3: resultado contrario, mixto o inconcluso | Interpretación honesta, no forzar éxito/iteración | **P0** |
| T19 | Step 3: no iterar | Recomendar pausa/cierre/decisión sin aprobación falsa | P1 |
| T20 | Step 4: preparar decisión con recursos y límites | Decision Package trazable con expected vs observed y evidencias | **P0** |
| T21 | Portfolio recibe request y decide | Autoridad correcta, cobertura/estado retornan con histórico | **P0** |
| T22 | Cambio de KPI mientras Step 2 está activo | Delta de mandato, dependencias `requires_review`, sin sobrescribir pruebas | P0 |
| T23 | Cross-org IDOR / permiso de mentor / viewer / owner | 403/404 y no exposición de fuentes ni decisiones | **P0** |
| T24 | Timeout de IA entre respuesta y guardado | Reintento idempotente, no pérdida ni confirmación ficticia | **P0** |
| T25 | Respuesta sin sentido de 30 palabras | No actualizar Card ni desbloquear checkpoint | **P0** |

**Harness recomendado:** tests deterministas de estado/permisos + casos LLM *live* repetidos + evaluación humana de relevancia, claridad y no invención; dataset development/regression/holdout. Una suite con 100% PASS determinístico demuestra regresión técnica, **no calidad cognitiva real**.

---

## 8. Roadmap por dependencias — propuesta de ejecución, no autorización

| Orden | Paquete | Resultado entregable | Dependencia / bloqueo | Criterio de GO |
|---|---|---|---|---|
| F0 | Congelar baseline técnica de trabajo | Commit/branch, flags, DB, PRs, run E2E inicial y consumidores legacy | Acceso a entorno autorizable | «AS-IS» verificable y reproducible |
| F1 | Autoridad y transiciones | Resolver GOV-01 y contrato post-Start, roles, estados e idempotencia | ADR si dominio cambia | T04, T06–T09 PASS |
| F2 | Contexto E2E y read models | Mandato versionado, Initiative/Step context, fuente y links a Portfolio | F1 | Mismo mandato vigente visible en reto, brief, Step y decisión |
| F3 | Card viva + motor semántico *aislado* | `classify_input → propose_card_delta → review/apply`, sin tocar Step gates | Schemas/provenance | T11–T14, T25 PASS y evaluación humana |
| F4 | Copilot de Step 0 y 1 | Entender perfil, investigar/contrastar y orientar según evidencia | F3, mecanismos de archivos | T11–T15 PASS |
| F5 | Step 2 y 3 orientados a impacto | Ideación antes que herramienta; prototipo/impacto/feedback; soporte | F4, capability registry y support | T16–T19 PASS |
| F6 | Step 4 + Portfolio Decision Loop | Package, authority, registro de decisión, retorno de señales | F2, F5 | T20–T22 PASS |
| F7 | E2E piloto controlado y migración visual | Tres journeys, roles, datos reales controlados, fallos de red, UX | F0–F6 | T01–T25 sin hard failures |
| F8 | Limpieza V1 y capacidades no MVP | Deprecar consumidores probados; beneficios avanzados/integraciones solo con nueva autoridad | F7 + ADR/re-test | No-regresión sin rutas huérfanas |

**No hacer:** «rediseñar UI completa → cambiar prompts → descubrir incompatibilidad con Core»; eliminar Steps legacy sin mapa de consumidores; sustituir de golpe Adaptive Core; fusionar un PR gigante para Portfolio y Steps; tratar el HTML como regla de backend; extrapolar status de iniciativa desde número de preguntas contestadas.

---

## 9. Matriz de no regresión / controles de protección

| Invariante a proteger | Prueba obligatoria |
|---|---|
| `Assign ≠ Accept ≠ Start` | T04, T06, T07 |
| Challenge Assignment no fabrica Initiative | T04, T08 |
| Múltiples retos e iniciativas, alcance por organización | T02, T05, T23 |
| Initiative existente no se duplica ni pierde historia | T09 |
| Initiative independiente no exige contexto corporativo | T10 |
| IA no confirma alineamiento / evidencia / inversión | T03, T11–T16, T21 |
| Copilot conversacional no es base canónica | T12, T14, T25 |
| Step 0–4 conservan funciones fijas | T11–T20 |
| Checkpoint se basa en suficiencia, no llenar fields | T11–T16, T25 |
| Step 4 no se confunde con impacto atribuido | T18–T21 |
| Portfolio consume eventos/read models; no escribe StepState | T20–T22 |
| Fuente nueva no borra historia / mandatos versionados | T12, T22 |
| Reintentos, permisos, auditable decisions | T06–T07, T23–T24 |

---

## 10. Registro de evidencia y enlaces del AS-IS

Enlaces a GitHub fijados al commit `75fc358...` salvo que se indique que son documentos **locales**. Los archivos fuente prueban **existencia e intención técnica**; no acreditan paso de tests ni despliegue. Se recomiendan como punto de partida para revisión de PR y Tech Spec.

| ID | Fuente | Qué sustenta |
|---|---|---|
| E01 | [Authority map](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/STARTERIA_AUTHORITY.md), [Core factual](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/doc/CONTRATO_LOGICA_CORE_STARTERIA_MVP_v0.2_ES%281%29.md), [Core candidato](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/core/STARTERIA_CORE_LOGIC_CONTRACT.md) | Jerarquía y diferencias entre Core v0.2 y v0.3 candidata. |
| E02 | [CURRENT_STATE.md](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/CURRENT_STATE.md) | Estado mixto del repo, legacy, fronteras V2, ausencia de certificación productiva global. |
| E03 | [STARTERIA_V2_MANIFEST.md](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/STARTERIA_V2_MANIFEST.md) | Estado lógico/implementación/visual/evidencia por slice; Steps V1/mixed. |
| E04 | [Portfolio Entry Session Controller](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-entry-runtime/session/session-controller.ts), [Current State Audit histórico](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/implementation/PORTFOLIO_ENTRY_CURRENT_STATE_AUDIT.md) | Interpretación y continuidad provisionales; legado de conversión. |
| E05 | [Portfolio Bootstrap Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-bootstrap/portfolio-bootstrap.service.ts), [Analyzer](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-bootstrap/portfolio-bootstrap.analyzer.ts) | Import batch, work items, mapeo, staging de propuestas y conexiones. |
| E06 | [Portfolio Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio.service.ts), [Router](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio.router.ts) | Frentes, retos, invitaciones, equipos, iniciativas, solapamientos, reportes, permisos. |
| E07 | [Challenge Coverage](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/challenge-coverage.read-service.ts), [Initiative Progress](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/initiative-progress.ts) | Lectura de cobertura y derivación del estado desde Steps. |
| E08 | [Portfolio Home Read Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio-home.read-service.ts), [Portfolio Home frontend](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/PortfolioLeadHomePage.tsx) | Read model y UI con composiciones mixtas/flags. |
| E09 | [Activation contract frozen v0.2](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/portfolio-lead/05-activation-handoff/PORTFOLIO_TO_INITIATIVE_ACTIVATION_EXPERIENCE_CONTRACT_v0.2.md), [Assignment Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-handoff/application/portfolio-handoff-assignment.service.ts), [Invitation Router](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-handoff/portfolio-handoff-invitation.router.ts) | Frontera del Handoff y rutas reales. |
| E10 | [Response Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-handoff/application/portfolio-handoff-response.service.ts) | Accept / Reject / Start, owner, versión, idempotencia, eventos. |
| E11 | [Handoff Invitation Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/HandoffInvitationPage.tsx), [HandoffShell](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/features/portfolio-handoff/components/HandoffShell.tsx) | Experiencia de recepción y comportamiento del Start frontend. |
| E12 | [Strategic Framing SF-0](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/portfolio-lead/07-strategic-framing/STRATEGIC_FRAMING_EXPERIENCE_CONTRACT_v0.1.md), [SF provisional state](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/strategic-framing/strategic-framing.provisional-state.service.ts), [SF-1 audit](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/docs/portfolio-lead/07-strategic-framing/STRATEGIC_FRAMING_CURRENT_STATE_AUDIT_SF1_v0.1.md) | Framing, provisional/canonical boundaries y limitaciones históricas de entradas. |
| E13 | [CreateProjectPage](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/CreateProjectPage.tsx), [InitiativeOverviewPage](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/InitiativeOverviewPage.tsx), [ParticipantChallengeDetailPage](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/ParticipantChallengeDetailPage.tsx) | Crear iniciativa legacy y overview actual. |
| E14 | [Reconstruction Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/reconstruction/reconstruction.service.ts) | Clasificación supports/contradicts/insufficient; alcance no equivale a full retroactive gating. |
| E15 | [Adaptive Core Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/adaptive-core.service.ts), [Checkpoint Evidence Policy](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/checkpoint-evidence-policy.ts) | Configuraciones, resultados, transiciones, evidencias y decisiones. |
| E16 | [AdaptiveCheckpointWorkspace](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/features/adaptive-core/components/AdaptiveCheckpointWorkspace.tsx), [Step 0 Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/Step0Page.tsx) | Preguntas renderizadas, formulario legacy y coexistencia de checkpoints. |
| E17 | [Checkpoint Planner](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/checkpoint-planner.ts) | Catálogo de variables, prefill y preguntas adaptadas por contexto de forma determinista. |
| E18 | [Orchestrator IA](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/ai-service/agents/orchestrator.py), [Research Assistant](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/ai-service/agents/research_assistant.py), [Solution Design](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/ai-service/agents/solution_design.py), [Experiment Coach](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/ai-service/agents/experiment_coach.py) | AI especializada por funciones y rutas. |
| E19 | [Copilot orchestration](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-orchestration.service.ts), [Capability Registry](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/capability-registry.ts), [Runtime config](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-runtime-config.ts) | Conversación y planes, capability centrada en CreateStrategicFront y adapter determinista. |
| E20 | [Evidence Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/evidence/evidence.service.ts), [PDF Router](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/initiative-pdfs/pdf.router.ts) | CRUD evidence y extracción con review de proposals. |
| E21 | [Step 1 Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/Step1Page.tsx), [Step 2 Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/Step2Page.tsx), [Step 3 Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/Step3Page.tsx), [Step 4 Page](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/Step4Page.tsx) | Formularios/módulos actuales y pasos funcionales implementados. |
| E22 | [Truth Service](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/truth/truth.service.ts), [pdf extraction / flatten](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/initiative-pdfs/extraction-flatten.ts) | Soporte a claims, fuentes y propuestas; requiere revisión E2E de semántica. |
| E23 | [Decision Readiness](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/decision-readiness.resolver.ts), [Decision Portfolio Return](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/decision-portfolio-return.ts), [Decision Authority](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/decision-authority.resolver.ts) | Readiness, autoridad y retorno a coverage y portafolio. |
| E24 | [Portfolio Resource Guard](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio-resource-guard.ts), [Auth](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/auth/auth.middleware.ts) | Validación de acceso/scoping, requiere pruebas cross-org globales. |
| E25 | **Referencia TO-BE local:** `STARTERIA_PORTFOLIO_STEPS_E2E_INTEGRATION_v0.1.md` §8 | Definición **candidata** de `SupportRequest`, pendiente de contraste con modelos existentes. |
| E26 | [Adaptive Core tests](https://github.com/DarkCodePE/plataforma-starteria/tree/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/__tests__), [front/e2e](https://github.com/DarkCodePE/plataforma-starteria/tree/75fc358838c34174da858937f4b47b92b8fbf074/front/e2e), [AI tests](https://github.com/DarkCodePE/plataforma-starteria/tree/75fc358838c34174da858937f4b47b92b8fbf074/ai-service/tests) | Existencia de suites, no ejecución en esta auditoría. |
| E27 | **Evidencia local de prototipo:** `Starteria_Steps_v06_QA_2_Perfiles.md` y `Starteria_Steps_Conversacion_Card_Viva_v06.html` | Fallos específicos del mockup; no extrapolar a producción. |

---

## 11. Riesgos, alcance, pendientes de segunda pasada

### 11.1 Riesgos principales

- **R-01 / autoridad:** promover Core v0.3 candidata o freezes a norma canónica sin ADR/re-test.
- **R-02 / doble lifecycle:** Handoff/Project/AdaptiveCore escribiendo estados incompatibles o duplicando Initiative.
- **R-03 / semántica:** Card alimentada por posición de turno o «texto presente», no por extracción y evaluación contextual.
- **R-04 / evidencia:** confundir documento subido, datos extraídos, claim respaldado, validación humana y resultados observados.
- **R-05 / delegación:** Portfolio Lead / Copilot operando permisos de Initiative Owner, o viceversa.
- **R-06 / reporting:** un mockup, prototype o KPI proxy se reporta como impacto conseguido.
- **R-07 / migración:** refactor profundo de Step 1/2 borra workspaces legacy, resultados, tests o usuarios existentes.
- **R-08 / complejidad:** intentar un multi-agent nuevo sin aprovechar adaptadores, checkpoints, schemas y agentes ya construidos.
- **R-09 / calidad:** confiar en tests deterministas para declarar utilidad real de un Copilot LLM.

### 11.2 Segunda pasada técnica necesaria para subir confianza

1. Obtener la **rama y commit exactos del entorno donde el usuario prueba Startería**; inventariar flags, migraciones, servicios desplegados, proveedor IA y rollback.
2. Ejecutar scripts de baseline (`typecheck`, pruebas relevantes de backend/front/AI y Playwright E2E), con reporte de comandos, entornos, tiempos y errores.
3. Abrir el Journey real en navegador con 3 perfiles, registrar capturas/replay y rastrear IDs hasta persistencia; no usar el HTML como sustituto.
4. Obtener estado factual de `SupportRequest`, servicios de importación/canonicalización, **todas las** Cards/evidencias y rutas de Decision Package, revisando migraciones, API y consumidores.
5. Mapear 100% de endpoints Handoff → post-Start y Step 4 → Portfolio con eventos/logs y versión de source.
6. Verificar escenarios de seguridad: cross-org, viewer, mentor, assigned owner, invitación revocada y reintento en condiciones de carrera.
7. Completar columna `runtime_result`, `test_run_id`, `deployment_sha`, `reviewer`, `final_treatment` para cada fila P0, con referencias permanentes a evidencia.

### 11.3 Criterio de cierre de auditoría E2E

La matriz se considerará **diagnóstico integral verificado (v1.0)** solamente cuando las 73 capacidades tengan decisión trazable, y todas las P0 cuenten con: (a) estado AS-IS observado en runtime o prueba de ausencia suficiente; (b) fuente de autoridad resuelta; (c) resultado de al menos un test relevante; (d) tratamiento aprobado; (e) responsables/estimación/dependencias; (f) aceptación objetiva y evidencia repetible. Hasta entonces, v0.1 es **baseline estática preliminar y plan de verificación**, no certificado del producto.

## 12. Próximo paso acordable

**No abrir todavía PR de funcionalidad.** A partir de esta matriz:

1. Revalidar la rama desplegada y ejecutar la segunda pasada, priorizando **P0**.
2. Reconciliar decisiones `GOV-01 / POST-01 / POST-02 / POST-03 / AI-BOUND-01` sin modificar silenciosamente contratos.
3. Validar la selección KEEP/ADAPT/REMOVE/NEW en sesión de producto/tech; añadir owners, estimación y tests reales.
4. Convertir las brechas aprobadas en slices pequeños (y solo entonces tech specs / PRs).

**Principio de cierre:** una experiencia E2E consistente se consigue cuando la estrategia del Portfolio Lead, la responsabilidad aceptada por Initiative Owner, la evidencia de Steps y la decisión final son **una única cadena trazable**, no pantallas visualmente parecidas.


---

## 13. Segunda pasada: código, CI/CD y limitaciones de runtime

**Versión:** 0.2 · **Fecha:** 20/10/2026 · **Modalidad:** AUDIT ONLY · **Estado:** `REPO+CI_VERIFIED_SCOPED / LIVE_UI_BLOCKED`  
**Repositorio:** `DarkCodePE/plataforma-starteria` · **Referencia inmutable:** [`75fc358838c34174da858937f4b47b92b8fbf074`](https://github.com/DarkCodePE/plataforma-starteria/commit/75fc358838c34174da858937f4b47b92b8fbf074).  
**Documento base:** `STARTERIA_E2E_ASIS_TOBE_GAP_MATRIX_v0.1.md` (73 capacidades, 46 P0, 26 P1, 1 P2).  
**TO-BE:** freezes candidatos de Steps y Portfolio↔Steps E2E; no sustituyen autoridad del repositorio.

### 13.0. Veredicto de esta pasada

Se pudo **verificar directamente por conector de GitHub** el estado de `main`, código de rutas/servicios, PRs fusionados, y **resultados de CI/CD de GitHub Actions** para el commit. Se pudo confirmar que el workflow de CD llegó a `Deploy to Rackspace Spot` y sus pasos de rollout y verificación finalizaron con `success`. **Esto no sustituye una prueba de experiencia de usuario en producción**.

Se intentó consultar la landing, `/dashboard` y `/public/start` mediante los medios de navegación disponibles y se probó conectividad desde el entorno de ejecución; **el sitio `https://starter-ia.com` no resultó accesible** por esos medios. No se realizó login, recorrido de navegador autenticado, inspección de base de datos productiva, validación contra proveedor LLM real, ni captura nueva de UX productiva. No se deben inferir fallos de la plataforma de esa inaccesibilidad: puede ser una restricción de este entorno.

**Resultado:** se elevó la confianza en *existencia e integración CI/CD acotada* y se corrigieron clasificaciones específicas; **la auditoría funcional en producción queda bloqueada**, no se simula con el HTML ni se declara superada. No se modificó código ni datos.

### 13.1. Evidencia nueva comprobada en esta pasada

| ID | Fuente / evidencia inmutable | Lo que prueba | Lo que NO prueba |
|---|---|---|---|
| V02-01 | [commit main 75fc3588](https://github.com/DarkCodePE/plataforma-starteria/commit/75fc358838c34174da858937f4b47b92b8fbf074) | La línea base `main` observada no cambió desde v0.1. | SHA desplegado actualmente en cada pod y configuración runtime. |
| V02-02 | [GitHub Actions CD #39080710106](https://github.com/DarkCodePE/plataforma-starteria/actions/runs/39080710106) | `success` en lint/build, Node tests/coverage, Python unit, Prisma drift, E2E light, imágenes backend/AI/frontend y Deploy to Rackspace Spot. | Calidad y completitud de E2E Portfolio→Steps; usabilidad real; éxito de LLM bajo datos nuevos. |
| V02-03 | [`.github/workflows/ci.yml`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/.github/workflows/ci.yml) | E2E light focaliza Portfolio Entry (`CURRENT_114D`, `LEGACY_COMPAT`, Live Understanding, PostgreSQL confirmation). | Journey completo con Assignment→Start→Step 0–4→Portfolio, ni browser de producción. |
| V02-04 | [`.github/workflows/cd.yml`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/.github/workflows/cd.yml), [script API smoke](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/scripts/ci/prod-api-smoke.sh) | En deploy hay verificaciones de schema/API tras rollout y paso de smoke autenticado condicional. El script consulta `GET` de Strategic Fronts, Home, Capacity, Projects tras login. | Que el smoke con tenant se haya **ejecutado** (el workflow puede saltarlo si no está habilitado) ni que verifique creación/decisión/Steps. |
| V02-05 | [PR #217 — KAN-153](https://github.com/DarkCodePE/plataforma-starteria/pull/217) | Se fusionó recuperación de Portfolio Entry y tratamiento de checkpoint con límites de lectura; PR reporta suites focales y Playwright. | Que resuelva cualquier otro flujo o incidente no reproducido; no es Copilot de Steps. |
| V02-06 | [PR #216 — PDF permissions](https://github.com/DarkCodePE/plataforma-starteria/pull/216) | Se añadió `requireProjectTeamAccess` a 8 rutas de PDFs/propuestas; pruebas del router con roles ajeno/VIEWER/EDITOR reportadas en PR. | Seguridad global de todos los recursos y cargas de archivos; el controller se mockea en el test mostrado. |
| V02-07 | [PR #215 — Step 4 Deck Feedback](https://github.com/DarkCodePE/plataforma-starteria/pull/215) | Se fusionó funcionalidad de subida PDF del deck, contraste IA con outputs Steps 0–3, persistencia y consumo gobernado de crédito. | Precisión semántica del modelo live, permisos en tenant real, ROI, ni Decision Package E2E completado. |
| V02-08 | [PR #210 — F-04/F-12/Step 0](https://github.com/DarkCodePE/plataforma-starteria/pull/210) | Se corrigió por código un bloqueo de navegación Step 0→1 cuando Step 0 ya estaba confirmado, además de fallo de read-model de aprendizajes y recuperación de confirmación de ruta. | Que el usuario deje de reproducirlo en producción sin verificación posterior. |
| V02-09 | [`portfolio-handoff-response.service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-handoff/application/portfolio-handoff-response.service.ts), [`HandoffInvitationPage.tsx`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/HandoffInvitationPage.tsx) | `startAssignedWork()` registra transición, versión, identidad e idempotencia; en handler de la página `start()` se actualiza el preview. | Puente completo post-Start→formulación o revisión de Initiative: no está demostrado por ese recorrido. |
| V02-10 | [`copilot-orchestration.service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-orchestration.service.ts), [`capability-registry.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/capability-registry.ts), [`copilot-runtime-config.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-runtime-config.ts) | El Copilot transversal persiste mensajes/intención/plan, pero el registro de capacidad consultado contiene `CreateStrategicFront`, y el assessment es determinista/condicionado por configuración. | Motor cognitivo universal orientando **cada input de Steps**. |
| V02-11 | [`checkpoint-planner.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/checkpoint-planner.ts), [`AdaptiveCheckpointWorkspace.tsx`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/features/adaptive-core/components/AdaptiveCheckpointWorkspace.tsx) | Reutiliza respuestas/contexto para materializar variables y preguntas; la UI sigue renderizando cuestionario `questions.map`. | Interpretación semántica de conversación libre hacia la Card viva; evaluación crítica continua. |
| V02-12 | [`portfolio-home.read-service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio-home.read-service.ts), [`decision-portfolio-return.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/decision-portfolio-return.ts) | Hay lecturas agregadas y propagación de efectos de decisión hacia portafolio. | Causalidad del impacto y trazabilidad completa con una decisión real desde Step 4. |

**Nota de certificación:** `success` en un job CI/CD es **evidencia de esa ejecución**; no lo reetiquetamos como "aprobado en producción" de un escenario que la suite no cubrió.

### 13.2. Correcciones / mayor precisión respecto a la matriz v0.1

| IDs v0.1 | Dictamen complementario v0.2 | Estado de verificación | Tratamiento propuesto |
|---|---|---|---|
| `PE-02`, `PE-04` | Existe CI E2E light de Portfolio Entry y recuperación KAN-153 fusionada. | `CI_SCOPED_PASS`, live no observado | `KEEP/ADAPT` sin duplicar motor Entry. |
| `PL-01`, `PL-11` | Deploy tiene verificación de API y *posible* smoke autenticado de Home/Capacity, **condicional**. | `DEPLOY_PASS` + `API_SMOKE_EXECUTION_UNKNOWN` | `KEEP` read models; comprobar datos/contexto en vista real. |
| `PL-09` | Solapamientos tienen endpoints/CRUD pero **no se verificó** análisis automático con explicación y revisión. | `CODE_PRESENT`, `UX_NOT_VERIFIED` | `ADAPT` primero; no crear detector nuevo por presunción. |
| `HO-03`, `HO-04` | Semántica de Accept/Reject/Start y guards se observan implementados. | `CODE_CONFIRMED`, sin journey real | `KEEP`, regression role/idempotency. |
| `HO-07`, `HO-08` | Handler `Start` de `HandoffInvitationPage` no materializa ni navega por sí mismo al motor de formulación/continuidad. **Brecha comprobada en ese handler**, no prueba universal de inexistencia. | `CODE_GAP_SCOPED`, E2E sin cubrir | `ADAPT/NEW`, diseñar puente autorizado fuera del bounded context Handoff. |
| `IO-02`, `IO-05` | `CreateProjectPage` es una ruta separada con creación de Project/ChallengeLink; el UI de Handoff no integra esa creación en el handler revisado. | `CODE_PRESENT`, integración no verificada | `ADAPT`, conservar identidad de retos/iniciativas. |
| `ST-01` a `ST-17` | UI de checkpoints usa listas de preguntas; motor de propuestas de Cards conversacionales **no queda acreditado**. | `CODE_PRESENT`, `TOBE_NOT_PROVEN` | `ADAPT`, sin borrar flujos ni gates. |
| `AI-01` y afines | Orquestador por tareas y Copilot transversal determinista son capacidades distintas del motor mental madre. | `CODE_CONFIRMED`, motor nuevo no probado | Reutilizar componentes y **prototipar integración semántica en Step 0**. |
| `AI-01` a `AI-11` (evidencias) | PDF de iniciativa tiene control de roles reforzado tras PR #216. | `CI/UNIT_SCOPED`, live cross-org no probado | `KEEP` guard; probar ejecución en escenario autorizado. |
| `DC-01` a `DC-09` (Step 4) | PR #215 añade **análisis real de deck con IA**; por ello no debe tratarse como panel estático ausente en el checkout del commit. | `CODE+PR+CI`, provider live específico no probado | `KEEP/ADAPT`: integrar con Card final, Decision Package y fuentes sin duplicar. |
| `DC-01` a `DC-09` (retorno) | `DecisionReadinessResolver`, Portfolio Home y return propagation existen; falta evaluar su continuidad con decisión real. | `CODE_PRESENT`, E2E no observado | `ADAPT/VERIFY`, no rehacer modelos. |
| `DC-01` a `DC-09` (seguridad) | PR #216 cubre rutas PDF concretas; no autoriza afirmar seguridad global. | `UNIT_SCOPED_PASS (reported)` | Verificar cross-org, owner, viewer y mentor en todos los recursos. |

Ninguna corrección autoriza editar contratos ni promover Core v0.3.

### 13.3. Segunda pasada: resultado de los 25 casos del plan v0.1

| Caso | Clasificación factual a 20/10/2026 | Evidencia / bloqueo para cerrar |
|---|---|---|
| T01 | `CI_PARCIAL` | CI E2E de 114D/legacy/live understanding; falta usuario real landing→Portfolio Home con fuente y continuidad. |
| T02 | `CODIGO+CD_PARCIAL` | Front/retos/capacidad y CD; falta navegador con 2 frentes y 4 retos. |
| T03 | `NO_EJECUTADO` | Requiere dataset import de 20 iniciativas, solapamientos y confirmaciones. |
| T04 | `CODIGO_PARCIAL` | Modelo target_kind y Accept/Start; falta jornada sin Initiative en DB. |
| T05 | `NO_EJECUTADO` | Falta cuenta Initiative Owner con 2 retos y 1 iniciativa. |
| T06 | `CODIGO_PARCIAL` | Se observan estados; no se ejecutó login/restore entre Accept y Start. |
| T07 | `CODIGO_PARCIAL` | Start idempotente en servicio; falta test real concurrente/duplicado en entorno. |
| T08 | `BRECHA_EN_HANDLER / NO_EJECUTADO` | Handler Start no encadena formulación de nueva iniciativa; falta trace completo por assignmentId. |
| T09 | `NO_EJECUTADO` | Hay identity Existing Initiative; falta evidencia de reconstrucción con Step 3 previo. |
| T10 | `CODIGO_PARCIAL` | `CreateProjectPage` existe; falta ejecución de iniciativa independiente sin empresa. |
| T11 | `NO_EJECUTADO` | Mockup v0.6 falló; no extrapolar a Copilot productivo. |
| T12 | `NO_EJECUTADO` | PDF y propuestas existen por rutas; falta ingesta inicial, dos documentos, preservación y Card. |
| T13 | `NO_EJECUTADO` | Se requiere LLM real y evaluación de sesgo/alternativas. |
| T14 | `NO_EJECUTADO` | Se requiere Step 1 live que refute hipótesis y propague resultado al 2. |
| T15 | `NO_EJECUTADO` | Se requiere import de informe cuali+cuanti y no re-preguntar. |
| T16 | `NO_EJECUTADO` | Se requiere criterio leads reales vs Figma y decisión explícita de proxy. |
| T17 | `NO_EJECUTADO` | SupportRequest E2E no localizado como circuito completo. |
| T18 | `NO_EJECUTADO` | Se requieren resultados contradichos/ambiguos y su Card de Step 3. |
| T19 | `NO_EJECUTADO` | Se requiere caso no iterar; mockup no prueba runtime. |
| T20 | `CODIGO_PARCIAL` | PR #215 prueba camino deck real; falta Decision Package con ROI/impacto y origen de cada afirmación. |
| T21 | `CODIGO_PARCIAL` | Existe decisión/propagación a Portfolio; falta jornada real de actor correcto. |
| T22 | `CODIGO_PARCIAL` | Core tiene critical-change dependency/resolver tests; falta ejecución con KPI alterado y versionado. |
| T23 | `UNIT_CI_PARCIAL` | PR #216 prueba guard de 8 rutas PDF, no todo IDOR ni deployment multi-org. |
| T24 | `CI_PARCIAL` | PR #217 recuperación scoped Portfolio Entry; falta perder respuesta/timeout de Steps. |
| T25 | `FALLO_EN_MOCKUP / NO_EJECUTADO_EN_RUNTIME` | QA v0.6 verifica clasificación posicional; falta test semántico de motor real Steps. |

**No hay T01–T25 que pueda marcarse `LIVE_E2E_PASS` con la evidencia disponible.** Eso es un límite de observación, no equivale a «25 fallos del producto».

### 13.4. Decisiones de alcance antes de ejecutar pruebas reales

1. **Obtener SHA desplegado** de backend, frontend y ai-service desde manifiestos/pods o endpoint de versión, no asumir que deploy `success` corresponde aún a cada instancia.
2. **Usar un tenant E2E aislado** y datos ficticios; jamás clientes reales ni archivos confidenciales para prueba exploratoria.
3. Preservar el `main` y registrar snapshot de entidades antes y después. La prueba de creación/decisión es una **escritura de datos en un tenant de prueba**, y requiere ese entorno aislado y aprobación operativa.
4. Evitar cambiar entitlements, credenciales, permisos de producción, flags o migraciones durante esta auditoría.
5. Para todos los casos anotar: `test_id`, `persona/rol`, `URL`, `timestamp`, `deployment_sha`, `request_id`, `assignment_id`, `challenge_id`, `initiative_id`, `step`, `source_ref`, `expected`, `actual`, captura/log y resultado `PASS / FAIL / BLOCKED`.
6. Completar los escenarios con usuarios autenticados de Lead, Initiative Owner y viewer. **No pedir contraseñas ni tokens dentro del chat.**
7. Resolver contradicciones con autoridades vigentes antes de aplicar los cambios recomendados; `KEEP / ADAPT / REMOVE / NEW` sigue provisional.

### 13.5. Corte de continuidad

El siguiente salto de confianza exige **browser real autenticado o ejecución del repositorio con DB/servicios de pruebas disponibles**. GitHub fuente+CI no sustituyen ese tramo. El protocolo reproducible está en `STARTERIA_E2E_RUNTIME_TEST_RUNBOOK_v0.1.md`.

**Estado de la auditoría integral:** `EN_PROGRESO`; no promover a `AUDITORIA_E2E_VERIFICADA` hasta completar pruebas productivas/sandbox, revisión de roles/autoridad y registro de evidencia de las 46 capacidades P0.
