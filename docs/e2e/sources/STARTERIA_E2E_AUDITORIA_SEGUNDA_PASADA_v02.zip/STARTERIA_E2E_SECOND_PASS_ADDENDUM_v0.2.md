# STARTERÍA — Segunda pasada de auditoría E2E (evidencia de código, CI/CD y límites de verificación)

**Versión:** 0.2 · **Fecha:** 20/10/2026 · **Modalidad:** AUDIT ONLY · **Estado:** `REPO+CI_VERIFIED_SCOPED / LIVE_UI_BLOCKED`  
**Repositorio:** `DarkCodePE/plataforma-starteria` · **Referencia inmutable:** [`75fc358838c34174da858937f4b47b92b8fbf074`](https://github.com/DarkCodePE/plataforma-starteria/commit/75fc358838c34174da858937f4b47b92b8fbf074).  
**Documento base:** `STARTERIA_E2E_ASIS_TOBE_GAP_MATRIX_v0.1.md` (73 capacidades, 46 P0, 26 P1, 1 P2).  
**TO-BE:** freezes candidatos de Steps y Portfolio↔Steps E2E; no sustituyen autoridad del repositorio.

## 0. Veredicto de esta pasada

Se pudo **verificar directamente por conector de GitHub** el estado de `main`, código de rutas/servicios, PRs fusionados, y **resultados de CI/CD de GitHub Actions** para el commit. Se pudo confirmar que el workflow de CD llegó a `Deploy to Rackspace Spot` y sus pasos de rollout y verificación finalizaron con `success`. **Esto no sustituye una prueba de experiencia de usuario en producción**.

Se intentó consultar la landing, `/dashboard` y `/public/start` mediante los medios de navegación disponibles y se probó conectividad desde el entorno de ejecución; **el sitio `https://starter-ia.com` no resultó accesible** por esos medios. No se realizó login, recorrido de navegador autenticado, inspección de base de datos productiva, validación contra proveedor LLM real, ni captura nueva de UX productiva. No se deben inferir fallos de la plataforma de esa inaccesibilidad: puede ser una restricción de este entorno.

**Resultado:** se elevó la confianza en *existencia e integración CI/CD acotada* y se corrigieron clasificaciones específicas; **la auditoría funcional en producción queda bloqueada**, no se simula con el HTML ni se declara superada. No se modificó código ni datos.

## 1. Evidencia nueva comprobada en esta pasada

| ID | Fuente / evidencia inmutable | Lo que prueba | Lo que NO prueba |
|---|---|---|---|
| V02-01 | [commit main 75fc3588](https://github.com/DarkCodePE/plataforma-starteria/commit/75fc358838c34174da858937f4b47b92b8fbf074) | La línea base `main` observada no cambió desde v0.1. | SHA desplegado actualmente en cada pod y configuración runtime. |
| V02-02 | [GitHub Actions CD #39080710106](https://github.com/DarkCodePE/plataforma-starteria/actions/runs/39080710106) | `success` en lint/build, Node tests/coverage, Python unit, Prisma drift, E2E light, imágenes backend/AI/frontend y Deploy to Rackspace Spot. | Calidad y completitud de E2E Portfolio→Steps; usabilidad real; éxito de LLM bajo datos nuevos. |
| V02-03 | [`.github/workflows/ci.yml`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/.github/workflows/ci.yml) | E2E light focaliza Portfolio Entry (`CURRENT_114D`, `LEGACY_COMPAT`, Live Understanding, PostgreSQL confirmation). | Journey completo con Assignment→Start→Step 0–4→Portfolio, ni browser de producción. |
| V02-04 | [`.github/workflows/cd.yml`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/.github/workflows/cd.yml), [script API smoke](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/scripts/ci/prod-api-smoke.sh) | En deploy hay verificaciones de schema/API tras rollout y paso de smoke autenticado condicional. El script consulta `GET` de Strategic Fronts, Home, Capacity, Projects tras login. | Que el smoke con tenant se haya **ejecutado** (el workflow puede saltarlo si no está habilitado) ni que verifique creación/decisión/Steps. |
| V02-05 | [PR #217 — KAN-153](https://github.com/DarkCodePE/plataforma-starteria/pull/217) | Se fusionó recuperación de Portfolio Entry y tratamiento de checkpoint con límites de lectura; PR reporta suites focales y Playwright. | Que resuelva cualquier otro flujo o incidente no reproducido; no es Copilot de Steps. |
| V02-06 | [PR #216 — PDF permissions](https://github.com/DarkCodePE/plataforma-starteria/pull/216) | Se añadió `requireProjectTeamAccess` a 8 rutas de PDFs/propuestas; pruebas del router con roles ajeno/VIEWER/EDITOR reportadas en PR. | Seguridad global de todos los recursos y cargas de archivos; el controller se mockea en el test mostrado. |
| V02-07 | [PR #215 — Step 4 Deck Feedback](https://github.com/DarkCodePE/plataforma-starteria/pull/215) | Se fusionó funcionalidad de subida PDF del deck, contraste IA con outputs Steps 0–3, persistencia y consumo gobernado de crédito. | Precisión semántica del modelo live, permisos en tenant real, ROI, ni Decision Package E2E completado. |
| V02-08 | [PR #210 — F-04/F-12/Step 0](https://github.com/DarkCodePE/plataforma-starteria/pull/210) | Se corrigió por código un bloqueo de navegación Step 0→1 cuando Step 0 ya estaba confirmado, además de fallo de read-model de aprendizajes y recuperación de confirmación de ruta. | Que el usuario deje de reproducirlo en producción sin verificación posterior. |
| V02-09 | [`portfolio-handoff-response.service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio-handoff/application/portfolio-handoff-response.service.ts), [`HandoffInvitationPage.tsx`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/app/pages/HandoffInvitationPage.tsx) | `startAssignedWork()` registra transición, versión, identidad e idempotencia; en handler de la página `start()` se actualiza el preview. | Puente completo post-Start→formulación o revisión de Initiative: no está demostrado por ese recorrido. |
| V02-10 | [`copilot-orchestration.service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-orchestration.service.ts), [`capability-registry.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/capability-registry.ts), [`copilot-runtime-config.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/copilot/application/copilot-runtime-config.ts) | El Copilot transversal persiste mensajes/intención/plan, pero el registro de capacidad consultado contiene `CreateStrategicFront`, y el assessment es determinista/condicionado por configuración. | Motor cognitivo universal orientando **cada input de Steps**. |
| V02-11 | [`checkpoint-planner.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/checkpoint-planner.ts), [`AdaptiveCheckpointWorkspace.tsx`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/front/src/features/adaptive-core/components/AdaptiveCheckpointWorkspace.tsx) | Reutiliza respuestas/contexto para materializar variables y preguntas; la UI sigue renderizando cuestionario `questions.map`. | Interpretación semántica de conversación libre hacia la Card viva; evaluación crítica continua. |
| V02-12 | [`portfolio-home.read-service.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/portfolio/portfolio-home.read-service.ts), [`decision-portfolio-return.ts`](https://github.com/DarkCodePE/plataforma-starteria/blob/75fc358838c34174da858937f4b47b92b8fbf074/backend/modules/adaptive-core/decision-portfolio-return.ts) | Hay lecturas agregadas y propagación de efectos de decisión hacia portafolio. | Causalidad del impacto y trazabilidad completa con una decisión real desde Step 4. |

**Nota de certificación:** `success` en un job CI/CD es **evidencia de esa ejecución**; no lo reetiquetamos como "aprobado en producción" de un escenario que la suite no cubrió.

## 2. Correcciones / mayor precisión respecto a la matriz v0.1

| IDs v0.1 | Dictamen complementario v0.2 | Estado de verificación | Tratamiento propuesto |
|---|---|---|---|
| `PE-02`, `PE-04` | Existe CI E2E light de Portfolio Entry y recuperación KAN-153 fusionada. | `CI_SCOPED_PASS`, live no observado | `KEEP/ADAPT` sin duplicar motor Entry. |
| `PL-01`, `PL-11` | Deploy tiene verificación de API y *posible* smoke autenticado de Home/Capacity, **condicional**. | `DEPLOY_PASS` + `API_SMOKE_EXECUTION_UNKNOWN` | `KEEP` read models; comprobar datos/contexto en vista real. |
| `PL-09` | Solapamientos tienen endpoints/CRUD pero **no se verificó** análisis automático con explicación y revisión. | `CODE_PRESENT`, `UX_NOT_VERIFIED` | `ADAPT` primero; no crear detector nuevo por presunción. |
| `HO-03`, `HO-04` | Semántica de Accept/Reject/Start y guards se observan implementados. | `CODE_CONFIRMED`, sin journey real | `KEEP`, regression role/idempotency. |
| `HO-07`, `HO-08` | Handler `Start` de `HandoffInvitationPage` no materializa ni navega por sí mismo al motor de formulación/continuidad. **Brecha comprobada en ese handler**, no prueba universal de inexistencia. | `CODE_GAP_SCOPED`, E2E sin cubrir | `ADAPT/NEW`, diseñar puente autorizado fuera del bounded context Handoff. |
| `IO-02`, `IO-05` | `CreateProjectPage` es una ruta separada con creación de Project/ChallengeLink; el UI de Handoff no integra esa creación en el handler revisado. | `CODE_PRESENT`, integración no verificada | `ADAPT`, conservar identidad de retos/iniciativas. |
| `ST-01` a `ST-17` | UI de checkpoints usa listas de preguntas; motor de propuestas de Cards conversacionales **no queda acreditado**. | `CODE_PRESENT`, `TOBE_NOT_PROVEN` | `ADAPT`, sin borrar flujos ni gates. |
| `AI-01` y afines | Orquestador por tareas y Copilot transversal determinista son capacidades distintas del motor mental madre. | `CODE_CONFIRMED`, motor nuevo no probado | Reutilizar componentes y **prototipar integración semántica en Step 0**. |
| `AI-01` a `AI-11` evidencias | PDF de iniciativa tiene control de roles reforzado tras PR #216. | `CI/UNIT_SCOPED`, live cross-org no probado | `KEEP` guard; probar ejecución en escenario autorizado. |
| `DC-01` a `DC-09` Step 4 | PR #215 añade **análisis real de deck con IA**; por ello no debe tratarse como panel estático ausente en el checkout del commit. | `CODE+PR+CI`, provider live específico no probado | `KEEP/ADAPT`: integrar con Card final, Decision Package y fuentes sin duplicar. |
| `DC-01` a `DC-09` retorno | `DecisionReadinessResolver`, Portfolio Home y return propagation existen; falta evaluar su continuidad con decisión real. | `CODE_PRESENT`, E2E no observado | `ADAPT/VERIFY`, no rehacer modelos. |
| `DC-01` a `DC-09` seguridad | PR #216 cubre rutas PDF concretas; no autoriza afirmar seguridad global. | `UNIT_SCOPED_PASS (reported)` | Verificar cross-org, owner, viewer y mentor en todos los recursos. |

Ninguna corrección autoriza editar contratos ni promover Core v0.3.

## 3. Segunda pasada: resultado de los 25 casos del plan v0.1

| Caso | Clasificación factual a 20/10/2026 | Evidencia / bloqueo para cerrar |
|---|---|---|
| T01 | `CI_PARCIAL` | CI E2E de 114D/legacy/live understanding; falta usuario real landing→Portfolio Home con fuente y continuidad. |
| T02 | `CODIGO+CD_PARCIAL` | Front/retos/capacidad y CD; falta navegador con 2 frentes y 4 retos. |
| T03 | `NO_EJECUTADO` | Requiere dataset import de 20 iniciativas, solapamientos y confirmaciones. |
| T04 | `CODIGO_PARCIAL` | Modelo target_kind y Accept/Start; falta jornada sin Initiative en DB. |
| T05 | `NO_EJECUTADO` | Falta cuenta Initiative Owner con 2 retos y 1 iniciativa. |
| T06 | `CODIGO_PARCIAL` | Se observan estados; no se ejecutó login/restore entre Accept y Start. |
| T07 | `CODIGO_PARCIAL` | Start idempotente en servicio; falta test real concurrente/duplicado en entorno. |
| T08 | `BRECHA_EN_HANDLER / NO_EJECUTADO` | Handler Start no encadena formulación de nueva iniciativa; falta trace completo por assignmentId. |
| T09 | `NO_EJECUTADO` | Hay identity Existing Initiative; falta evidencia de reconstrucción con Step 3 previo. |
| T10 | `CODIGO_PARCIAL` | `CreateProjectPage` existe; falta ejecución de iniciativa independiente sin empresa. |
| T11 | `NO_EJECUTADO` | Mockup v0.6 falló; no extrapolar a Copilot productivo. |
| T12 | `NO_EJECUTADO` | PDF y propuestas existen por rutas; falta ingesta inicial, dos documentos, preservación y Card. |
| T13 | `NO_EJECUTADO` | Se requiere LLM real y evaluación de sesgo/alternativas. |
| T14 | `NO_EJECUTADO` | Se requiere Step 1 live que refute hipótesis y propague resultado al 2. |
| T15 | `NO_EJECUTADO` | Se requiere import de informe cuali+cuanti y no re-preguntar. |
| T16 | `NO_EJECUTADO` | Se requiere criterio leads reales vs Figma y decisión explícita de proxy. |
| T17 | `NO_EJECUTADO` | SupportRequest E2E no localizado como circuito completo. |
| T18 | `NO_EJECUTADO` | Se requieren resultados contradichos/ambiguos y su Card de Step 3. |
| T19 | `NO_EJECUTADO` | Se requiere caso no iterar; mockup no prueba runtime. |
| T20 | `CODIGO_PARCIAL` | PR #215 prueba camino deck real; falta Decision Package con ROI/impacto y origen de cada afirmación. |
| T21 | `CODIGO_PARCIAL` | Existe decisión/propagación a Portfolio; falta jornada real de actor correcto. |
| T22 | `CODIGO_PARCIAL` | Core tiene critical-change dependency/resolver tests; falta ejecución con KPI alterado y versionado. |
| T23 | `UNIT_CI_PARCIAL` | PR #216 prueba guard de 8 rutas PDF, no todo IDOR ni deployment multi-org. |
| T24 | `CI_PARCIAL` | PR #217 recuperación scoped Portfolio Entry; falta perder respuesta/timeout de Steps. |
| T25 | `FALLO_EN_MOCKUP / NO_EJECUTADO_EN_RUNTIME` | QA v0.6 verifica clasificación posicional; falta test semántico de motor real Steps. |

**No hay T01–T25 que pueda marcarse `LIVE_E2E_PASS` con la evidencia disponible.** Eso es un límite de observación, no equivale a «25 fallos del producto».

## 4. Decisiones de alcance antes de ejecutar pruebas reales

1. **Obtener SHA desplegado** de backend, frontend y ai-service desde manifiestos/pods o endpoint de versión, no asumir que deploy `success` corresponde aún a cada instancia.
2. **Usar un tenant E2E aislado** y datos ficticios; jamás clientes reales ni archivos confidenciales para prueba exploratoria.
3. Preservar el `main` y registrar snapshot de entidades antes y después. La prueba de creación/decisión es una **escritura de datos en un tenant de prueba**, y requiere ese entorno aislado y aprobación operativa.
4. Evitar cambiar entitlements, credenciales, permisos de producción, flags o migraciones durante esta auditoría.
5. Para todos los casos anotar: `test_id`, `persona/rol`, `URL`, `timestamp`, `deployment_sha`, `request_id`, `assignment_id`, `challenge_id`, `initiative_id`, `step`, `source_ref`, `expected`, `actual`, captura/log y resultado `PASS / FAIL / BLOCKED`.
6. Completar los escenarios con usuarios autenticados de Lead, Initiative Owner y viewer. **No pedir contraseñas ni tokens dentro del chat.**
7. Resolver contradicciones con autoridades vigentes antes de aplicar los cambios recomendados; `KEEP / ADAPT / REMOVE / NEW` sigue provisional.

## 5. Corte de continuidad

El siguiente salto de confianza exige **browser real autenticado o ejecución del repositorio con DB/servicios de pruebas disponibles**. GitHub fuente+CI no sustituyen ese tramo. El protocolo reproducible está en `STARTERIA_E2E_RUNTIME_TEST_RUNBOOK_v0.1.md`.

**Estado de la auditoría integral:** `EN_PROGRESO`; no promover a `AUDITORIA_E2E_VERIFICADA` hasta completar pruebas productivas/sandbox, revisión de roles/autoridad y registro de evidencia de las 46 capacidades P0.
