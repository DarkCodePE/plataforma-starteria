# Auditoría UX y comportamental — Startería Steps v0.6

**Fecha:** 19/10/2026  
**Objeto probado:** `Starteria_Steps_Conversacion_Card_Viva_v06.html` (prototipo local)  
**Método:** automatización de navegador Chromium + lectura del estado JavaScript generado + capturas.  
**Límites:** el mockup no conecta con un LLM real, no analiza archivos y permite explícitamente transiciones simuladas. Los resultados NO describen el comportamiento actual del repositorio productivo.

## Resumen ejecutivo

**Resultado del ensayo: NO APTO todavía para validar la nueva experiencia conversacional.** Se puede navegar, responder y generar Cards, pero la información se asigna por orden de turno, no por su significado. El Copilot no replanifica el diálogo según lo aportado; las respuestas informativas se reciben con los mismos mensajes prefijados. Una Card puede contener un dato ajeno al campo o perder evidencia cuando se sube un archivo. Una persona sin conocimiento puede llegar a Step 2 sin comprender el reto ni disponer de evidencia.

### Perfil A: usuario que no conoce el proceso

**Escenario:** recibe el reto de mejorar activación de clientes, desconoce cómo funciona onboarding, las áreas implicadas y los datos disponibles.

| Interacción | Respuesta del usuario | Qué guardó el mockup |
|---|---|---|
| Step 0 / turno 1 | «No sé cómo funciona el onboarding, solo recibí el reto.» | `propuesta = No sé cómo funciona…` (INCORRECTO: no ha propuesto ninguna iniciativa) |
| Step 0 / turno 2 | «No conozco a las personas involucradas ni tengo documentos.» | `contexto = Pendiente` |
| Step 0 / turno 3 | «Desconozco qué debemos comprobar, nunca he trabajado en esa área.» | `duda = Pendiente` |
| Step 0 / turno 4 | «No tengo información sobre recursos, plazos o responsables.» | `limitacion = Pendiente` |
| Checkpoint Step 0 | Solo consta mandato recibido; no hay iniciativa delimitada ni incertidumbre definida | El botón permite continuar a Step 1 |
| Step 1 | Respondió cuatro veces «No tengo información y no sé cómo investigar todavía.» | El mockup llenó con `Pendiente` los apartados de investigación y permitió avanzar a Step 2 |
| Step 2 | Sin evidencia y sin foco definido | `foco = Pendiente: el usuario aún no dispone de esta información.` |

**Problemas para la persona:** el sistema no interpreta el desconocimiento como motivo para guiar el diagnóstico; consume turnos, pregunta por campos posteriores y permite cerrar sin un punto de partida real. La card queda incorrectamente caracterizada.

**Capturas:** `novice_step0_answer1.png`, `novice_checkpoint.png`, `novice_step2_without_evidence.png`.

### Perfil B: usuario que llega con información previa y quiere subirla

**Escenario:** recibió un reto nuevo, dispone de un informe, 18 entrevistas, mapa de proceso y tiempos por fase. Quiere que Startería los revise antes de encuadrar su propuesta.

| Momento | Qué intentó | Resultado observado |
|---|---|---|
| Brief y Step 0 | Subir archivos antes de empezar | No existe botón accesible de adjuntar en esas pantallas |
| Primera respuesta de Step 0 | Explicó qué fuentes tenía, principales cifras y hallazgos; pidió analizar PDF y Excel | TODO el párrafo se guarda en `propuesta` (INCORRECTO: es evidencia y contexto, no una propuesta de solución) |
| Step 0 / siguiente turno | Describió el flujo Comercial → Operaciones | Se guarda como `contexto`, pero el Copilot no contrastó esto con el reporte ya informado |
| Step 1 | Usó `Adjuntar referencia` para subir un archivo local | Solo registra nombre de archivo, sin leer ni analizar contenido |
| Step 1 / consulta | «Analiza el contenido del archivo…» | Respuesta genérica: no tiene conexión con LLM y recomienda revisar información |

**Defecto adicional confirmado:** cuando Step 1 ya tiene `evidencia = «El informe de junio contiene 84 registros, 21 detenidos…»`, adjuntar `evidencia_preexistente.txt` REEMPLAZA completamente el contenido de `evidencia` por «Archivo(s) adjuntado(s)…», en lugar de agregar la fuente al registro existente.

**Capturas:** `have_evidence_after_paste.png`, `have_evidence_step1.png`, `have_evidence_after_upload.png`, `evidence_overwrite.png`.

## Hallazgos priorizados

| ID | Severidad | Hallazgo comprobado | Causa técnica observada | Corrección requerida |
|---|---|---|---|---|
| UX-01 | **P0** | El usuario dice «No sé» y se registra como propuesta de iniciativa. | `replyOnTurn` asigna al campo en función de `maps[step][turn]`; además la expresión de desconocimiento tiene un límite `\\b` que no detecta de manera confiable el «sé» acentuado. | Detectar intención y significado; si no se conoce, dejar explícito `unknown`, mantener el mismo objetivo de aclaración y ofrecer una acción útil. |
| UX-02 | **P0** | Un texto completo con hallazgos, entrevistas y métricas queda guardado bajo «Qué propone hacer». | Asignación posicional por turno sin extracción de entidades/contexto, validación semántica o clasificación de procedencia. | Extraer claims por categoría, fuente y estado; mostrar sugerencias de Card para revisión antes de aplicarlas. |
| UX-03 | **P0** | Un usuario sin conocimiento entra a Step 2 sin evidencia ni alcance. | `checkpoint`/`next` permiten seguir con pendientes en esta demo; no existe lógica de suficiencia. | Checkpoints basados en resultado mínimo y evidencia/materialidad, con opciones de ayuda, posponer o solicitar soporte. Mantener el permiso de avance solo para modo demostración señalado explícitamente. |
| UX-04 | **P0** | No se pueden subir documentos al recibir el reto o en Step 0. | La UI `Adjuntar referencia` se genera únicamente para `i === 1`. | Permitir fuentes desde el brief, creación y todos los Steps; primero analizar material disponible y después preguntar por las brechas reales. |
| UX-05 | **P0** | Adjuntar un archivo sobreescribe evidencia previa. | El listener de `#localFile` ejecuta `set(S.step,'evidencia',...)`, con reemplazo destructivo. | Modelo de evidencias como objetos independientes y acumulativos, vinculados a claims, Step, tipo de fuente y revisión. |
| UX-06 | **P1** | Preguntas y respuestas siguen un guion incluso cuando el usuario ya aportó la información. | `prompt(i,n)` y `replyOnTurn` operan por índice de turno, no por incertidumbres resueltas. | Planificador dinámico: determinar qué se sabe, qué cambió, qué bloquea el output y siguiente intervención relevante. |
| UX-07 | **P1** | «Consulta libre» produce respuestas prefabricadas que no integran documentos ni Cards. | `advice()` selecciona fragmentos mediante expresiones regulares y texto genérico. | Copilot con contexto estructurado y herramientas por Step, distinguiendo sugerencias de hechos. |
| UX-08 | **P1** | Texto gramatical pero irrelevante supera validación y se registra como propuesta. | `meaningful()` analiza longitud/diversidad de letras, no pertinencia al reto. | Evaluar relevancia semántica; no descartar errores por regex solamente ni promover texto irrelevante a claims. |
| UX-09 | **P1** | Step 1 recibe `Pendiente: ...` como la duda principal al pasar desde Step 0. | Herencia textual de `val(0,'duda')` sin comprobar suficiencia, pertinencia o naturaleza del dato. | Handoff validado con `question_to_investigate`, fuente y motivo; sin foco, ayudar a definirlo antes de proseguir. |
| UX-10 | **P2** | «No sé» no dispara apropiadamente una intervención de exploración; de hecho queda guardado literalmente como propuesta. | Regex `\\b` alrededor de expresiones con caracteres acentuados. | Tests de lenguaje natural español, desconocimiento, respuestas ambiguas y textos contradictorios. |

## Evidencia técnica adicional

- La prueba no produjo excepciones JavaScript (`pageerror = []`). Los defectos son principalmente de semántica, autoridad y orquestación, no de renderizado.
- En un ensayo alternativo, respondí en Step 0 únicamente al mandato preexistente: hice clic directamente en `Revisar card` → `Continuar al siguiente Step`. Se abrió Step 1. Repetí sin responder ninguna pregunta y abrió Step 2. La demo lo advierte, pero **no sirve para ensayar la lógica real de gating**.
- Un texto no relacionado, «La tortuga verde camina despacio por el jardín los domingos», pasó `meaningful()` y quedó registrado en la propuesta de Step 0.
- El control de archivos existe oculto en el DOM desde el inicio, pero no tiene punto de entrada visible hasta Step 1. Incluso allí, la demo declara explícitamente que **no lee contenidos**.

## Recomendación de producto y pruebas siguientes

**Conservar:** Mis iniciativas, brief/traspaso narrativo, navegación de cinco Steps, conversación central y Card viva de salida.

**Cambiar antes de la siguiente prueba UX:**

1. Eliminar el mapeo `turno → campo` como fuente de verdad. El Copilot debe clasificar la respuesta y proponer actualizaciones de la Card por *significado*, incluso cuando una única respuesta contenga varios hechos y evidencias.
2. Añadir **«Ya tengo información» / «Adjuntar contexto»** desde el brief y desde cualquier Step, con lectura real en el producto final, referencias a fuente y confirmación humana de lo extraído.
3. Para el perfil sin conocimiento, el primer job es reconstruir contexto con guía (ejemplos, actores, proceso, datos o apoyo), no forzar una propuesta o terminar el Step.
4. Preparar el checkpoint desde una rúbrica de suficiencia **específica del Step y la iniciativa**, no desde 4 o 5 turnos.
5. Prueba comparativa A/B con los dos perfiles y una tercera persona que llegue con una idea de solución errada, y medir: correcciones de Card, turnos hasta primera acción útil, reutilización de fuentes, huecos de evidencia y capacidad de alcanzar el objetivo sin preguntas redundantes.

**Criterio de aceptación sugerido:** ante el texto «Ya tengo un informe, entrevistas y métricas…», Step 0 debe registrar qué fuentes existen y ofrecer revisarlas antes de pedir una propuesta; ante «No sé cómo funciona», debe dejar la propuesta sin definir y ofrecer una forma concreta de entender el proceso. En ambos casos la Card debe permanecer fiel a la información aportada y no crear afirmaciones no sustentadas.
