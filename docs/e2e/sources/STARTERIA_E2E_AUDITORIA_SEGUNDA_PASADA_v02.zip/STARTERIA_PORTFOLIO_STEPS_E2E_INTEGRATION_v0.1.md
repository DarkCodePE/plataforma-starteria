# STARTERÍA — PORTFOLIO LEAD × INITIATIVE OWNER × STEPS E2E

**Versión:** v0.1 · **Fecha:** 2026-10-20  
**Estado:** **CONTRATO DE INTEGRACIÓN CANDIDATO PARA REVISIÓN / PLANEAMIENTO**. No incorporado ni promovido a la autoridad del repositorio.  
**Dependencia:** `STEPS_TARGET_DESIGN_FREEZE_v0.1.md` (target de experiencia congelado, no implementación).  
**Propósito:** conectar estrategia → reto → asignación/aceptación → iniciativa → Steps → evidencia → decisión → retorno al portafolio, preservando autoridad y soporte a iniciativas nuevas, heredadas e independientes.

## 0. Autoridad y principio de continuidad

Fuente factual superior a revisar en el repositorio: `docs/STARTERIA_AUTHORITY.md` → Core v0.2 factual → ADRs de producto aprobados → Experience Contracts vigentes. La especificación Core v0.3 disponible es **candidata**; este documento usa sus funciones de Step, contribution/benefit-tracking como **target**, sin declarar sus deltas promovidos.

Contrato de frontera vigente y congelado para implementación: `docs/portfolio-lead/05-activation-handoff/PORTFOLIO_TO_INITIATIVE_ACTIVATION_EXPERIENCE_CONTRACT_v0.2.md`. Define dos assignments: `challenge` y `existing_initiative`. Su alcance acaba en **Start**. La creación posterior de Initiative, el reingreso a Steps y la reconstrucción metodológica requieren una experiencia/contrato **post-Start**, que aquí se propone como puente sin modificar retrospectivamente el contrato de activación.

Otras fuentes: `Portfolio Lead V.2.pdf` (PRD draft, subordinado), `PRD Starteria V.3.pdf` (importación/recorrido), `STARTERIA_CRAZY8S_E2E_BASE_LOGIC_v0.1.md`, `STEPS_NEW_CHAT_HANDOFF_v0.1.md`, contrato Strategic Framing SF-0 aprobado con alcance acotado, Portfolio Home Read Model PH-0 congelado para target, auditoría E2E de octubre 2026 y registro D-01–D-12.

**Regla madre:** Portfolio gobierna prioridades, cobertura, recursos/soporte y preparación de decisiones; Initiative Owner desarrolla iniciativas y produce evidencia; la **Autoridad de Decisión de Negocio** configurada decide lo reservado. Portfolio Lead puede coincidir con dicha autoridad solo cuando posee facultades explícitas.

## 1. Job to be done E2E

**Portfolio Lead:** «¿Qué objetivo debemos mover, qué retos e iniciativas lo están abordando, con qué evidencia, recursos y riesgos, y qué decisiones debemos preparar?»

**Initiative Owner:** «¿Qué me han pedido lograr, qué sé hasta ahora, qué puedo hacer con mis capacidades y qué evidencia necesito producir para justificar el siguiente paso?»

**Business Decision Authority:** «¿Qué podemos aprobar, cambiar, financiar, transferir, escalar o cerrar con evidencia suficientemente confiable?»

**Resultado de producto:** conectar intención + iniciativa + evidencias + decisiones, no solo obtener un brief o una respuesta de chat.

## 2. Recorrido E2E corporativo: ruta principal

```text
(0) Entrada/diagnóstico inicial [opcional según canal; no crea estructura automática]
    ↓
(1) Portfolio Entry / interpretación provisional y revisión humana
    ↓
(2) Portfolio Setup / Strategic Framing
    ORGANIZACIÓN [contexto transversal] → FRENTE → KPI/señal → baseline/target/horizonte [si existen]
    ↓
(3) Formular Reto (corrección | crecimiento | exploración)
    propósito + cambio buscado + restricciones + horizonte + decisión objetivo
    ↓
(4) Activar cobertura y decidir cómo movilizar personas/capacidades
    una o varias iniciativas existentes o nuevas; owner asignado
    ↓
(5) ASSIGN → Invitation → revisión brief → ACCEPT / REJECT → Activation Overview → START
    [frontera formal del Experience Contract de Activation]
    ↓
(6) POST-START BRIDGE
    ├─ A: reto solo → coformular respuesta candidata con Copilot → confirmar → CREATE Initiative
    └─ B: Initiative existente → síntesis narrativa de continuidad + revisión/gating retroactivo
    ↓
(7) Initiative Overview + Step actual/ciclo gobernado → Steps 0–4 con Copilot + Card viva
    ↓
(8) Claims/evidencias y soporte durante ejecución → Signals hacia Portfolio
    ↓
(9) Step 4: Initiative Brief + Decision Package + solicitud de decisión
    ↓
(10) Portfolio Center de atención/decisión → Autoridad de Decisión de Negocio
    ↓
(11) Decision Event: continuar / iterar / pivotear / implementar / transferir /
     escalar / pausar / cerrar con aprendizaje
    ↓
(12) Ruta de continuidad, eventual nuevo ciclo, benefit tracking y memoria reutilizable
    ↺ señales actualizadas hacia Frente/Reto/Portfolio
```

**Precaución:** no inferir que esta cadena completa esté implementada, probada con IA real o desplegada. Representa el target integrado.

## 3. Tres journeys de Initiative Owner, una misma experiencia de Steps

### A. Reto nuevo que necesita iniciativa

```text
Portfolio Lead define Reto y asigna Challenge (sin Initiative)
→ persona revisa brief con resultado, horizonte, restricciones y contexto
→ Accept = acepta el encargo
→ Activation Overview = entiende lo recibido y el próximo movimiento
→ Start = se inicia el trabajo asignado (no crea por sí solo Initiative)
→ Copilot pregunta/analiza solo lo necesario para formular una respuesta concreta
→ user review de propuesta de Initiative, relación con el Reto y contribución esperada
→ confirmación explícita → Initiative draft/canónica según reglas y permisos vigentes
→ Step 0 enmarca **qué logrará la iniciativa actual** y qué necesita hacer/comprobar
```

**No:** obligar al owner a redefinir Frente/KPI, forzarlo a elegir un método o crear Initiative vacía al enviar una invitación.

### B. Iniciativa heredada o avanzada

```text
Portfolio asigna Existing Initiative existente, no crea copia
→ Accept → Overview → Start
→ lectura narrativa: objetivo original, qué intentaron, qué hicieron, evidencia recibida,
   resultados, cambios/decisiones, pendientes, riesgos y mandato ahora
→ se distinguen completitudes declaradas vs validadas (fuente + timestamp + revisión)
→ gating retroactivo (no convertir Step 3 importado en aprobación implícita de Step 1)
→ aterrizaje del nuevo ownership + ruta apropiada de continuidad
→ Step pertinente, o revisión previa si un hard gate crítico está abierto
```

**No:** decir «60% completo» sin método ni evidencia; obligar a repetir todo el trabajo; sobrescribir resultados históricos.

### C. Iniciativa independiente del usuario

```text
Mis iniciativas → Crear iniciativa
→ conversación inicial libre con Copilot (documentos opcionales)
→ propuesta provisional revisable
→ persona confirma creación
→ Step 0–4 sin exigir Frente/Reto corporativo
→ decisión de continuidad según su contexto (iterar, probar, comercializar, partner, etc.)
```

Puede solicitar vinculación futura a una organización/reto por un flujo gobernado. No adquiere permisos Portfolio Lead automáticamente.

## 4. Un reto, varias respuestas, un portafolio

- Un **Frente Estratégico** puede conectarse a distintos Retos; un Reto puede recibir múltiples iniciativas distintas que buscan contribuir a su resultado.
- El Portfolio Lead puede operar un caso sencillo con **un solo reto y una iniciativa**, o un conjunto de frentes, retos e iniciativas. La UX puede simplificar «prioridad → iniciativa» cuando no hay necesidad de comparación, **sin cambiar** por ello la relación canónica corporativa que establezca el Core vigente.
- El Portfolio debe ver **cobertura** (qué iniciativas intentan abordar el reto), **contribución** (hipótesis/mecanismo/evidencia de aporte) e **impacto** (cambio observado/atribuido) como dimensiones separadas.
- Un assignment de Challenge sin Initiative no se cuenta como Initiative en curso. Si el owner propone dos iniciativas para el mismo reto, se requiere una confirmación explícita de su creación y del alcance autorizado, no creación implícita.
- Para cartera grande, la Home prioriza atención: solicitudes de ayuda, bloqueos, calidad de evidencia, riesgo de desalineamiento, fechas y decisiones. No puede afirmarse que haya retorno/ROI real sin observación y atribución suficientes.

## 5. Handoffs entre Portfolio, Assigned Work y Steps

| Frontera | Actor que entrega → recibe | Paquete mínimo | Confirmación / condición |
|---|---|---|---|
| Frente → Reto | Portfolio Lead | resultado buscado, KPI/señal, baseline/target/horizonte cuando existan, razón de negocio y restricciones | Creación/activación humana dentro de dominio vigente |
| Reto → Assigned Work | Portfolio Lead → persona invitada | `challenge_ref`, `assignment_id`, `target_kind`, `initiative_ref?`, mandato, contexto, fuentes, owner propuesto, restricciones, decisión objetivo, versión | Invite no es Accept; Accept no es Start |
| Accept → Start | Invitado/Owner | aceptación explícita, contexto revisable, preguntas pendientes | Start requiere aceptado; comando idempotente y con permisos |
| Start → Initiative (ruta A) | Owner/Copilot → Core | propuesta estructurada, alternativa elegida, vínculo propuesto a Reto, contribución esperada, dudas, restricciones, fuentes | Confirmación humana antes de crear/promover objeto canónico |
| Start → continuidad (ruta B) | Owner/Copilot → Core | narrativa heredada, snapshots, claims, evidencia, decisión histórica, completitud y gaps revisables | No duplica Initiative; gating retroactivo y status `requires_review` cuando corresponda |
| Step N → Step N+1 | Initiative Owner + validadores | Card de salida + evidencia/claims + contradicciones + unknowns + decisión siguiente + versión | Checkpoint de suficiencia y gates, no solo completitud textual |
| Step 4 → Portfolio | Initiative Owner → Portfolio | Initiative Brief, Decision Package, opción recomendada, outcome esperado/observado, riesgos, necesidades, recursos, evidencias, incertidumbre | Ingreso a cola de decisión, **sin autoaprobar** |
| Portfolio → Authority | Portfolio Lead → autoridad específica | paquete con resumen ejecutivo y detalle auditable | Decisión explícita, auditada, con actor autorizado |
| Decision → Continuidad | Autoridad → Owner/Portfolio/IT/operación | decisión, responsable siguiente, alcance, fechas, requisitos, transferencias, métricas de seguimiento | Handoff real con aceptación cuando corresponda |

### 5.1 Mínimo de `MissionContext` para Steps (conceptual, no schema productivo)

```text
MissionContext
├── initiative_id? / assignment_id
├── target_kind: challenge | existing_initiative | independent
├── challenge_snapshot_id? / challenge_version?
├── strategic_front_ref? / organizational_context_snapshot?
├── business_outcome / KPI_or_signal? / baseline? / target? / horizon?
├── execution_mandate + desired_decision
├── owner + executing_team + business_decision_authority_ref?
├── constraints {time,budget,capacity,dependencies,guardrails}
├── known_sources[] + evidence_refs[] + claims[]
├── work_history[] + step_outputs[] + prior_decisions[]
├── alignment_status + contribution_hypothesis
└── origin_provenance + review_state + change_version
```

Los campos opcionales permanecen desconocidos si el usuario no los declaró o no están disponibles. El modelo no rellena KPI, ROIs, owners o valores por suposiciones.

### 5.2 `StepResultEnvelope` hacia Portfolio (conceptual)

```text
StepResultEnvelope
├── initiative_id / active_cycle_id / step_number / output_version
├── result_card_ref
├── expected_output + completion_state + sufficiency_state
├── material_findings[] + evidence_refs[] + source_refs[]
├── expected_contribution + observed_signal? + impact_claims[]
├── blockers[] + support_requests[] + required_decisions[]
├── next_work + next_owner + checkpoint_review_status
├── upstream_mandate_snapshot_version
└── generated_at + actor_attribution + provenance
```

**Portfolio consume lecturas y eventos**, no manipula directamente `StepState` ni interpreta la conversación como fuente canónica. Durante trabajo, recibe señales de atención útiles; no necesita ver cada pregunta que realizó el Copilot.

## 6. Navegación E2E por rol (target)

| Portfolio Lead | Initiative Owner | Decisor |
|---|---|---|
| Inicio / prioridades / atención | **Mis iniciativas**, con assignments como cards y botón Crear iniciativa | Bandeja de solicitudes de decisión cuando corresponda |
| Frentes y retos / cobertura | Brief recibido, continuidad heredada, contexto y documentos | Resultados esperados y evidencia relevante |
| Iniciativas vinculadas / señales | Conversación Copilot + Card viva por Step | Alternativas, riesgos, costos/limitaciones |
| Bloqueos y solicitudes | Evidencias, solicitudes de ayuda, actividad | Decisión confirmada con rationale |
| Centro de decisión / seguimiento de beneficios | Resultado Step 4 y estado de decisión | Seguimiento según permisos y responsabilidad |

No mostrar Portfolio/Estructura de Equipos como responsabilidades que el ejecutor debe gobernar dentro de Steps. El usuario puede tener **roles múltiples**, pero las acciones de cada rol requieren permisos y contexto explícitos.

## 7. Qué ve el Portfolio Lead durante cada Step

| Momento | Señal útil para Portfolio | Qué NO debe afirmarse |
|---|---|---|
| Pre-Start | Assignment propuesto/aceptado/por comenzar, dudas sin resolver | «Iniciativa activa» si no existe ni se ha iniciado |
| Step 0 | Propósito y alcance definidos, fit con mandato como propuesta, gaps y restricciones | KPI movido o alineamiento corporativo confirmado por IA |
| Step 1 | Hallazgos apoyados por fuentes, cambio de framing, incertidumbres y bloqueos | «Problema comprobado» sin evidencia suficiente |
| Step 2 | Opción elegida, hipótesis de impacto, artefacto preparado, capacidades faltantes y readiness | Resultado de negocio realizado porque existe un mockup |
| Step 3 | Experimento ejecutado, señal observada, discrepancias, supuestos apoyados/refutados | Atribución causal sin método ni validación |
| Step 4 | Decision Package, alternativas, costos/riesgos y necesidad de decisión | Decisión humana ya aprobada por generar documento |
| Después del ciclo | Decisión, transferencia, implementación, resultados posteriores con fuente | Confundir proyección/ahorro estimado con beneficio observado |

**Visión de valor:** jerarquía Reto → Iniciativas → evidencia/decisiones/impacto. Cada señal debe conservar fuente, fuerza de evidencia, fecha y referencia al mandato vigente.

## 8. Soporte y desbloqueo desde Steps hacia Portfolio

El ejecutor puede pedir acceso a clientes, datos/áreas, permiso, responsable, orientación sobre mandato, soporte técnico, recursos o una decisión. Se propone un objeto/evento conceptual:

```text
SupportRequest
├── initiative_ref + assignment_ref? + step_ref + challenge_ref?
├── request_type: access | data | technical | budget | coordination | scope | decision
├── situation + why_blocked + impact_if_unresolved
├── requested_action + suggested_recipient_role
├── urgency? + due_date? + attachments[]
├── state: draft | submitted | triaged | in_progress | resolved | rejected
└── versions + source_refs + author
```

`SupportRequest` no concede permisos ni fondos. Portfolio Lead canaliza/coordina; si la decisión está reservada a otra autoridad, solicita intervención del decisor válido. El owner puede continuar trabajo paralelo que no invalide restricciones.

## 9. Contrato de contribución y vínculo con el resultado de negocio

Cada iniciativa corporativa necesita una **hipótesis de contribución**, no un ROI supuesto. Relacionar:

```text
resultado del reto / KPI
        ↑
señal de contribución esperada
        ↑
hipótesis de mecanismo
        ↑
solución / experimento / implementación
        ↑
evidencia y resultados observados
```

En Step 2, el Copilot debe advertir si el artefacto elegido **no puede demostrar el impacto exigido**. Ejemplo: requisito de «captar leads» + Figma demuestra comprensión/usabilidad, no leads; diseñar prueba comercial apropiada, pedir capacidades adicionales o explicitar proxy limitado. En Step 3 se contrasta esperado/observado y en Portfolio se separa cobertura, contribución, movimiento del KPI y valor real atribuible.

## 10. Cambios materiales, evidencia antigua y retroalimentación

- Si Portfolio modifica materialmente KPI, alcance, horizonte, restricciones o decisión objetivo, registrar nueva versión del mandato y disparar **impact assessment** sobre iniciativas dependientes.
- Initiative Owner ve la diferencia, propone ajuste/reencuadre y conserva historial de lo que sabía cuando actuó. No se reescriben outputs anteriores.
- Una fuente importada con material tipo Step 3 puede ser almacenada y analizada aunque falten datos de Step 1; los gates retroactivos evitan aprobar sin reconstrucción/verificación.
- Nuevos resultados pueden refutar hipótesis previas: el motor ofrece reencuadre o nueva ruta de continuidad sin forzar un falso «avance lineal».
- El centro de decisión tiene que mostrar snapshots y **cuán actuales son** las fuentes utilizadas. La política exacta de snapshots obsoletos sigue abierta en D-09.

## 11. Scope E2E del MVP controlado

**Incluir para prueba de valor:** Portfolio Lead con un objetivo/Frente claro, uno o más Retos, asignación válida, aceptación separada de Start, formulación de una iniciativa nueva y recepción de una heredada, Step 0–4 con Cards y evidencia, solicitud de apoyo, Decision Package, intervención del decisor y retorno al portafolio; iniciativa independiente como tercer punto de entrada a Steps.

**No exigir para demostrar el primer valor:** integraciones profundas Jira/Drive/MCP enterprise, marketplace, automatización organizacional completa, causal attribution L6, motor financiero avanzado, múltiples proveedores LLM en producción ni industrialización automática de resultados.

**Diagnóstico de valor / Startería Lab / rutas autoservicio:** capa comercial/triage que puede derivar a estos journeys, pero **no se congela como puerta obligatoria del E2E operativo** ni se presume implementada. Requeriría un contrato de primer valor y una decisión explícita de alcance.

## 12. Preguntas contractuales no resueltas (no reconciliar silenciosamente)

| ID | Tensión | Tratamiento antes de implementar |
|---|---|---|
| **D-01** | Identidad oficial del repo y variantes WIP | Verificar fuente/branch exacto para implementación; no mezclar overlays sin integración. |
| **D-03** | Core v0.3 candidata: Reto activo necesita Initiative vs contrato Activation permite Challenge Assignment sin Initiative | Definir estados de Reto (draft/activación/preparación/en ejecución) mediante ADR/re-test si afecta dominio; no fabricar Initiative para satisfacer cobertura. |
| **B-01** | ¿Qué evento post-Start materializa una iniciativa candidata creada a partir de Challenge Assignment? | Definir contrato post-Start y autorización explícita de creación; preservar idempotencia y no inventar `pre_start` canónico. |
| **B-02** | ¿Cómo se determina el Step al recibir una Initiative avanzada? | Reconstrucción/gating retroactivo + revisión de suficiencia humana cuando corresponde; no usar porcentaje ni heurística del modelo como aprobación. |
| **B-03** | ¿Quién confirma el vínculo de contribución y cambios al mandato? | Definir actor autorizante y cuándo se requiere; IA solo propone. |
| **D-08** | Benefit Tracking y L5/L6 de Core candidato | Limitar MVP inicial a evidencia y decisión; realización/atribución requieren fuente, horizonte, autoridad y re-test. |
| **D-09** | Cambios en evidencia/snapshots tras confirmación | Política explícita de currentness y revisión de dependencias. |
| **D-12** | Integración SF/Portfolio Home y varias ramas | Delivery por slices y tests de grants, cross-org, observabilidad; no afirmar target mergeado. |

Las decisiones B-01/B-02/B-03 son propuestas de integración de este documento; no están cerradas por existir una mockup o PRD. No se promueve Core v0.3.

## 13. Casos E2E de aceptación

| ID | Caso | Resultado esperado |
|---|---|---|
| E2E-01 | PL configura objetivo y un Reto | Mandato con KPI/señal cuando exista, horizonte, constraints y fuentes; confirmación humana. |
| E2E-02 | PL asigna Challenge sin Initiative | Invitation no crea Initiative; Accept registra ownership; Start es evento independiente. |
| E2E-03 | Usuario abandona tras Accept | Assignment sigue aceptado, no se marca inicio ni Step 0 completado. |
| E2E-04 | Usuario crea propuesta para reto tras Start | Copilot propone; confirma persona; Initiative queda vinculada según autoridad y sin duplicados. |
| E2E-05 | Un reto convoca varias iniciativas | Portfolio ve cada Initiative, cobertura y evidencia por separado; no cuenta invitations como iniciativas. |
| E2E-06 | Usuario recibe Initiative avanzada | Se preserva entidad/historia; brief narrativo; gating retroactivo; no replay obligatorio del trabajo válido. |
| E2E-07 | Usuario crea iniciativa independiente | No se impone frente/reto ni se concede Portfolio Lead. |
| E2E-08 | Step 0 sin contexto | Copilot identifica lo que falta y orienta a obtenerlo, no inventa ni bloquea por formulario vacío. |
| E2E-09 | Step 1 contradice hipótesis original de IA | Card y señal para Portfolio muestran cambio de foco trazable, sin cambiar KPI del reto por IA. |
| E2E-10 | Step 2 Figma vs KPI leads | Se reporta brecha impacto/demostración, support request o prueba adecuada; no claim falso. |
| E2E-11 | Bloqueo por permisos/datos | Solicitud llega a cola Portfolio, responsable/estado; el owner conserva trabajo y notificación. |
| E2E-12 | Un Step se «completa» con basura irrelevante | Falla suficiencia; no Step transition automática. |
| E2E-13 | Step 3 refuta hipótesis | Se conserva resultado negativo como evidencia, no falso éxito; recomienda opciones. |
| E2E-14 | Usuario decide no iterar | Prepara recomendación y limitaciones para decisión, sin validar hipótesis automáticamente. |
| E2E-15 | Step 4 termina con Decision Package | PL/decisor ve expected vs observed, evidencias, recursos, riesgos y actor decisor. |
| E2E-16 | Decisor elige cierre/continuidad | Decisión trazable con responsable, siguiente acción, retorno actualizado en Portfolio. |
| E2E-17 | KPI/mandato cambia a mitad de Step 2 | Versiona cambio, alerta y revisión de impacto, no reescribe outputs. |
| E2E-18 | Dato estimado llega al portfolio | Se etiqueta esperado/estimado, nunca realizado o atribuible sin fuente/método. |
| E2E-19 | Usuario no tiene permiso Portfolio | No ve iniciativas/solicitudes de otras organizaciones, incluso con URL/ID conocido. |
| E2E-20 | IA falla mientras el usuario responde | Input preservado, reintento idempotente, no creación duplicada ni pérdida de Card previa. |

**Criterio de E2E GO para piloto:** 0 violaciones de autoridad, no invención/promoción indebida de claims, `Assign≠Accept≠Start` correcto, 3 journeys convergen en Steps y resultado retorna a Portfolio con estado de decisión y trazabilidad. El copy agradable no sustituye estos checks.

## 14. Entregables de implementación derivados (NO implementar en este freeze)

1. `POST_START_INITIATIVE_FORMULATION_AND_CONTINUITY_EXPERIENCE_CONTRACT` (B-01/B-02; después del hard boundary de Activation).
2. `STEPS_COPILOT_REASONING_AND_CARD_CONTRACT` (motor mental madre, next move, provenance, card schema y elección de intervención).
3. `PORTFOLIO_INITIATIVE_SIGNAL_AND_SUPPORT_CONTRACT` (read models/colas/solicitudes/decisiones sin escribir StepState desde Portfolio).
4. Traceability `Requirement → Code → Test` sobre repo actual, con matriz KEEP/ADAPT/REPAIR/NEW/ADR.
5. Harness E2E controlado con tres journeys y casos ST-01–ST-14 / E2E-01–E2E-20.

## 15. Criterio para considerar «integrada» la experiencia

Se considera preparada para implementación cuando: (a) se aprueba/reconcilia este contrato con la autoridad vigente; (b) se resuelven los conflictos materiales; (c) existe Tech Spec con IDs/estados/permisos/eventos versionados; (d) se define el post-Start; (e) existen pruebas que verifican handoffs, evidence truth y retorno al portafolio; (f) un test real con usuario valida comprensión y valor, no solo renderizado.

**Regla final:** Portfolio gobierna el «para qué» y la decisión; Steps acompaña el «cómo», conserva el «qué ocurrió» y entrega evidencia al decisor. Ninguna capa reemplaza a la otra.
